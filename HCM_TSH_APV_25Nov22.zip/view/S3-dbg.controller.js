/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
jQuery.sap.require("hcm.approve.timesheet.util.DataManager");
jQuery.sap.require("hcm.approve.timesheet.util.Formatter");
jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");

sap.ca.scfld.md.controller.BaseDetailController.extend("hcm.approve.timesheet.view.S3", {
	extHookcreateDetailModelData: null,
	extHookviewSummary: null,
	extHookChangeFooterButtons: null,

	getWeeklyPendingEntriesCount: function() {
		var numVisibleCheckBox = 0;
		var iconTabBarID = this.byId("S3IconTabBar");
		var SelectedKey = iconTabBarID.getSelectedKey();
		//fetch the items for the selected icon tab filter
		for (var k = 0; k < iconTabBarID.getItems().length; k++) {
			if (iconTabBarID.getItems()[k].getKey() === SelectedKey) {
				var oItems = this.byId("S3IconTabBar").getItems()[k].getContent()[0].getItems();
				break;
			}
		}
		/*		var selectedIconTabFilter = this.byId("S3IconTabBar").oSelectedItem;
		var oItems =  selectedIconTabFilter.getContent()[0].getItems();*/
		for (var i = 0; i < oItems.length; i++) {
			var oCheckBox = oItems[i].getCells()[1];
			if (oCheckBox.getEnabled() === true) {
				numVisibleCheckBox++;
			}
		}
		return numVisibleCheckBox;
	},
	updateModel: function() {
		this.updateFlag = true;
		//	this._initData(this.filter,this.IndividualMasterData);
		this.setBtnEnabled("ApproveBtn", false);
		this.setBtnEnabled("RejectBtn", false);
		var eventBus = sap.ui.getCore().getEventBus();
		eventBus.publish("hcm.approve.timesheet", "timesheetApproveReject", this.pernr);
		/*this.IndividualMasterData = this.oApplication.getModel("masterModel").getData().MasterModelDataCollection[this.masterItem];
		this.setDetailObjectHdr(this.IndividualMasterData);*/
	},
	refreshDetail: function(channelId, eventId, data) {
		this.IndividualMasterData = this.oApplication.getModel("masterModel").getData().MasterModelDataCollection[data.pos];
		this.pernr = this.IndividualMasterData.PERNR;
		var startDate = this.IndividualMasterData.STARTDATE;
		var endDate = this.IndividualMasterData.ENDDATE;
		this.filter = "PERNR eq '" + this.pernr + "' and STARTDATE eq '" + startDate + "'and ENDDATE eq '" + endDate + "'";
		this._initData(this.filter, this.IndividualMasterData);
		this.setDetailObjectHdr(this.IndividualMasterData);
	},
	setButtonState: function(event) {
		var iconTabBarID = this.byId("S3IconTabBar");
		var SelectedKey = iconTabBarID.getSelectedKey();
		var counterDateTime = this.fetchSelectedCounters(); //Note 2206414 async rec check
		this.lSelectedCounters = counterDateTime[0];
		this.lLaeda = counterDateTime[1];
		this.lLaetm = counterDateTime[2];

		if (this.lSelectedCounters.length !== 0) {
			this.setBtnEnabled("ApproveBtn", true);
			this.setBtnEnabled("RejectBtn", true);
		} else {
			this.setBtnEnabled("ApproveBtn", false);
			this.setBtnEnabled("RejectBtn", false);
		}

		var selectableEntriesCount = this.getWeeklyPendingEntriesCount();
		//handle the selection of header checkbox
		if (selectableEntriesCount === this.lSelectedCounters.length) {

			// var headerCheckBoxState = event.getParameters().checked;
			for (var k = 0; k < iconTabBarID.getItems().length; k++) {
				if (iconTabBarID.getItems()[k].getKey() === SelectedKey) {
					this.byId("S3IconTabBar").getItems()[k].getContent()[0].getColumns()[1].getHeader().setSelected(true);
					this.prevAllSelected = true;
					break;
				}
			}

		} else if (this.prevAllSelected === true) {
			for (var k = 0; k < iconTabBarID.getItems().length; k++) {
				if (iconTabBarID.getItems()[k].getKey() === SelectedKey) {
					this.byId("S3IconTabBar").getItems()[k].getContent()[0].getColumns()[1].getHeader().setSelected(false);
					this.prevAllSelected = false;
					break;
				}
			}
		}
	},
	reset: function() { //Note 2124135
		var iconTabBarID = this.byId("S3IconTabBar");
		for (var k = 0; k < iconTabBarID.getItems().length; k++) {
			if (iconTabBarID.getItems()[k].getKey() === this.prevIconTabFilter) {
				this.byId("S3IconTabBar").getItems()[k].getContent()[0].getColumns()[1].getHeader().setSelected(false); //reset the header checkbox
				this.selectAllCheckBoxes(); //reset all the selected checkboxes and the button state
				break;
			}
		}
		this.prevIconTabFilter = this.byId("S3IconTabBar").getSelectedKey(); //End Note 2124135
	},
	selectAllCheckBoxes: function(event) {
		var iconTabBarID = this.byId("S3IconTabBar");

		var headerCheckBoxState, SelectedKey; //Note 2124135
		//If event is generated then call is from the checkbox , else it is from reset function
		if (event) {
			headerCheckBoxState = event.getParameters().selected;
			SelectedKey = iconTabBarID.getSelectedKey();
		} else { //set the parameters for resetting the rest of checkboxes in the previous contabfilter
			headerCheckBoxState = false;
			SelectedKey = this.prevIconTabFilter; //End Note 2124135
		}
		// var headerCheckBoxState = event.getParameters().checked;
		//fetch the items for the selected icon tab filter
		for (var k = 0; k < iconTabBarID.getItems().length; k++) {
			if (iconTabBarID.getItems()[k].getKey() === SelectedKey) {
				var oItems = this.byId("S3IconTabBar").getItems()[k].getContent()[0].getItems();
				break;
			}
		}
		/*		var selectedIconTabFilter = this.byId("S3IconTabBar").oSelectedItem;
		var oItems =  selectedIconTabFilter.getContent()[0].getItems();*/
		for (var i = 0; i < oItems.length; i++) {
			var oCheckBox = oItems[i].getCells()[1];
			if (oCheckBox.getEnabled() === true) {
				oCheckBox.setSelected(headerCheckBoxState); //set each checkbox to the headerCheckBox State
			}
		}
		//Set the button status according to the headerCheckBox state.
		if (headerCheckBoxState === true) {
			this.setBtnEnabled("ApproveBtn", true);
			this.setBtnEnabled("RejectBtn", true);
			this.prevAllSelected = true;
		} else {
			this.setBtnEnabled("ApproveBtn", false);
			this.setBtnEnabled("RejectBtn", false);
			this.prevAllSelected = true;
		}

		var counterDateTime = this.fetchSelectedCounters(); //Note 2206414 async rec check
		this.lSelectedCounters = counterDateTime[0];
		this.lLaeda = counterDateTime[1];
		this.lLaetm = counterDateTime[2];
	},
	fetchSelectedCounters: function(event) {
		var iconTabBarID = this.byId("S3IconTabBar");
		var SelectedKey = iconTabBarID.getSelectedKey();
		//fetch the items for the selected icon tab filter
		for (var k = 0; k < iconTabBarID.getItems().length; k++) {
			if (iconTabBarID.getItems()[k].getKey() === SelectedKey) {
				var oItems = this.byId("S3IconTabBar").getItems()[k].getContent()[0].getItems();
				break;
			}
		}
		/*	var selectedIconTabFilter = this.byId("S3IconTabBar").oSelectedItem;
		var oItems =  selectedIconTabFilter.getContent()[0].getItems();*/
		var oCounter = [],
			oLaeda = [],
			oLaetm = []; //Note 2206414 async rec check
		for (var i = 0; i < oItems.length; i++) {
			var oCheckBox = oItems[i].getCells()[1];
			if (oCheckBox.getSelected() === true)
			//	if(oCheckBox.getChecked() === true)
			{
				oCounter.push(oItems[i].getCells()[1].getCustomData()[0].getValue()); //Note 2206414 async rec check
				oLaeda.push(oItems[i].getCells()[1].getCustomData()[1].getValue());
				oLaetm.push(oItems[i].getCells()[1].getCustomData()[2].getValue());
			}
		}
		return [oCounter, oLaeda, oLaetm]; //Note 2206414 async rec check
	},

	setSelectedRejectionReason: function(rejReason) {
		this.Reason = rejReason.REASON;
		var RejectionReasonText = null;
		if (this.lSelectedCounters.length > 1) {
//BEGIN OF NOTE 2310185		    
		    if(this.resourceBundle.sLocale === 'ja'){
		     RejectionReasonText = this.resourceBundle.getText("TSA_REJS_CONF");                           //NOTE 2312493  
		    }else{       
			 RejectionReasonText = this.resourceBundle.getText("TSA_REJS_CONF") + " " + this.EMPNAME + "?";
		    }
		} else {
		   if(this.resourceBundle.sLocale === 'ja'){
		    RejectionReasonText = this.resourceBundle.getText("TSA_REJ_CONF");                            //NOTE 2312493     
		   }else{     
			RejectionReasonText = this.resourceBundle.getText("TSA_REJ_CONF") + " " + this.EMPNAME + "?";
		   }	
		}
//END OF NOTE 2310185
		var lSettings = this.confirmationTextBoxView(RejectionReasonText);
		sap.ca.ui.dialog.factory.confirm(lSettings, jQuery.proxy(function(response) {
			if (response.isConfirmed === true) {
				var submitStr = this.createSubmitStr("R", this.Reason);
				submitStr += "'";
				var collection = "CATS_ACTION?" + submitStr;
				hcm.approve.timesheet.util.DataManager.submitPendingEntries(collection, jQuery.proxy(function(oData, oResponse) {
					sap.ca.ui.message.showMessageToast(this.resourceBundle.getText("CATS_SUCCESS_MESSAGE"));
					this.updateModel();
				}, this));
			}
		}, this));
	},

	createSubmitStr: function(statusChar, rejReason) {
		var str = "cats='";
		for (var i = 0; i < this.lSelectedCounters.length; i++) {
			str += this.pernr + "," + this.lSelectedCounters[i] + "," + statusChar + "," + rejReason + "," + hcm.approve.timesheet.util.Formatter.LastDateTimeFormatter(
				this.lLaeda[i], this.lLaetm[i].ms) + "/"; //Note 2206414 async rec check
		}
		return str;
	},
	confirmationTextBoxView: function(ConfBoxText) {
		var oSettings = {
			question: ConfBoxText,
			showNote: false,
			title: this.resourceBundle.getText("TSA_CONF_HEADER"),
			confirmButtonLabel: "OK"
		};
		return oSettings;
	},

	/*fetchSelectedTableEntries : function(){
		var selectedIconTabFilter = this.byId("S3IconTabBar").oSelectedItem;					
		var selectedTableEntries = selectedIconTabFilter.getContent()[0].getSelectedItems();    
		return selectedTableEntries;
	},*/

	viewSummary: function(event) {
		/**
		 * @ControllerHook Modify the contents in the Summary pop-up
		 * This hook method can be used to add or remove the contents for the Summary pop-up
		 * It is called when you click on the button in the detail view
		 * @callback hcm.approve.timesheet.view.S3~extHookviewSummary
		 * @param {object} event captured on click of the button
		 */
		if (this.extHookviewSummary) {
			this.extHookviewSummary(event);
		} else {
			var counter = event.getSource().getCustomData()[0].getValue("counter");
			var iconTabBarID = this.byId("S3IconTabBar");
			var selectedKey = iconTabBarID.getSelectedKey();
			var selectedIcontab = null;
			for (var l = 0; l < iconTabBarID.getItems().length; l++) {
				if (iconTabBarID.getItems()[l].getKey() === selectedKey) {
					selectedIcontab = this.byId("S3IconTabBar").getItems()[l];
					break;
				}
			}

			var notesArray = [];
			/*	var path = selectedIcontab.mBindingInfos.key.binding.oContext.sPath;
		path = path.split("/");
		var weekIndex = path[2];*/
			var weekIndex = selectedIcontab.getCustomData()[0].getValue();
			var weeksCollection = this.oView.getModel("a").getData().DetailModelDataCollection;
			//traverse to fetch the past entry using counter as the reference
			var weekData = weeksCollection[weekIndex].PENDING_ENTRIES;

			for (var i = 0; i < weekData.length; i++) {
				if (weekData[i].COUNTER === counter) {
					notesArray.push({
						"title": this.resourceBundle.getText("TSA_DATE"),
						"description": hcm.approve.timesheet.util.Formatter.DateFormatter(weekData[i].WORKDATE)
					});
					notesArray.push({
						"title": this.resourceBundle.getText("TSA_DESCRIPTION"),
						"description": hcm.approve.timesheet.util.Formatter.newLineAdder(weekData[i].MAIN_FIELD_TEXT, weekData[i].SUB_FIELDS_TEXT)
					});
					notesArray.push({
						"title": this.resourceBundle.getText("TSA_TIME_RECORDED"),
						"description": hcm.approve.timesheet.util.Formatter.unitAppender(weekData[i].CATSHOURS, weekData[i].CATSUNIT)
					});
					var notes = weekData[i].NOTES;
					var rejectionReason = weekData[i].REJ_REASON;
					if (notes || rejectionReason) {
						if (notes) {
							notesArray.push({
								"title": this.resourceBundle.getText("TSA_NOTES"),
								"description": notes
							});
						}
						if (rejectionReason) {
							var rejectionReasonText = null;
							var CachedRejectionReason = hcm.approve.timesheet.util.DataManager.getCachedModelObjProp("RejectionReason");
							if (!CachedRejectionReason) {
								hcm.approve.timesheet.util.DataManager.getRejectionReasons(jQuery.proxy(function(objResponse) {
									//do-nothing
								}, this), function(objResponse) {
									//hcm.emp.mybenefits.util.DataManager.parseErrorMessages(objResponse);
									hcm.approve.timesheet.util.DataManager.processError(objResponse);
								});
								CachedRejectionReason = hcm.approve.timesheet.util.DataManager.getCachedModelObjProp("RejectionReason");
							}
							for (var j = 0; j < CachedRejectionReason.length; j++) {
								if (CachedRejectionReason[j].REASON === rejectionReason) {
									rejectionReasonText = CachedRejectionReason[j].TEXT;
								}
							}
							notesArray.push({
								"title": this.resourceBundle.getText("TSA_TIT_REJECTION_REASON"),
								"description": rejectionReasonText
							});
						}
					}

					if (weekData[i].oPastEntries) {

						for (var k = 0; k < weekData[i].oPastEntries.length; k++) { //Create the notes data

							var pastCatsHours = weekData[i].oPastEntries[k].CATSHOURS;
							var pastCatsUnit = weekData[i].oPastEntries[k].CATSUNIT;
							var changedDate = weekData[i].oPastEntries[k].CHANGED_DATE;
							var changedTime = weekData[i].oPastEntries[k].CHANGED_TIME;
							var changedBy = weekData[i].oPastEntries[k].CHANGED_BY;

							notesArray.push({
								"title": this.resourceBundle.getText("TSA_PAST_ENTRY"),
								"description": hcm.approve.timesheet.util.Formatter.unitAppender(pastCatsHours, pastCatsUnit)
							});
							notesArray.push({
								"title": this.resourceBundle.getText("TSA_CHANGED_DATETIME"),
								"description": hcm.approve.timesheet.util.Formatter.DateTimeFormatter(changedDate, changedTime)
							});

							notesArray.push({
								"title": this.resourceBundle.getText("TSA_CHANGED_BY"),
								"description": changedBy
							});
						}
					}
					break;
				}
			}
			var template = new sap.m.ColumnListItem({
				cells: [
		                new sap.m.Label({
						text: "{title}"
					}),
		                 new sap.m.Text({
						text: "{description}"
					})
		                                                ]
			});
			var oTable = new sap.m.Table({
				columns: [new sap.m.Column(), new sap.m.Column()]
			});
			var closePopOver = function(event) {
				oPopOver.close();
			};
			var details = this.resourceBundle.getText("TSA_DETAILS");
			var empname = event.getSource().getCustomData()[1].getValue("empname");
			var oPopOver = new sap.m.ResponsivePopover({
				contentWidth: "40%",
				placement: sap.m.PlacementType.Left,
				title: hcm.approve.timesheet.util.Formatter.textAppender(details, empname),
				content: oTable,
				beginButton: new sap.m.Button({
					text: this.resourceBundle.getText("TSA_ACCEPT"),
					press: closePopOver
				})
			});
			var noteJsonModel = new sap.ui.model.json.JSONModel({
				"Notes": notesArray
			});
			oTable.bindAggregation("items", "/Notes", template);
			oTable.setModel(noteJsonModel);
			oPopOver.openBy(sap.ui.getCore().byId(event.getParameters().id));

		}
	},

	handleSearch: function(oEvent) {
		var sValue = oEvent.getParameter("value");
		var oFilter = new sap.ui.model.Filter("TEXT", sap.ui.model.FilterOperator.Contains, sValue);
		var oBinding = oEvent.getSource().getBinding("items");
		oBinding.filter([oFilter]);
	},

	handleClose: function(evt) {
		var listSPath = evt.getParameters().selectedItem.getBindingContext().sPath;
		var listSPathSplit = listSPath.split("/");
		var listIndex = listSPathSplit[2];
		var CachedRejectionReason = hcm.approve.timesheet.util.DataManager.getCachedModelObjProp("RejectionReason");
		this.setSelectedRejectionReason(CachedRejectionReason[listIndex]);

	},

	setRejectionReasons: function(CachedRejectionReason) {
		var oData = {
			"RejectionReasonCollection": CachedRejectionReason
		};
		var oModel = new sap.ui.model.json.JSONModel(oData);
		var rejReasonTemplate = new sap.m.StandardListItem({
			title: "{TEXT}",
			type: "Active"
		});

		var oDialog = new sap.m.SelectDialog({
			title: this.resourceBundle.getText("TSA_TIT_REJECTION_REASON"),
			items: {
				path: "/RejectionReasonCollection",
				template: rejReasonTemplate
			},
			search: this.handleSearch,
			close: this.handleClose,
			confirm: jQuery.proxy(this.handleClose, this)
		});
		oDialog.setModel(oModel);
		oDialog.open();
	},

	setDetailObjectHdr: function(ObjHdrData) {
		this.EMPNAME = ObjHdrData.EMPNAME;
		var objHdr = this.byId("DetailObjHdr");
		objHdr.setTitle(ObjHdrData.EMPNAME);
		objHdr.setNumber(hcm.approve.timesheet.util.Formatter.timeConverter(ObjHdrData.CATSHOURS)); //Note 2206414 make duration display consistent with My Timesheet app
		objHdr.setNumberUnit(this.resourceBundle.getText("TSA_HRS_APPR"));
		this.byId("DetailObjHdrAttr1").setText(hcm.approve.timesheet.util.Formatter.weekAppender(ObjHdrData.NUM_WEEKS));
		this.byId("DetailObjHdrAttr2").setText(ObjHdrData.POSNAME);
		this.byId("DetailObjHdrStatus1").setText(hcm.approve.timesheet.util.Formatter.textAppender1( //Note 2206414 make duration display consistent with My Timesheet app
			hcm.approve.timesheet.util.Formatter.timeConverter(ObjHdrData.APPROVEDHOURS), this.resourceBundle
			.getText("TSA_HOURS"), this.resourceBundle.getText("TSA_STAT_APPROVED")));
		this.byId("DetailObjHdrStatus2").setText(hcm.approve.timesheet.util.Formatter.textAppender1(
			hcm.approve.timesheet.util.Formatter.timeConverter(ObjHdrData.REJECTEDHOURS), this.resourceBundle
			.getText("TSA_HOURS"), this.resourceBundle.getText("TSA_STAT_REJ")));
	},
	_getStatusText: function(number) {
		switch (number) {
			case "20":
				return [this.resourceBundle.getText("TSA_STAT_FOR_APPR"), "None", true];
			case "30":
				return [this.resourceBundle.getText("TSA_STAT_APPROVED"), "Success", false];
			case "40":
				return [this.resourceBundle.getText("TSA_STAT_REJ"), "Error", false];
			case "50":
				return [this.resourceBundle.getText("TSA_STAT_CHANGED"), "Warning", true];
		}
	},

	_createDetailModelData: function(oResults) {
		var weeksData = []; // holds complete set of weeks data
		var weekData = {}; //holds data for a week
		var oWeek = [];
		var oPendingEntry = {};
		var oAllPastEntries = [];
		var displayWeekNumber = 0;
		var pastEntries = []; //past entries associated with the new entry
		var currWeeknumber, nextWeekNumber, oStatus = null;
		var totalCatHours = 0.0,
			headerCheckboxState = false;

		for (var i = 0; i < oResults.length; i++) {
			currWeeknumber = oResults[i].WEEKNR;
			if (i !== oResults.length - 1) {
				nextWeekNumber = oResults[i + 1].WEEKNR;
			} else {
				nextWeekNumber = undefined;
			}

			oPendingEntry = {};
			oPendingEntry.EMPNAME = oResults[i].EMPNAME;
			oPendingEntry.WORKDATE = oResults[i].WORKDATE;
			oPendingEntry.MAIN_FIELD_TEXT = oResults[i].MAIN_FIELD_TEXT;
			oPendingEntry.SUB_FIELDS_TEXT = oResults[i].SUB_FIELDS_TEXT;
			oPendingEntry.CATSHOURS = oResults[i].CATSHOURS;
			oPendingEntry.CATSUNIT = oResults[i].CATSUNIT;
			var status = oResults[i].STATUS;
			if (status === "20" || status === "30") {
				totalCatHours += Number(oPendingEntry.CATSHOURS);
			}
			if (status === "20" && headerCheckboxState !== true) {
				headerCheckboxState = true;
			}
			oStatus = this._getStatusText(oResults[i].STATUS);
			oPendingEntry.STATUS_TEXT = oStatus[0];
			oPendingEntry.STATUS = oStatus[1];
			oPendingEntry.CHECKBOX_STATE = oStatus[2];
			oPendingEntry.CHECKBOX_SELECTED_STATE = false;
			oPendingEntry.COUNTER = oResults[i].COUNTER;
			oPendingEntry.REF_COUNTER = oResults[i].REF_COUNTER;

			oPendingEntry.CHANGED_DATE = oResults[i].CHANGED_DATE;
			oPendingEntry.CHANGED_TIME = oResults[i].CHANGED_TIME;
			oPendingEntry.CHANGED_BY = oResults[i].CHANGED_BY;
			if (oResults[i].CATSTEXT) { //Note: 2165196  check to display either catstext or ltxa1(short text)
				oPendingEntry.NOTES = oResults[i].CATSTEXT;
			} else {
				oPendingEntry.NOTES = oResults[i].NOTES;
			} //End Note: 2165196
			oPendingEntry.REJ_REASON = oResults[i].REJ_REASON;
			if (oPendingEntry.NOTES || oPendingEntry.REJ_REASON) {
				oPendingEntry.moreInfoBtnStatus = true;
			} else {
				oPendingEntry.moreInfoBtnStatus = false;
			}

			if (status === "50") {
				oAllPastEntries.push(oPendingEntry);
			} else {
				oWeek.push(oPendingEntry);
			}
			if (currWeeknumber !== nextWeekNumber) {
				for (var j = 0; j < oAllPastEntries.length; j++) {
					var counter = oAllPastEntries[j].COUNTER; //Counter of past entries will be matched with the ref_counter of the new entry
					for (var k = 0; k < oWeek.length; k++) {
						if (oWeek[k].REF_COUNTER === counter) {
							pastEntries.push(oAllPastEntries[j]);
							oWeek[k].moreInfoBtnStatus = true;
							oWeek[k].STATUS1 = oAllPastEntries[j].STATUS_TEXT;
							oWeek[k].oPastEntries = pastEntries;
							pastEntries = [];
							break;
						}
					}
				}
				weekData.PENDING_ENTRIES = oWeek;
				weekData.WEEK_START = oResults[i].WEEK_START;
				weekData.WEEK_END = oResults[i].WEEK_END;
				weekData.totalCatHours = totalCatHours;
				weekData.weekTarget = oResults[i].WEEK_TARGET;
				weekData.tableID = "PendingEntriesTable" + oResults[i].WEEKNR; //used to generate dynamic ids for table as well as tab filter
				weekData.tabFilterID = "IconTabFilter" + oResults[i].WEEKNR;
				weekData.displayWeekNumber = displayWeekNumber;
				weekData.MainCheckBoxState = headerCheckboxState;
				weekData.MainCheckBoxSelectedState = false;
				if (weekData.PENDING_ENTRIES.length > 0) {
					weeksData.push(weekData);
				}

				//clean up
				oWeek = [];
				weekData = {};
				totalCatHours = 0.0;
				headerCheckboxState = false;
				displayWeekNumber++;
			}
		}
		return weeksData;

	},
	_initData: function(filter, ObjHdrData) {
		this.setDetailObjectHdr(ObjHdrData);
		hcm.approve.timesheet.util.DataManager.getDetail(filter, jQuery.proxy(function(objResponse) {
			var DetailModelData;
			/**
			 * @ControllerHook Modify the loaded view
			 * It is called when the detail page odata call is successful
			 * @callback hcm.approve.timesheet.view.S3~extHookcreateDetailModelData
			 * @param {object} Response from the Detail Odata Call
			 * @return {object} Data parsed according to weeks
			 */
			if (this.extHookcreateDetailModelData) {
				DetailModelData = this.extHookcreateDetailModelData(objResponse);
			} else {
				DetailModelData = this._createDetailModelData(objResponse);
			}

			this.byId("RecordedTime").setText(hcm.approve.timesheet.util.Formatter.textFormatter(this.totalCatHours, ObjHdrData.TARGETHOURS));
			var oDetailModel = new sap.ui.model.json.JSONModel({
				"DetailModelDataCollection": DetailModelData
			});
			var oView = this.getView();
			oView.setModel(oDetailModel, "a");
			this.byId("S3IconTabBar").setExpanded(true);
			if (!this.updateFlag) {
				this.byId("S3IconTabBar").setSelectedKey(DetailModelData[0].tabFilterID);
				this.prevIconTabFilter = this.byId("S3IconTabBar").getSelectedKey();
			}
			this.updateFlag = false;
		}, this), function(objResponse) {
			hcm.approve.timesheet.util.DataManager.processError(objResponse);
			//hcm.emp.mybenefits.util.DataManager.parseErrorMessages(objResponse);
		});

	},

	onInit: function() {
		// execute the onInit for the base class
		// BaseDetailController
		sap.ca.scfld.md.controller.BaseDetailController.prototype.onInit.call(this);
		this.oDataModel = this.oApplicationFacade.getODataModel();
		this.resourceBundle = this.oApplicationFacade.getResourceBundle();
		hcm.approve.timesheet.util.DataManager.init(this.oDataModel, this.resourceBundle);

		var eventBus = sap.ui.getCore().getEventBus();
		eventBus.subscribe("hcm.approve.timesheet", "refreshDetail", this.refreshDetail, this);
		if (!this.oApplication) {
			this.oApplication = this.oApplicationFacade.oApplicationImplementation;
		}
		this.oRouter.attachRouteMatched(function(oEvent) {
			if (oEvent.getParameter("name") === "detail") {
				hcm.approve.timesheet.util.DataManager.init(this.oDataModel, this.resourceBundle);
				var contextPath = decodeURIComponent(oEvent.getParameter("arguments").contextPath);
				this.masterItem = Number(contextPath.slice(contextPath.indexOf("/") + 1, contextPath.length));
				this.IndividualMasterData = this.oApplication.getModel("masterModel").getData().MasterModelDataCollection[this.masterItem];
				this.pernr = this.IndividualMasterData.PERNR;
				var startDate = this.IndividualMasterData.STARTDATE;
				var endDate = this.IndividualMasterData.ENDDATE;
				this.filter = "PERNR eq '" + this.pernr + "' and STARTDATE eq '" + startDate + "'and ENDDATE eq '" + endDate + "'";
				this._initData(this.filter, this.IndividualMasterData);
			}

		}, this);
	},

	getHeaderFooterOptions: function() {
		var objHdrFtr = {
			oPositiveAction: {
				sId: "ApproveBtn",
				sI18nBtnTxt: this.resourceBundle.getText("TSA_APPROVE"),
				bDisabled: true,
				onBtnPressed: jQuery.proxy(function() {
					var ConfBoxText, lSettings;
					//Fetch the selected time entry counters
					if (this.lSelectedCounters.length > 1) {
//BEGIN OF NOTE 2310185					    
					    if(this.resourceBundle.sLocale === 'ja'){
					     ConfBoxText = this.resourceBundle.getText("TSA_APRS_CONF");                           //NOTE 2312493       
					    }else{
						 ConfBoxText = this.resourceBundle.getText("TSA_APRS_CONF") + " " + this.EMPNAME + "?";
					    }
					} else {
					   if(this.resourceBundle.sLocale === 'ja'){ 
					    ConfBoxText = this.resourceBundle.getText("TSA_APR_CONF");                            //NOTE 2312493  
					   }else{ 
						ConfBoxText = this.resourceBundle.getText("TSA_APR_CONF") + " " + this.EMPNAME + "?";
					   }
					}
//END OF NOTE 2310185					
					lSettings = this.confirmationTextBoxView(ConfBoxText); //function end create str, osettings
					sap.ca.ui.dialog.factory.confirm(lSettings, jQuery.proxy(function(response) {
						if (response.isConfirmed === true) {
							var submitStr = this.createSubmitStr("A", "");
							submitStr += "'";
							var collection = "CATS_ACTION?" + submitStr;
							hcm.approve.timesheet.util.DataManager.submitPendingEntries(collection, jQuery.proxy(function(oData, oResponse) {
								sap.ca.ui.message.showMessageToast(this.resourceBundle.getText("CATS_SUCCESS_MESSAGE"));
								this.updateModel();
							}, this));
						}
					}, this));
				}, this)
			},

			oNegativeAction: {
				sId: "RejectBtn",
				sI18nBtnTxt: this.resourceBundle.getText("TSA_REJECT"),
				bDisabled: true,
				onBtnPressed: jQuery.proxy(function() {
					var CachedRejectionReason = hcm.approve.timesheet.util.DataManager.getCachedModelObjProp("RejectionReason");
					if (!CachedRejectionReason) {
						hcm.approve.timesheet.util.DataManager.getRejectionReasons(jQuery.proxy(function(objResponse) {
							this.setRejectionReasons(objResponse);
						}, this), function(objResponse) {
							//hcm.emp.mybenefits.util.DataManager.parseErrorMessages(objResponse);
							hcm.approve.timesheet.util.DataManager.processError(objResponse);
						});
					} else {
						this.setRejectionReasons(CachedRejectionReason);
					}
				}, this)

			}
		};
		var m = new sap.ui.core.routing.HashChanger();
		var oUrl = m.getHash();
		if (oUrl.indexOf("Shell-runStandaloneApp") >= 0) {
			objHdrFtr.bSuppressBookmarkButton = true;
		}
		/**
		 * @ControllerHook Modify the footer buttons
		 * This hook method can be used to add and change buttons for the detail view footer
		 * It is called when the decision options for the detail item are fetched successfully
		 * @callback hcm.approve.timesheet.view.S3~extHookChangeFooterButtons
		 * @param {object} Header Footer Object
		 * @return {object} Header Footer Object
		 */

		if (this.extHookChangeFooterButtons) {
			objHdrFtr = this.extHookChangeFooterButtons(objHdrFtr);
		}
		return objHdrFtr;
	}
});