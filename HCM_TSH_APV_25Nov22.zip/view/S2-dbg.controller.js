/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.ScfldMasterController");

sap.ca.scfld.md.controller.ScfldMasterController.extend("hcm.approve.timesheet.view.S2", {

	extHookfillList: null,
	extHookChangeFooterButtons: null,

	onInit: function() {
		sap.ca.scfld.md.controller.ScfldMasterController.prototype.onInit.call(this);
		this.oDataModel = this.oApplicationFacade.getODataModel();
		this.resourceBundle = this.oApplicationFacade.getResourceBundle();
		hcm.approve.timesheet.util.DataManager.init(this.oDataModel, this.resourceBundle);
		hcm.approve.timesheet.util.Formatter.init(this.resourceBundle);
		this.oApplication = this.oApplicationFacade.oApplicationImplementation;
		this.oRouter.attachRouteMatched(this._handleRouteMatched, this);
		this._isLocalRouting = false;
		this._fnRefreshCompleted = null;
		this._isMasterRefresh = false;
		this.firstItemRemoved = false;

		var eventBus = sap.ui.getCore().getEventBus();
		eventBus.subscribe("hcm.approve.timesheet", "timesheetApproveReject", this._handleUpdate, this);
	},
	selectFirstItem: function() { //selectes either the first item or the item selected before refresh
		var oList = this.getList();
		var aItems = oList.getItems();
		var oListItem;
		var oIndex = null,
			searchKey = null;
		if (aItems.length < 1) {
			this.showEmptyView();
			this.pernr = null;
			this.updateModelCall = false;
			return;
		}
		var oInstance = new sap.ui.core.routing.HashChanger();
		var completeURL = oInstance.getHash().split('detail');
		if (completeURL[1] !== undefined) {
			completeURL = completeURL[1].split("/");
		}
		if (completeURL[1] !== undefined) {
			searchKey = decodeURIComponent(completeURL[1]);
			//	searchKey = decodeURIComponent(searchKey);

		}
		if (this.itemNotFound) {
			oIndex = searchKey.split("/")[1];
			if (oIndex === "0") {
				this.firstItemRemoved = true; //previously first item was removed
			}
			oListItem = this._oApplicationImplementation.getFirstListItem(this);
			this.setListItem(oListItem);
			return;
		}
		//get the index
		if ((searchKey !== null && searchKey !== "") && (aItems)) {
			oIndex = searchKey.split("/")[1];
			if (oIndex === null) {
				if (aItems.length > 0) {
					oListItem = this._oApplicationImplementation.getFirstListItem(this);
				} else {
					this.showEmptyView();
				}
			} else {

				if (aItems.length > oIndex) {
					oListItem = aItems[oIndex];
					this.setListItem(oListItem);
				}

			}
		} else {
			oListItem = this._oApplicationImplementation.getFirstListItem(this);
			this.setListItem(oListItem);
		}

	},
	/*	getDetailNavigationParameters : function(oListItem) {
		return {
			contextPath : encodeURIComponent(oListItem.getBindingContextPath().substr(1))
		};
	},*/
	_handleRouteMatched: function(oEvent) {

		// to use cached data for local routing
		if (oEvent.getParameter("name") === "master" && (this._isLocalRouting === false)) {
			this._initData();
		}
	},

	_handleUpdate: function(channelId, eventId, data) {
		this._initData(data);
	},

	setListItem: function(oItem) {
		var oList = this.getList();
		if (oList) {
			oList.removeSelections(true);
		}
		oItem.setSelected(true);
		if ( /*this.itemPathBeforeRefresh !== oList.getSelectedContextPaths()[0] ||*/ !this.updateModelCall || (this.itemNotFound && !this.firstItemRemoved)) {
			this.oRouter.navTo("detail", {
				contextPath: encodeURIComponent(oItem.getBindingContextPath().substr(1))
			}, !jQuery.device.is.phone);
		} else {
			this.updateModelCall = false;
			var eventBus = sap.ui.getCore().getEventBus();
			eventBus.publish("hcm.approve.timesheet", "refreshDetail", {
				pos: this.updatedMasterItemPos
			});
		}
		this._isLocalRouting = true;
		this.firstItemRemoved = false;
	},

	applySearchPatternToListItem: function(oItem, sFilterPattern) {
		if ((oItem.getTitle() && oItem.getTitle().toLowerCase().indexOf(sFilterPattern) !== -1) || (oItem.getNumber() && oItem.getNumber().toLowerCase()
			.indexOf(sFilterPattern) !== -1) || (oItem.getFirstStatus() && oItem.getFirstStatus().getText().toLowerCase().indexOf(sFilterPattern) !==
			-1) || (oItem.getSecondStatus() && oItem.getSecondStatus().getText().toLowerCase().indexOf(sFilterPattern) !== -1)) {
			return true;
		}
		var aAttributes = oItem.getAttributes();
		for (var j = 0; j < aAttributes.length; j++) {
			if (aAttributes[j].getText().toLowerCase().indexOf(sFilterPattern) !== -1) {
				return true;
			}
		}
		return false;
	},

	fillList: function(oMasterModel) {
		this.byId("list").bindItems({
			path: "/MasterModelDataCollection",
			template: new sap.m.ObjectListItem({
				type: "{device>/listItemType}",
				title: "{parts:[{path:'EMPNAME'}], formatter:'hcm.approve.timesheet.util.Formatter.removeText'}",
				number: "{parts:[{path:'CATSHOURS'}], formatter:'hcm.approve.timesheet.util.Formatter.timeConverter'}", //Note 2206414 make duration display consistent with My Timesheet app
				numberUnit: "{i18n>TSA_HOURS}",
				attributes: [
							              new sap.m.ObjectAttribute({
						text: "{POSNAME}"
					})],
				firstStatus: new sap.m.ObjectStatus({
					text: "{i18n>TSA_STAT_FOR_APPR}",
					state: "None"
				}),
				secondStatus: new sap.m.ObjectStatus({
					text: "{parts:[{path:'NUM_WEEKS'}], formatter:'hcm.approve.timesheet.util.Formatter.weekAppender'}",
					state: "None"
				}),
				customData: new sap.ui.core.CustomData({
					key: "AtsPernr",
					value: "{PERNR}"
				})
			})
		});
	},

	_initData: function(data) {
		if (data) {
			this.pernr = data; //will be set onupdate() via event bus
		}

		hcm.approve.timesheet.util.DataManager.getMaster(jQuery.proxy(function(objResponse) {
			//var MasterModelData = this._createDetailModelData(objResponse);
			var oMasterModel = new sap.ui.model.json.JSONModel({
				"MasterModelDataCollection": objResponse
			});
			var oView = this.getView();
			oView.setModel(oMasterModel);
			this.oApplication.setModel(oMasterModel, "masterModel");
			this._isLocalRouting = true;
			this.itemNotFound = false;
			/**
			 * @ControllerHook Modify the footer buttons
			 * This hook method can be used to add and change the properties of the list
			 * It is called when the employees data for the manager is called successfully
			 * @callback hcm.approve.timesheet.view.S2~extHookfillList
			 * @param {object} Master model for the list
			 */
			if (this.extHookfillList) {
				this.extHookfillList(oMasterModel);
			} else {
				this.fillList(oMasterModel);
			}
			this.refreshHeaderFooterForEditToggle();

			if (this._fnRefreshCompleted) {
				this._fnRefreshCompleted();
			}
			var i, masterListItems = this.byId("list").getItems();
			//to do : handle no data on update model call
			if (this.pernr) {
				this.updateModelCall = true;
				for (i = 0; i < masterListItems.length; i++) {
					if (this.pernr === masterListItems[i].getCustomData()[0].getValue("AtsPernr")) {
						this.updatedMasterItemPos = i;
						this.setListItem(masterListItems[i]);
						break;
					}
				}
				if (i === masterListItems.length) {
					if (masterListItems.length > 0) {
						this.pernr = masterListItems[0].getCustomData()[0].getValue("AtsPernr");
					}

					this.updatedMasterItemPos = 0;
					this.itemNotFound = true;
					this.selectFirstItem();
				}
			} else if (!jQuery.device.is.phone) {
				/*if((!jQuery.device.is.phone && i === masterListItems.length) || this._isMasterRefresh === true) ){*/
				this.selectFirstItem();
			}

		}, this), function(objResponse) {
			hcm.approve.timesheet.util.DataManager.processError(objResponse);
		});

	},
	getHeaderFooterOptions: function() {
		var data;
		var oList = this.byId("list");
		var count = oList.getItems().length;
		var objHdrFtr = {

			sI18NMasterTitle: this.resourceBundle.getText("MASTER_TITLE", [count]),
			onRefresh: jQuery.proxy(function(searchField, fnRefreshCompleted) {
				/*this.itemPathBeforeRefresh = this.byId("list").getSelectedContextPaths()[0];*/
				var length = this.byId("list").getItems().length;
				this._fnRefreshCompleted = fnRefreshCompleted;
				this._searchField = searchField;
				this._isMasterRefresh = true;
				if (length > 0 && !jQuery.device.is.phone) {
					data = this.byId("list").getSelectedItem().getCustomData()[0].getValue("AtsPernr");
				}
				this._initData(data);
				//var eventBus = sap.ui.getCore().getEventBus();
				//eventBus.publish("hcm.approve.timesheet", "refreshDetail",this.pernr);
			}, this)
		};
		var m = new sap.ui.core.routing.HashChanger();
		var oUrl = m.getHash();
		if (oUrl.indexOf("Shell-runStandaloneApp") >= 0) {
			objHdrFtr.onBack = null;
		}
		/**
		 * @ControllerHook Modify the footer buttons
		 * This hook method can be used to add and change buttons for the detail view footer
		 * It is called when the decision options for the detail item are fetched successfully
		 * @callback hcm.approve.timesheet.view.S2~extHookChangeFooterButtons
		 * @param {object} Header Footer Object
		 * @return {object} Header Footer Object
		 */

		if (this.extHookChangeFooterButtons) {
			objHdrFtr = this.extHookChangeFooterButtons(objHdrFtr);
		}

		return objHdrFtr;
	}
});