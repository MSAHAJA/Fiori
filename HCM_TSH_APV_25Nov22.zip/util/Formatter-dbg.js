/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
//declare namespace
jQuery.sap.declare("hcm.approve.timesheet.util.Formatter");
jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
jQuery.sap.require("sap.ca.ui.model.format.AmountFormat");

hcm.approve.timesheet.util.Formatter = {
	init: function(resourseBundle) {
		this.resourceBundle = resourseBundle;
	},
	DateRangeFormatter: function(ODate1, ODate2) {
		var oDateInstance = sap.ui.core.format.DateFormat.getDateInstance({
			style: "medium",
			pattern: "MMM dd"
		});

		var formattedDate1 = ODate1.substr(0, 4) + "-" + ODate1.substr(4, 2) + "-" + ODate1.substr(6, 2); //change date format to yyyy-mm-dd
		var formattedDate2 = ODate2.substr(0, 4) + "-" + ODate2.substr(4, 2) + "-" + ODate2.substr(6, 2);
		var displayDate = oDateInstance.format(new Date(formattedDate1), true) + " - " + oDateInstance.format(new Date(formattedDate2), true); //UTC param changed to true 2148838
		return displayDate;
	},

	DateFormatter: function(ODate) {
		var oDateInstance = sap.ui.core.format.DateFormat.getDateInstance({
			style: "medium",
			pattern: "MMM dd"
		});
		var formattedDate = ODate.substr(0, 4) + "-" + ODate.substr(4, 2) + "-" + ODate.substr(6, 2); //change date format to yyyy-mm-dd
		return oDateInstance.format(new Date(formattedDate), true); //UTC param changed to true 2148838
	},

	LastDateTimeFormatter: function(ODate, OTime) {
		var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
			pattern: "yyyyMMdd"
		});
		var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
			pattern: "HHmmss"
		});
		return dateFormat.format(ODate, true) + "," + timeFormat.format(new Date(OTime), true);
	},

	weekAppender: function(num_week) {
		if (num_week > 1) {
			return hcm.approve.timesheet.util.Formatter.resourceBundle.getText("TSA_OVER") + " " + num_week + " " + hcm.approve.timesheet.util.Formatter
				.resourceBundle.getText("TSA_WEEKS");
		} else {
			return hcm.approve.timesheet.util.Formatter.resourceBundle.getText("TSA_OVER") + " " + num_week + " " + hcm.approve.timesheet.util.Formatter
				.resourceBundle.getText("TSA_WEEK");
		}
	},

	textAppender: function(text1, text2) {
		return text1 + " " + text2;
	},

	textAppender1: function(text1, text2, text3) {
		var text = text1 + " " + text2 + ", " + text3;
		return text;
	},
	newLineAdder: function(text1, text2) {
		return text1 + "\n" + text2;
	},

	timeConverter: function(value) {
		var hours = parseInt(Number(value), 10).toString();
		var minutes = parseInt(((Number(value) - hours) * 60), 10).toString();

		if (hours.length === 1) {
			hours = "0" + hours;
		}
		if (minutes.length === 1) {
			minutes = "0" + minutes;
		}
		return hours + ":" + minutes;
	},
	unitAppender: function(text1, text2) {
		if (text2 === "H") { //convert to hours and minutes
			var time = hcm.approve.timesheet.util.Formatter.timeConverter(text1);
			return time;
		} else {
			return text1 + " " + text2;
		}
	},

	removeText: function(text1) {
		return text1.slice(text1.indexOf(".") + 1, text1.length); //Removes title from names(Mr Ms Mrs) 
	},
	IdFormatter: function(text1, text2) {
		return text1 + text2;
	},
	textFormatter: function(value, text1, text2) {
		if (value > 0) {
			return text1 + "/" + text2;
		} else {
			return text1;
		}
	},
	recTimeDisplay: function(value1, value2) {
		if (value2 > 0) {
			return hcm.approve.timesheet.util.Formatter.timeConverter(value1) + "/" + hcm.approve.timesheet.util.Formatter.timeConverter(value2);

		} else {
			return hcm.approve.timesheet.util.Formatter.timeConverter(value1);

		}
	},
	DateTimeFormatter: function(date, time) {
		var oDateInstance = sap.ui.core.format.DateFormat.getDateInstance({
			pattern: "d.MM.yyyy",
			locale: "EN"
		});
		var oDate = oDateInstance.format(date, false);
		var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
			pattern: "KK:mm:ss a"
		});
		// timezoneOffset is in hours convert to milliseconds  
		var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
		var oTime = timeFormat.format(new Date(time.ms + TZOffsetMs));
		return oDate + "[ " + oTime + " ]";
	}
};