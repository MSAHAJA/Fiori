jQuery.sap.registerPreloadedModules({
"name":"hcm/approve/timesheet/Component-preload",
"version":"2.0",
"modules":{
	"hcm/approve/timesheet/Component.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("hcm.approve.timesheet.Component");
jQuery.sap.require("hcm.approve.timesheet.Configuration");
jQuery.sap.require("sap.ca.scfld.md.ComponentBase");

sap.ca.scfld.md.ComponentBase.extend("hcm.approve.timesheet.Component", {
		metadata : sap.ca.scfld.md.ComponentBase.createMetaData("MD", {
			"name" : "Approve Timesheets",
			"version" : "1.8.7",
			"library" : "hcm.approve.timesheet",
			"includes" : [],
				"dependencies" : {
				"libs" : ["sap.m", "sap.me","sap.ui.commons"],
			"components" : []
			},
			"config" : {
			              "resourceBundle" : "i18n/i18n.properties",
                          "titleResource" : "TSA_APP_TITLE" 
			//	"resourceBundle" : "i18n/i18n.properties",
			//	"titleResource" : "SHELL_TITLE",
			//	"icon" : "sap-icon://Fiori2/F0002",
			//	"favIcon" : "./resources/sap/ca/ui/themes/base/img/favicon/F0002_My_Accounts.ico",
			//	"homeScreenIconPhone" : "./resources/sap/ca/ui/themes/base/img/launchicon/F0002_My_Accounts/57_iPhone_Desktop_Launch.png",
			//	"homeScreenIconPhone@2" : "./resources/sap/ca/ui/themes/base/img/launchicon/F0002_My_Accounts/114_iPhone-Retina_Web_Clip.png",
			//	"homeScreenIconTablet" : "./resources/sap/ca/ui/themes/base/img/launchicon/F0002_My_Accounts/72_iPad_Desktop_Launch.png",
			//	"homeScreenIconTablet@2" : "./resources/sap/ca/ui/themes/base/img/launchicon/F0002_My_Accounts/144_iPad_Retina_Web_Clip.png",
		},
		viewPath : "hcm.approve.timesheet.view"
		
		// masterPageRoutes : {
		// // fill the routes to your master pages in here. The application will start with a navigation to route "master"
		// leading to master screen S2.
		// // If this is not desired please define your own route "master"
		// },
		// detailPageRoutes : {
		// //fill the routes to your detail pages in here. The application will navigate from the master page to route
		// //"detail" leading to detail screen S3.
		// If this is not desired please define your own route "detail"
		//		"toS5" : {
		//			"pattern" : "toS5",
		//			"view" : "S5",
		//		}
		//},
		//fullScreenPageRoutes : {
		//	// fill the routes to your full screen pages in here.
		//	"subDetail" : {
		//		"pattern" : "subDetail/{contextPath}",
		//		"view" : "S4",
		//	}
		//}
	}),
	
	/**
	 * Initialize the application
	 *
	 * @returns {sap.ui.core.Control} the content
	 */
	createContent : function() {

		var oViewData = {
				component: this
		};
		return sap.ui.view({
			viewName: "hcm.approve.timesheet.Main",
			type: sap.ui.core.mvc.ViewType.XML,
			viewData: oViewData
		});
	
	}

});

},
	"hcm/approve/timesheet/Configuration.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("hcm.approve.timesheet.Configuration");
jQuery.sap.require("sap.ca.scfld.md.ConfigurationBase");
jQuery.sap.require("sap.ca.scfld.md.app.Application");

sap.ca.scfld.md.ConfigurationBase.extend("hcm.approve.timesheet.Configuration", {

	oServiceParams: {
		serviceList: [
			{
				name: "HCM_TIMESHEET_APPROVE_SRV",
				masterCollection: "TIME_PENDING",
				serviceUrl: "/sap/opu/odata/sap/HCM_TIMESHEET_APPROVE_SRV/",
				isDefault: true,
				mockedDataSource: "/hcm.approve.timesheet/model/metadata.xml",
				useBatch: true
			}
		]
	},

	getServiceParams: function () {
		return this.oServiceParams;
	},

/*	getAppConfig: function() {
		return this.oAppConfig;
	},*/

	/*
	 * @inherit
	 */
	getServiceList: function () {
		return this.oServiceParams.serviceList;
	},
	getMasterKeyAttributes : function() {
		//return the key attribute of your master list item
		return ["Id"];
	}

});
},
	"hcm/approve/timesheet/Main.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
sap.ui.controller("hcm.approve.timesheet.Main", {

	onInit : function() {
		jQuery.sap.require("sap.ca.scfld.md.Startup");				
		sap.ca.scfld.md.Startup.init("hcm.approve.timesheet", this);
		jQuery.sap.require("hcm.approve.timesheet.util.DataManager");
		jQuery.sap.require("hcm.approve.timesheet.util.Formatter");
	}
});
},
	"hcm/approve/timesheet/Main.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core"\n           xmlns="sap.m" controllerName="hcm.approve.timesheet.Main"  displayBlock="true" height="100%">\n        <App id="fioriContent" showHeader="false">\n        </App>\n</core:View>',
	"hcm/approve/timesheet/i18n/i18n.properties":'# Timesheet Approval Property file\n# __ldi.translation.uuid=bd588d80-5915-11e4-8ed6-0800200c9a66\n\n#XTIT:  Application name\nTSA_APP_TITLE=Approve Timesheets\n\n#XTIT:  Application name\nMASTER_TITLE=Timesheets ({0})\n\n#XTIT:  Application name\nTSA_APP=Timesheet\n\n#XTIT: detail panel text\nDETAIL_TITLE=Timesheet\n\n#XTIT: weekly target\nTSA_WEEKLY_TARGET=Target\n\n#XBUT: Button Approve\nTSA_APPROVE=Approve\n\n#XBUT: Button Reject\nTSA_REJECT=Reject\n\n#XBUT: button to confirm submit\nTSA_ACCEPT=OK\n\n#XBUT: Button to Navigate back&nbsp;\\\\\\&nbsp;\nTSA_BACK=Back\n\n#XFLD: No hours entered by the employee\nTSA_HOURS=Hours\n\n#XFLD: Hour in short form.\nTSA_HOUR_SHORT=h\n\n#XFLD: Minutes in short form.\nTSA_MIN_SHORT=m\n\n#YMSG: Message for list service error\nLIST_SERVICE_ERR_MESSAGE=Could not obtain the list of timesheet entries\n\n#YMSG: Message for Successful updation\nCATS_SUCCESS_MESSAGE= Timesheet entries updated\n\n#XFLD: Column header for activity\nTSA_ACTIVITY=Activity\n\n#XFLD: Column header for date\nTSA_DATE=Date\n\n#XTIT: Details  for time entry notes.\nTSA_DETAILS=Details for\n\n#XTIT: Title for list of rejection reasons\nTSA_TIT_REJECTION_REASON=Rejection Reason\n\n#XTIT: Message for Approval confirmation\nTSA_APR_CONF=Do you want to approve the selected entry for\n\n#XTIT: Message for Approvals confirmation\nTSA_APRS_CONF=Do you want to approve the selected entries for\n\n#XTIT: Message for Rejection confirmation\nTSA_REJ_CONF=Do you want to reject the selected entry for\n\n#XTIT: Message for Rejection confirmation\nTSA_REJS_CONF=Do you want to reject the selected entries for\n\n#XTIT: title for submit confirmation\nTSA_CONF_HEADER=Confirmation\n\n#XFLD: Text for multiple weeks\nTSA_WEEKS=Weeks\n\n#XFLD: Text for week\nTSA_WEEK=Week\n\n#XFLD: Recorded Time for employee.\nTSA_TIME_RECORDED=Recorded\n\n#XFLD: Notes for time entry.\nTSA_NOTES=Notes\n\n#XFLD: Over weeks.\nTSA_OVER=Over\n\n#XFLD: Wage Type for time entry.\nTSA_WAGE_TYPE=Wage Type\n\n#XTIT:Description\nTSA_DESCRIPTION = Description\n\n#XTIT: More information\nTSA_INFO = More Info\n\n#XFLD: Hours for approval\nTSA_HRS_APPR = Hours for approval\n\n#XFLD: For approval status\nTSA_STAT_FOR_APPR = For Approval\n\n#XFLD: Approved status\nTSA_STAT_APPROVED = Approved\n\n#XFLD: Rejected status\nTSA_STAT_REJ = Rejected\n\n#XFLD: Changed after approval\nTSA_STAT_CHANGED = Changed after approval\n\n#XTIT: Approval status header\nTSA_APPR_STATUS = Approval status\n\n#XTIT: Past Entry\nTSA_PAST_ENTRY = Past Entry\n\n#XFLD: Changed date\nTSA_CHANGED_DATETIME = Changed on\n\n#XFLD: Changed by\nTSA_CHANGED_BY = Changed by\n\n# YMSG: No items are currently available\nNO_ITEMS_AVAILABLE=No items are currently available\n',
	"hcm/approve/timesheet/i18n/i18n_ar.properties":'\n#XTIT:  Application name\nTSA_APP_TITLE=\\u0627\\u0639\\u062A\\u0645\\u0627\\u062F \\u0633\\u062C\\u0644\\u0627\\u062A \\u0627\\u0644\\u062D\\u0636\\u0648\\u0631\n\n#XTIT:  Application name\nMASTER_TITLE=\\u0633\\u062C\\u0644\\u0627\\u062A \\u0627\\u0644\\u062D\\u0636\\u0648\\u0631 ({0})\n\n#XTIT:  Application name\nTSA_APP=\\u0635\\u062D\\u064A\\u0641\\u0629 \\u0627\\u0644\\u062D\\u0636\\u0648\\u0631\n\n#XTIT: detail panel text\nDETAIL_TITLE=\\u0635\\u062D\\u064A\\u0641\\u0629 \\u0627\\u0644\\u062D\\u0636\\u0648\\u0631\n\n#XTIT: weekly target\nTSA_WEEKLY_TARGET=\\u0627\\u0644\\u0647\\u062F\\u0641\n\n#XBUT: Button Approve\nTSA_APPROVE=\\u0627\\u0639\\u062A\\u0645\\u0627\\u062F\n\n#XBUT: Button Reject\nTSA_REJECT=\\u0631\\u0641\\u0636\n\n#XBUT: button to confirm submit\nTSA_ACCEPT=\\u0645\\u0648\\u0627\\u0641\\u0642\n\n#XBUT: Button to Navigate back&nbsp;\\\\\\&nbsp;\nTSA_BACK=\\u0627\\u0644\\u062E\\u0644\\u0641\n\n#XFLD: No hours entered by the employee\nTSA_HOURS=\\u0627\\u0644\\u0633\\u0627\\u0639\\u0627\\u062A\n\n#XFLD: Hour in short form.\nTSA_HOUR_SHORT=\\u0633\n\n#XFLD: Minutes in short form.\nTSA_MIN_SHORT=\\u062F\n\n#YMSG: Message for list service error\nLIST_SERVICE_ERR_MESSAGE=\\u062A\\u0639\\u0630\\u0631 \\u0627\\u0644\\u062D\\u0635\\u0648\\u0644 \\u0639\\u0644\\u0649 \\u0642\\u0627\\u0626\\u0645\\u0629 \\u0628\\u0625\\u062F\\u062E\\u0627\\u0644\\u0627\\u062A \\u0633\\u062C\\u0644 \\u0627\\u0644\\u062D\\u0636\\u0648\\u0631\n\n#YMSG: Message for Successful updation\nCATS_SUCCESS_MESSAGE=\\u062A\\u0645 \\u062A\\u062D\\u062F\\u064A\\u062B \\u0625\\u062F\\u062E\\u0627\\u0644\\u0627\\u062A \\u0633\\u062C\\u0644 \\u0627\\u0644\\u062D\\u0636\\u0648\\u0631\n\n#XFLD: Column header for activity\nTSA_ACTIVITY=\\u0627\\u0644\\u0646\\u0634\\u0627\\u0637\n\n#XFLD: Column header for date\nTSA_DATE=\\u0627\\u0644\\u062A\\u0627\\u0631\\u064A\\u062E\n\n#XTIT: Details  for time entry notes.\nTSA_DETAILS=\\u062A\\u0641\\u0627\\u0635\\u064A\\u0644\n\n#XTIT: Title for list of rejection reasons\nTSA_TIT_REJECTION_REASON=\\u0633\\u0628\\u0628 \\u0627\\u0644\\u0631\\u0641\\u0636\n\n#XTIT: Message for Approval confirmation\nTSA_APR_CONF=\\u0647\\u0644 \\u062A\\u0631\\u064A\\u062F \\u0627\\u0639\\u062A\\u0645\\u0627\\u062F \\u0627\\u0644\\u0625\\u062F\\u062E\\u0627\\u0644 \\u0627\\u0644\\u0645\\u062D\\u062F\\u062F \\u0644\\u0640\n\n#XTIT: Message for Approvals confirmation\nTSA_APRS_CONF=\\u0647\\u0644 \\u062A\\u0631\\u064A\\u062F \\u0627\\u0639\\u062A\\u0645\\u0627\\u062F \\u0627\\u0644\\u0625\\u062F\\u062E\\u0627\\u0644\\u0627\\u062A \\u0627\\u0644\\u0645\\u062D\\u062F\\u062F\\u0629 \\u0644\\u0640\n\n#XTIT: Message for Rejection confirmation\nTSA_REJ_CONF=\\u0647\\u0644 \\u062A\\u0631\\u064A\\u062F \\u0631\\u0641\\u0636 \\u0627\\u0644\\u0625\\u062F\\u062E\\u0627\\u0644 \\u0627\\u0644\\u0645\\u062D\\u062F\\u062F \\u0644\\u0640\n\n#XTIT: Message for Rejection confirmation\nTSA_REJS_CONF=\\u0647\\u0644 \\u062A\\u0631\\u064A\\u062F \\u0631\\u0641\\u0636 \\u0627\\u0644\\u0625\\u062F\\u062E\\u0627\\u0644\\u0627\\u062A \\u0627\\u0644\\u0645\\u062D\\u062F\\u062F\\u0629 \\u0644\\u0640\n\n#XTIT: title for submit confirmation\nTSA_CONF_HEADER=\\u062A\\u0623\\u0643\\u064A\\u062F\n\n#XFLD: Text for multiple weeks\nTSA_WEEKS=\\u0623\\u0633\\u0628\\u0648\\u0639/\\u0623\\u0633\\u0627\\u0628\\u064A\\u0639\n\n#XFLD: Text for week\nTSA_WEEK=\\u0627\\u0644\\u0623\\u0633\\u0628\\u0648\\u0639\n\n#XFLD: Recorded Time for employee.\nTSA_TIME_RECORDED=\\u0645\\u0633\\u062C\\u064E\\u0644\n\n#XFLD: Notes for time entry.\nTSA_NOTES=\\u0645\\u0644\\u0627\\u062D\\u0638\\u0627\\u062A\n\n#XFLD: Over weeks.\nTSA_OVER=\\u0645\\u062A\\u062C\\u0627\\u0648\\u0632\n\n#XFLD: Wage Type for time entry.\nTSA_WAGE_TYPE=\\u0646\\u0648\\u0639 \\u0627\\u0644\\u0623\\u062C\\u0631\n\n#XTIT:Description\nTSA_DESCRIPTION=\\u0627\\u0644\\u0648\\u0635\\u0641\n\n#XTIT: More information\nTSA_INFO=\\u0645\\u0639\\u0644\\u0648\\u0645\\u0627\\u062A \\u0625\\u0636\\u0627\\u0641\\u064A\\u0629\n\n#XFLD: Hours for approval\nTSA_HRS_APPR=\\u0633\\u0627\\u0639\\u0627\\u062A \\u0627\\u0644\\u0627\\u0639\\u062A\\u0645\\u0627\\u062F\n\n#XFLD: For approval status\nTSA_STAT_FOR_APPR=\\u0644\\u0644\\u0627\\u0639\\u062A\\u0645\\u0627\\u062F\n\n#XFLD: Approved status\nTSA_STAT_APPROVED=\\u0645\\u0639\\u062A\\u0645\\u064E\\u062F\n\n#XFLD: Rejected status\nTSA_STAT_REJ=\\u0645\\u0631\\u0641\\u0648\\u0636\n\n#XFLD: Changed after approval\nTSA_STAT_CHANGED=\\u062A\\u0645 \\u0627\\u0644\\u062A\\u063A\\u064A\\u064A\\u0631 \\u0628\\u0639\\u062F \\u0627\\u0644\\u0627\\u0639\\u062A\\u0645\\u0627\\u062F\n\n#XTIT: Approval status header\nTSA_APPR_STATUS=\\u062D\\u0627\\u0644\\u0629 \\u0627\\u0644\\u0627\\u0639\\u062A\\u0645\\u0627\\u062F\n\n#XTIT: Past Entry\nTSA_PAST_ENTRY=\\u0625\\u062F\\u062E\\u0627\\u0644 \\u0633\\u0627\\u0628\\u0642\n\n#XFLD: Changed date\nTSA_CHANGED_DATETIME=\\u062A\\u0627\\u0631\\u064A\\u062E \\u0627\\u0644\\u062A\\u063A\\u064A\\u064A\\u0631\n\n#XFLD: Changed by\nTSA_CHANGED_BY=\\u062A\\u0645 \\u0627\\u0644\\u062A\\u063A\\u064A\\u064A\\u0631 \\u0628\\u0648\\u0627\\u0633\\u0637\\u0629\n\n# YMSG: No items are currently available\nNO_ITEMS_AVAILABLE=\\u0644\\u0627 \\u062A\\u062A\\u0648\\u0641\\u0631 \\u0623\\u064A\\u0629 \\u0639\\u0646\\u0627\\u0635\\u0631 \\u062D\\u0627\\u0644\\u064A\\u064B\\u0627\n',
	"hcm/approve/timesheet/i18n/i18n_bg.properties":'\n#XTIT:  Application name\nTSA_APP_TITLE=\\u041E\\u0434\\u043E\\u0431\\u0440\\u044F\\u0432\\u0430\\u043D\\u0435 \\u043D\\u0430 \\u0432\\u0440\\u0435\\u043C\\u0435\\u0432\\u0438 \\u0440\\u0430\\u0437\\u0447\\u0435\\u0442\\u0438\n\n#XTIT:  Application name\nMASTER_TITLE=\\u0412\\u0440\\u0435\\u043C\\u0435\\u0432\\u0438 \\u0440\\u0430\\u0437\\u0447\\u0435\\u0442\\u0438 ({0})\n\n#XTIT:  Application name\nTSA_APP=\\u0412\\u0440\\u0435\\u043C\\u0435\\u0432\\u0438 \\u0440\\u0430\\u0437\\u0447\\u0435\\u0442\n\n#XTIT: detail panel text\nDETAIL_TITLE=\\u0412\\u0440\\u0435\\u043C\\u0435\\u0432\\u0438 \\u0440\\u0430\\u0437\\u0447\\u0435\\u0442\n\n#XTIT: weekly target\nTSA_WEEKLY_TARGET=\\u0426\\u0435\\u043B\n\n#XBUT: Button Approve\nTSA_APPROVE=\\u041E\\u0434\\u043E\\u0431\\u0440\\u044F\\u0432.\n\n#XBUT: Button Reject\nTSA_REJECT=\\u041E\\u0442\\u0445\\u0432\\u044A\\u0440\\u043B\\u044F\\u043D\\u0435\n\n#XBUT: button to confirm submit\nTSA_ACCEPT=OK\n\n#XBUT: Button to Navigate back&nbsp;\\\\\\&nbsp;\nTSA_BACK=\\u041D\\u0430\\u0437\\u0430\\u0434\n\n#XFLD: No hours entered by the employee\nTSA_HOURS=\\u0427\\u0430\\u0441\\u043E\\u0432\\u0435\n\n#XFLD: Hour in short form.\nTSA_HOUR_SHORT=\\u0447\n\n#XFLD: Minutes in short form.\nTSA_MIN_SHORT=\\u043C\n\n#YMSG: Message for list service error\nLIST_SERVICE_ERR_MESSAGE=\\u041D\\u0435\\u0432\\u044A\\u0437\\u043C\\u043E\\u0436\\u043D\\u043E \\u043F\\u043E\\u043B\\u0443\\u0447\\u0430\\u0432\\u0430\\u043D\\u0435 \\u043D\\u0430 \\u0441\\u043F\\u0438\\u0441\\u044A\\u043A\\u0430 \\u0441\\u044A\\u0441 \\u0437\\u0430\\u043F\\u0438\\u0441\\u0438 \\u0432\\u044A\\u0432 \\u0432\\u0440\\u0435\\u043C\\u0435\\u0432\\u0438 \\u0440\\u0430\\u0437\\u0447\\u0435\\u0442\\u0438\n\n#YMSG: Message for Successful updation\nCATS_SUCCESS_MESSAGE=\\u0417\\u0430\\u043F\\u0438\\u0441\\u0438\\u0442\\u0435 \\u0432\\u044A\\u0432 \\u0432\\u0440\\u0435\\u043C\\u0435\\u0432\\u0438\\u0442\\u0435 \\u0440\\u0430\\u0437\\u0447\\u0435\\u0442\\u0438 \\u0441\\u0430 \\u0430\\u043A\\u0442\\u0443\\u0430\\u043B\\u0438\\u0437\\u0438\\u0440\\u0430\\u043D\\u0438\n\n#XFLD: Column header for activity\nTSA_ACTIVITY=\\u0414\\u0435\\u0439\\u043D\\u043E\\u0441\\u0442\n\n#XFLD: Column header for date\nTSA_DATE=\\u0414\\u0430\\u0442\\u0430\n\n#XTIT: Details  for time entry notes.\nTSA_DETAILS=\\u041F\\u043E\\u0434\\u0440\\u043E\\u0431\\u043D\\u0438 \\u0434\\u0430\\u043D\\u043D\\u0438\n\n#XTIT: Title for list of rejection reasons\nTSA_TIT_REJECTION_REASON=\\u041F\\u0440\\u0438\\u0447\\u0438\\u043D\\u0430 \\u0437\\u0430 \\u043E\\u0442\\u0445\\u0432\\u044A\\u0440\\u043B\\u044F\\u043D\\u0435\n\n#XTIT: Message for Approval confirmation\nTSA_APR_CONF=\\u0416\\u0435\\u043B\\u0430\\u0435\\u0442\\u0435 \\u043B\\u0438 \\u0434\\u0430 \\u043E\\u0434\\u043E\\u0431\\u0440\\u0438\\u0442\\u0435 \\u0438\\u0437\\u0431\\u0440\\u0430\\u043D\\u0438\\u044F \\u0437\\u0430\\u043F\\u0438\\u0441 \\u0437\\u0430\n\n#XTIT: Message for Approvals confirmation\nTSA_APRS_CONF=\\u0416\\u0435\\u043B\\u0430\\u0435\\u0442\\u0435 \\u043B\\u0438 \\u0434\\u0430 \\u043E\\u0434\\u043E\\u0431\\u0440\\u0438\\u0442\\u0435 \\u0438\\u0437\\u0431\\u0440\\u0430\\u043D\\u0438\\u0442\\u0435 \\u0437\\u0430\\u043F\\u0438\\u0441\\u0438 \\u0437\\u0430\n\n#XTIT: Message for Rejection confirmation\nTSA_REJ_CONF=\\u0416\\u0435\\u043B\\u0430\\u0435\\u0442\\u0435 \\u043B\\u0438 \\u0434\\u0430 \\u043E\\u0442\\u0445\\u0432\\u044A\\u0440\\u043B\\u0438\\u0442\\u0435 \\u0438\\u0437\\u0431\\u0440\\u0430\\u043D\\u0438\\u044F \\u0437\\u0430\\u043F\\u0438\\u0441 \\u0437\\u0430\n\n#XTIT: Message for Rejection confirmation\nTSA_REJS_CONF=\\u0416\\u0435\\u043B\\u0430\\u0435\\u0442\\u0435 \\u043B\\u0438 \\u0434\\u0430 \\u043E\\u0442\\u0445\\u0432\\u044A\\u0440\\u043B\\u0438\\u0442\\u0435 \\u0438\\u0437\\u0431\\u0440\\u0430\\u043D\\u0438\\u0442\\u0435 \\u0437\\u0430\\u043F\\u0438\\u0441\\u0438 \\u0437\\u0430\n\n#XTIT: title for submit confirmation\nTSA_CONF_HEADER=\\u041F\\u043E\\u0442\\u0432\\u044A\\u0440\\u0436\\u0434\\u0435\\u043D\\u0438\\u0435\n\n#XFLD: Text for multiple weeks\nTSA_WEEKS=\\u0421\\u0435\\u0434\\u043C\\u0438\\u0446\\u0438\n\n#XFLD: Text for week\nTSA_WEEK=\\u0421\\u0435\\u0434\\u043C\\u0438\\u0446\\u0430\n\n#XFLD: Recorded Time for employee.\nTSA_TIME_RECORDED=\\u0417\\u0430\\u043F\\u0438\\u0441\\u0430\\u043D\n\n#XFLD: Notes for time entry.\nTSA_NOTES=\\u0411\\u0435\\u043B\\u0435\\u0436\\u043A\\u0438\n\n#XFLD: Over weeks.\nTSA_OVER=\\u041D\\u0430\\u0434\n\n#XFLD: Wage Type for time entry.\nTSA_WAGE_TYPE=\\u0412\\u0438\\u0434 \\u0437\\u0430\\u043F\\u043B\\u0430\\u0449\\u0430\\u043D\\u0435\n\n#XTIT:Description\nTSA_DESCRIPTION=\\u041E\\u043F\\u0438\\u0441\\u0430\\u043D\\u0438\\u0435\n\n#XTIT: More information\nTSA_INFO=\\u041F\\u043E\\u0432\\u0435\\u0447\\u0435 \\u0438\\u043D\\u0444\\u043E\\u0440\\u043C\\u0430\\u0446\\u0438\\u044F\n\n#XFLD: Hours for approval\nTSA_HRS_APPR=\\u0427\\u0430\\u0441\\u043E\\u0432\\u0435 \\u0437\\u0430 \\u043E\\u0434\\u043E\\u0431\\u0440\\u0435\\u043D\\u0438\\u0435\n\n#XFLD: For approval status\nTSA_STAT_FOR_APPR=\\u0417\\u0430 \\u043E\\u0434\\u043E\\u0431\\u0440\\u0435\\u043D\\u0438\\u0435\n\n#XFLD: Approved status\nTSA_STAT_APPROVED=\\u041E\\u0434\\u043E\\u0431\\u0440\\u0435\\u043D\n\n#XFLD: Rejected status\nTSA_STAT_REJ=\\u041E\\u0442\\u0445\\u0432\\u044A\\u0440\\u043B\\u0435\\u043D\n\n#XFLD: Changed after approval\nTSA_STAT_CHANGED=\\u041F\\u0440\\u043E\\u043C\\u0435\\u043D\\u0435\\u043D \\u0441\\u043B\\u0435\\u0434 \\u043E\\u0434\\u043E\\u0431\\u0440\\u0435\\u043D\\u0438\\u0435\n\n#XTIT: Approval status header\nTSA_APPR_STATUS=\\u0421\\u0442\\u0430\\u0442\\u0443\\u0441 \\u043D\\u0430 \\u043E\\u0434\\u043E\\u0431\\u0440\\u0435\\u043D\\u0438\\u0435\n\n#XTIT: Past Entry\nTSA_PAST_ENTRY=\\u041C\\u0438\\u043D\\u0430\\u043B \\u0437\\u0430\\u043F\\u0438\\u0441\n\n#XFLD: Changed date\nTSA_CHANGED_DATETIME=\\u041F\\u0440\\u043E\\u043C\\u0435\\u043D\\u0435\\u043D \\u043D\\u0430\n\n#XFLD: Changed by\nTSA_CHANGED_BY=\\u041F\\u0440\\u043E\\u043C\\u0435\\u043D\\u0435\\u043D \\u043E\\u0442\n\n# YMSG: No items are currently available\nNO_ITEMS_AVAILABLE=\\u0412 \\u043C\\u043E\\u043C\\u0435\\u043D\\u0442\\u0430 \\u043D\\u044F\\u043C\\u0430 \\u043D\\u0430\\u043B\\u0438\\u0447\\u043D\\u0438 \\u043F\\u043E\\u0437\\u0438\\u0446\\u0438\\u0438\n',
	"hcm/approve/timesheet/i18n/i18n_cs.properties":'\n#XTIT:  Application name\nTSA_APP_TITLE=Schvalov\\u00E1n\\u00ED evidence \\u010Dasu\n\n#XTIT:  Application name\nMASTER_TITLE=Pracovn\\u00ED v\\u00FDkazy ({0})\n\n#XTIT:  Application name\nTSA_APP=Evidence \\u010Dasu\n\n#XTIT: detail panel text\nDETAIL_TITLE=Evidence \\u010Dasu\n\n#XTIT: weekly target\nTSA_WEEKLY_TARGET=C\\u00EDl\n\n#XBUT: Button Approve\nTSA_APPROVE=Schv\\u00E1lit\n\n#XBUT: Button Reject\nTSA_REJECT=Zam\\u00EDtnout\n\n#XBUT: button to confirm submit\nTSA_ACCEPT=OK\n\n#XBUT: Button to Navigate back&nbsp;\\\\\\&nbsp;\nTSA_BACK=Zp\\u011Bt\n\n#XFLD: No hours entered by the employee\nTSA_HOURS=Hodiny\n\n#XFLD: Hour in short form.\nTSA_HOUR_SHORT=h\n\n#XFLD: Minutes in short form.\nTSA_MIN_SHORT=min.\n\n#YMSG: Message for list service error\nLIST_SERVICE_ERR_MESSAGE=Nelze z\\u00EDskat seznam z\\u00E1znam\\u016F evidence \\u010Dasu\n\n#YMSG: Message for Successful updation\nCATS_SUCCESS_MESSAGE=Polo\\u017Eky evidence \\u010Dasu aktualizov\\u00E1ny\n\n#XFLD: Column header for activity\nTSA_ACTIVITY=\\u010Cinnost\n\n#XFLD: Column header for date\nTSA_DATE=Datum\n\n#XTIT: Details  for time entry notes.\nTSA_DETAILS=Detaily\n\n#XTIT: Title for list of rejection reasons\nTSA_TIT_REJECTION_REASON=D\\u016Fvod zam\\u00EDtnut\\u00ED\n\n#XTIT: Message for Approval confirmation\nTSA_APR_CONF=Chcete schv\\u00E1lit vybran\\u00FD z\\u00E1znam pro\n\n#XTIT: Message for Approvals confirmation\nTSA_APRS_CONF=Chcete schv\\u00E1lit vybran\\u00E9 z\\u00E1znamy pro\n\n#XTIT: Message for Rejection confirmation\nTSA_REJ_CONF=Chcete zam\\u00EDtnout vybran\\u00FD z\\u00E1znam pro\n\n#XTIT: Message for Rejection confirmation\nTSA_REJS_CONF=Chcete zam\\u00EDtnout vybran\\u00E9 z\\u00E1znamy pro\n\n#XTIT: title for submit confirmation\nTSA_CONF_HEADER=Potvrzen\\u00ED\n\n#XFLD: Text for multiple weeks\nTSA_WEEKS=T\\u00FDdny\n\n#XFLD: Text for week\nTSA_WEEK=T\\u00FDden\n\n#XFLD: Recorded Time for employee.\nTSA_TIME_RECORDED=Zaznamen\\u00E1no\n\n#XFLD: Notes for time entry.\nTSA_NOTES=Pozn\\u00E1mky\n\n#XFLD: Over weeks.\nTSA_OVER=P\\u0159es\n\n#XFLD: Wage Type for time entry.\nTSA_WAGE_TYPE=Typ mzdy\n\n#XTIT:Description\nTSA_DESCRIPTION=Popis\n\n#XTIT: More information\nTSA_INFO=Dal\\u0161\\u00ED informace\n\n#XFLD: Hours for approval\nTSA_HRS_APPR=Hodiny ke schv\\u00E1len\\u00ED\n\n#XFLD: For approval status\nTSA_STAT_FOR_APPR=Ke schv\\u00E1len\\u00ED\n\n#XFLD: Approved status\nTSA_STAT_APPROVED=Schv\\u00E1leno\n\n#XFLD: Rejected status\nTSA_STAT_REJ=Zam\\u00EDtnuto\n\n#XFLD: Changed after approval\nTSA_STAT_CHANGED=Zm\\u011Bn\\u011Bno po schv\\u00E1len\\u00ED\n\n#XTIT: Approval status header\nTSA_APPR_STATUS=Stav schvalov\\u00E1n\\u00ED\n\n#XTIT: Past Entry\nTSA_PAST_ENTRY=Minul\\u00FD z\\u00E1znam\n\n#XFLD: Changed date\nTSA_CHANGED_DATETIME=Zm\\u011Bn\\u011Bno\n\n#XFLD: Changed by\nTSA_CHANGED_BY=Zm\\u011Bnil(a)\n\n# YMSG: No items are currently available\nNO_ITEMS_AVAILABLE=Aktu\\u00E1ln\\u011B nejsou k dispozici \\u017E\\u00E1dn\\u00E9 polo\\u017Eky\n',
	"hcm/approve/timesheet/i18n/i18n_de.properties":'\n#XTIT:  Application name\nTSA_APP_TITLE=Erfasste Zeiten genehmigen\n\n#XTIT:  Application name\nMASTER_TITLE=Arbeitszeitbl\\u00E4tter ({0})\n\n#XTIT:  Application name\nTSA_APP=Arbeitszeitblatt\n\n#XTIT: detail panel text\nDETAIL_TITLE=Arbeitszeitblatt\n\n#XTIT: weekly target\nTSA_WEEKLY_TARGET=Ziel\n\n#XBUT: Button Approve\nTSA_APPROVE=Genehmigen\n\n#XBUT: Button Reject\nTSA_REJECT=Ablehnen\n\n#XBUT: button to confirm submit\nTSA_ACCEPT=OK\n\n#XBUT: Button to Navigate back&nbsp;\\\\\\&nbsp;\nTSA_BACK=Zur\\u00FCck\n\n#XFLD: No hours entered by the employee\nTSA_HOURS=Stunden\n\n#XFLD: Hour in short form.\nTSA_HOUR_SHORT=Std.\n\n#XFLD: Minutes in short form.\nTSA_MIN_SHORT=Min.\n\n#YMSG: Message for list service error\nLIST_SERVICE_ERR_MESSAGE=Zeiteintr\\u00E4ge k\\u00F6nnen nicht abgerufen werden\n\n#YMSG: Message for Successful updation\nCATS_SUCCESS_MESSAGE=Zeiteintr\\u00E4ge aktualisiert\n\n#XFLD: Column header for activity\nTSA_ACTIVITY=T\\u00E4tigkeit\n\n#XFLD: Column header for date\nTSA_DATE=Datum\n\n#XTIT: Details  for time entry notes.\nTSA_DETAILS=Details\n\n#XTIT: Title for list of rejection reasons\nTSA_TIT_REJECTION_REASON=Ablehnungsgrund\n\n#XTIT: Message for Approval confirmation\nTSA_APR_CONF=M\\u00F6chten Sie den ausgew\\u00E4hlten Eintrag genehmigen f\\u00FCr\n\n#XTIT: Message for Approvals confirmation\nTSA_APRS_CONF=M\\u00F6chten Sie die ausgew\\u00E4hlten Eintr\\u00E4ge genehmigen f\\u00FCr\n\n#XTIT: Message for Rejection confirmation\nTSA_REJ_CONF=M\\u00F6chten Sie den ausgew\\u00E4hlten Eintrag ablehnen f\\u00FCr\n\n#XTIT: Message for Rejection confirmation\nTSA_REJS_CONF=M\\u00F6chten Sie die ausgew\\u00E4hlten Eintr\\u00E4ge ablehnen f\\u00FCr\n\n#XTIT: title for submit confirmation\nTSA_CONF_HEADER=Best\\u00E4tigung\n\n#XFLD: Text for multiple weeks\nTSA_WEEKS=Wochen\n\n#XFLD: Text for week\nTSA_WEEK=Woche\n\n#XFLD: Recorded Time for employee.\nTSA_TIME_RECORDED=Erfasst\n\n#XFLD: Notes for time entry.\nTSA_NOTES=Notizen\n\n#XFLD: Over weeks.\nTSA_OVER=\\u00FCberschritten\n\n#XFLD: Wage Type for time entry.\nTSA_WAGE_TYPE=Lohnart\n\n#XTIT:Description\nTSA_DESCRIPTION=Beschreibung\n\n#XTIT: More information\nTSA_INFO=Weitere Informationen\n\n#XFLD: Hours for approval\nTSA_HRS_APPR=Zu genehmigende Stunden\n\n#XFLD: For approval status\nTSA_STAT_FOR_APPR=Zu genehmigen\n\n#XFLD: Approved status\nTSA_STAT_APPROVED=Genehmigt\n\n#XFLD: Rejected status\nTSA_STAT_REJ=Abgelehnt\n\n#XFLD: Changed after approval\nTSA_STAT_CHANGED=Nach Genehmigung ge\\u00E4ndert\n\n#XTIT: Approval status header\nTSA_APPR_STATUS=Genehmigungsstatus\n\n#XTIT: Past Entry\nTSA_PAST_ENTRY=Alter Eintrag\n\n#XFLD: Changed date\nTSA_CHANGED_DATETIME=Ge\\u00E4ndert am\n\n#XFLD: Changed by\nTSA_CHANGED_BY=Ge\\u00E4ndert von\n\n# YMSG: No items are currently available\nNO_ITEMS_AVAILABLE=Derzeit sind keine \\u00C4nderungen verf\\u00FCgbar\n',
	"hcm/approve/timesheet/i18n/i18n_en.properties":'\n#XTIT:  Application name\nTSA_APP_TITLE=Approve Timesheets\n\n#XTIT:  Application name\nMASTER_TITLE=Timesheets ({0})\n\n#XTIT:  Application name\nTSA_APP=Timesheet\n\n#XTIT: detail panel text\nDETAIL_TITLE=Timesheet\n\n#XTIT: weekly target\nTSA_WEEKLY_TARGET=Target\n\n#XBUT: Button Approve\nTSA_APPROVE=Approve\n\n#XBUT: Button Reject\nTSA_REJECT=Reject\n\n#XBUT: button to confirm submit\nTSA_ACCEPT=OK\n\n#XBUT: Button to Navigate back&nbsp;\\\\\\&nbsp;\nTSA_BACK=Back\n\n#XFLD: No hours entered by the employee\nTSA_HOURS=Hours\n\n#XFLD: Hour in short form.\nTSA_HOUR_SHORT=h\n\n#XFLD: Minutes in short form.\nTSA_MIN_SHORT=m\n\n#YMSG: Message for list service error\nLIST_SERVICE_ERR_MESSAGE=Could not obtain the list of timesheet entries\n\n#YMSG: Message for Successful updation\nCATS_SUCCESS_MESSAGE=Timesheet entries updated\n\n#XFLD: Column header for activity\nTSA_ACTIVITY=Activity\n\n#XFLD: Column header for date\nTSA_DATE=Date\n\n#XTIT: Details  for time entry notes.\nTSA_DETAILS=Details\n\n#XTIT: Title for list of rejection reasons\nTSA_TIT_REJECTION_REASON=Rejection Reason\n\n#XTIT: Message for Approval confirmation\nTSA_APR_CONF=Do you want to approve the selected entry for\n\n#XTIT: Message for Approvals confirmation\nTSA_APRS_CONF=Do you want to approve the selected entries for\n\n#XTIT: Message for Rejection confirmation\nTSA_REJ_CONF=Do you want to reject the selected entry for\n\n#XTIT: Message for Rejection confirmation\nTSA_REJS_CONF=Do you want to reject the selected entries for\n\n#XTIT: title for submit confirmation\nTSA_CONF_HEADER=Confirmation\n\n#XFLD: Text for multiple weeks\nTSA_WEEKS=Weeks\n\n#XFLD: Text for week\nTSA_WEEK=Week\n\n#XFLD: Recorded Time for employee.\nTSA_TIME_RECORDED=Recorded\n\n#XFLD: Notes for time entry.\nTSA_NOTES=Notes\n\n#XFLD: Over weeks.\nTSA_OVER=Over\n\n#XFLD: Wage Type for time entry.\nTSA_WAGE_TYPE=Wage Type\n\n#XTIT:Description\nTSA_DESCRIPTION=Description\n\n#XTIT: More information\nTSA_INFO=More Info\n\n#XFLD: Hours for approval\nTSA_HRS_APPR=Hours for Approval\n\n#XFLD: For approval status\nTSA_STAT_FOR_APPR=For Approval\n\n#XFLD: Approved status\nTSA_STAT_APPROVED=Approved\n\n#XFLD: Rejected status\nTSA_STAT_REJ=Rejected\n\n#XFLD: Changed after approval\nTSA_STAT_CHANGED=Changed After Approval\n\n#XTIT: Approval status header\nTSA_APPR_STATUS=Approval Status\n\n#XTIT: Past Entry\nTSA_PAST_ENTRY=Past Entry\n\n#XFLD: Changed date\nTSA_CHANGED_DATETIME=Changed On\n\n#XFLD: Changed by\nTSA_CHANGED_BY=Changed By\n\n# YMSG: No items are currently available\nNO_ITEMS_AVAILABLE=No items currently available\n',
	"hcm/approve/timesheet/i18n/i18n_en_US_sappsd.properties":'\n#XTIT:  Application name\nTSA_APP_TITLE=[[[\\u0100\\u03C1\\u03C1\\u0157\\u014F\\u028B\\u0113 \\u0162\\u012F\\u0271\\u0113\\u015F\\u0125\\u0113\\u0113\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XTIT:  Application name\nMASTER_TITLE=[[[\\u0162\\u012F\\u0271\\u0113\\u015F\\u0125\\u0113\\u0113\\u0163\\u015F ({0})]]]\n\n#XTIT:  Application name\nTSA_APP=[[[\\u0162\\u012F\\u0271\\u0113\\u015F\\u0125\\u0113\\u0113\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XTIT: detail panel text\nDETAIL_TITLE=[[[\\u0162\\u012F\\u0271\\u0113\\u015F\\u0125\\u0113\\u0113\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XTIT: weekly target\nTSA_WEEKLY_TARGET=[[[\\u0162\\u0105\\u0157\\u011F\\u0113\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XBUT: Button Approve\nTSA_APPROVE=[[[\\u0100\\u03C1\\u03C1\\u0157\\u014F\\u028B\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XBUT: Button Reject\nTSA_REJECT=[[[\\u0158\\u0113\\u0135\\u0113\\u010B\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XBUT: button to confirm submit\nTSA_ACCEPT=[[[\\u014E\\u0136\\u2219\\u2219]]]\n\n#XBUT: Button to Navigate back&nbsp;\\\\\\&nbsp;\nTSA_BACK=[[[\\u0181\\u0105\\u010B\\u0137]]]\n\n#XFLD: No hours entered by the employee\nTSA_HOURS=[[[\\u0124\\u014F\\u0171\\u0157\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XFLD: Hour in short form.\nTSA_HOUR_SHORT=[[[\\u0125\\u2219\\u2219\\u2219]]]\n\n#XFLD: Minutes in short form.\nTSA_MIN_SHORT=[[[\\u0271\\u2219\\u2219\\u2219]]]\n\n#YMSG: Message for list service error\nLIST_SERVICE_ERR_MESSAGE=[[[\\u0108\\u014F\\u0171\\u013A\\u018C \\u014B\\u014F\\u0163 \\u014F\\u0183\\u0163\\u0105\\u012F\\u014B \\u0163\\u0125\\u0113 \\u013A\\u012F\\u015F\\u0163 \\u014F\\u0192 \\u0163\\u012F\\u0271\\u0113\\u015F\\u0125\\u0113\\u0113\\u0163 \\u0113\\u014B\\u0163\\u0157\\u012F\\u0113\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#YMSG: Message for Successful updation\nCATS_SUCCESS_MESSAGE=[[[\\u0162\\u012F\\u0271\\u0113\\u015F\\u0125\\u0113\\u0113\\u0163 \\u0113\\u014B\\u0163\\u0157\\u012F\\u0113\\u015F \\u0171\\u03C1\\u018C\\u0105\\u0163\\u0113\\u018C\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XFLD: Column header for activity\nTSA_ACTIVITY=[[[\\u0100\\u010B\\u0163\\u012F\\u028B\\u012F\\u0163\\u0177\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XFLD: Column header for date\nTSA_DATE=[[[\\u010E\\u0105\\u0163\\u0113]]]\n\n#XTIT: Details  for time entry notes.\nTSA_DETAILS=[[[\\u010E\\u0113\\u0163\\u0105\\u012F\\u013A\\u015F \\u0192\\u014F\\u0157\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XTIT: Title for list of rejection reasons\nTSA_TIT_REJECTION_REASON=[[[\\u0158\\u0113\\u0135\\u0113\\u010B\\u0163\\u012F\\u014F\\u014B \\u0158\\u0113\\u0105\\u015F\\u014F\\u014B\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XTIT: Message for Approval confirmation\nTSA_APR_CONF=[[[\\u010E\\u014F \\u0177\\u014F\\u0171 \\u0175\\u0105\\u014B\\u0163 \\u0163\\u014F \\u0105\\u03C1\\u03C1\\u0157\\u014F\\u028B\\u0113 \\u0163\\u0125\\u0113 \\u015F\\u0113\\u013A\\u0113\\u010B\\u0163\\u0113\\u018C \\u0113\\u014B\\u0163\\u0157\\u0177 \\u0192\\u014F\\u0157\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XTIT: Message for Approvals confirmation\nTSA_APRS_CONF=[[[\\u010E\\u014F \\u0177\\u014F\\u0171 \\u0175\\u0105\\u014B\\u0163 \\u0163\\u014F \\u0105\\u03C1\\u03C1\\u0157\\u014F\\u028B\\u0113 \\u0163\\u0125\\u0113 \\u015F\\u0113\\u013A\\u0113\\u010B\\u0163\\u0113\\u018C \\u0113\\u014B\\u0163\\u0157\\u012F\\u0113\\u015F \\u0192\\u014F\\u0157\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XTIT: Message for Rejection confirmation\nTSA_REJ_CONF=[[[\\u010E\\u014F \\u0177\\u014F\\u0171 \\u0175\\u0105\\u014B\\u0163 \\u0163\\u014F \\u0157\\u0113\\u0135\\u0113\\u010B\\u0163 \\u0163\\u0125\\u0113 \\u015F\\u0113\\u013A\\u0113\\u010B\\u0163\\u0113\\u018C \\u0113\\u014B\\u0163\\u0157\\u0177 \\u0192\\u014F\\u0157\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XTIT: Message for Rejection confirmation\nTSA_REJS_CONF=[[[\\u010E\\u014F \\u0177\\u014F\\u0171 \\u0175\\u0105\\u014B\\u0163 \\u0163\\u014F \\u0157\\u0113\\u0135\\u0113\\u010B\\u0163 \\u0163\\u0125\\u0113 \\u015F\\u0113\\u013A\\u0113\\u010B\\u0163\\u0113\\u018C \\u0113\\u014B\\u0163\\u0157\\u012F\\u0113\\u015F \\u0192\\u014F\\u0157\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XTIT: title for submit confirmation\nTSA_CONF_HEADER=[[[\\u0108\\u014F\\u014B\\u0192\\u012F\\u0157\\u0271\\u0105\\u0163\\u012F\\u014F\\u014B\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XFLD: Text for multiple weeks\nTSA_WEEKS=[[[\\u0174\\u0113\\u0113\\u0137\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XFLD: Text for week\nTSA_WEEK=[[[\\u0174\\u0113\\u0113\\u0137]]]\n\n#XFLD: Recorded Time for employee.\nTSA_TIME_RECORDED=[[[\\u0158\\u0113\\u010B\\u014F\\u0157\\u018C\\u0113\\u018C\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XFLD: Notes for time entry.\nTSA_NOTES=[[[\\u0143\\u014F\\u0163\\u0113\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XFLD: Over weeks.\nTSA_OVER=[[[\\u014E\\u028B\\u0113\\u0157]]]\n\n#XFLD: Wage Type for time entry.\nTSA_WAGE_TYPE=[[[\\u0174\\u0105\\u011F\\u0113 \\u0162\\u0177\\u03C1\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XTIT:Description\nTSA_DESCRIPTION=[[[\\u010E\\u0113\\u015F\\u010B\\u0157\\u012F\\u03C1\\u0163\\u012F\\u014F\\u014B\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XTIT: More information\nTSA_INFO=[[[\\u039C\\u014F\\u0157\\u0113 \\u012C\\u014B\\u0192\\u014F\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XFLD: Hours for approval\nTSA_HRS_APPR=[[[\\u0124\\u014F\\u0171\\u0157\\u015F \\u0192\\u014F\\u0157 \\u0105\\u03C1\\u03C1\\u0157\\u014F\\u028B\\u0105\\u013A\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XFLD: For approval status\nTSA_STAT_FOR_APPR=[[[\\u0191\\u014F\\u0157 \\u0100\\u03C1\\u03C1\\u0157\\u014F\\u028B\\u0105\\u013A\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XFLD: Approved status\nTSA_STAT_APPROVED=[[[\\u0100\\u03C1\\u03C1\\u0157\\u014F\\u028B\\u0113\\u018C\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XFLD: Rejected status\nTSA_STAT_REJ=[[[\\u0158\\u0113\\u0135\\u0113\\u010B\\u0163\\u0113\\u018C\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XFLD: Changed after approval\nTSA_STAT_CHANGED=[[[\\u0108\\u0125\\u0105\\u014B\\u011F\\u0113\\u018C \\u0105\\u0192\\u0163\\u0113\\u0157 \\u0105\\u03C1\\u03C1\\u0157\\u014F\\u028B\\u0105\\u013A\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XTIT: Approval status header\nTSA_APPR_STATUS=[[[\\u0100\\u03C1\\u03C1\\u0157\\u014F\\u028B\\u0105\\u013A \\u015F\\u0163\\u0105\\u0163\\u0171\\u015F\\u2219\\u2219\\u2219\\u2219]]]\n\n#XTIT: Past Entry\nTSA_PAST_ENTRY=[[[\\u01A4\\u0105\\u015F\\u0163 \\u0114\\u014B\\u0163\\u0157\\u0177\\u2219\\u2219\\u2219\\u2219]]]\n\n#XFLD: Changed date\nTSA_CHANGED_DATETIME=[[[\\u0108\\u0125\\u0105\\u014B\\u011F\\u0113\\u018C \\u014F\\u014B\\u2219\\u2219\\u2219\\u2219]]]\n\n#XFLD: Changed by\nTSA_CHANGED_BY=[[[\\u0108\\u0125\\u0105\\u014B\\u011F\\u0113\\u018C \\u0183\\u0177\\u2219\\u2219\\u2219\\u2219]]]\n\n# YMSG: No items are currently available\nNO_ITEMS_AVAILABLE=[[[\\u0143\\u014F \\u012F\\u0163\\u0113\\u0271\\u015F \\u0105\\u0157\\u0113 \\u010B\\u0171\\u0157\\u0157\\u0113\\u014B\\u0163\\u013A\\u0177 \\u0105\\u028B\\u0105\\u012F\\u013A\\u0105\\u0183\\u013A\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n',
	"hcm/approve/timesheet/i18n/i18n_en_US_saptrc.properties":'\n#XTIT:  Application name\nTSA_APP_TITLE=yc/JBs+xk0lnfnHL7QX0kQ_Approve Timesheets\n\n#XTIT:  Application name\nMASTER_TITLE=lhOXMqX/S6gpRIAPgaMYWA_Timesheets ({0})\n\n#XTIT:  Application name\nTSA_APP=1/ftIHWi0QaiJdCmrAXE0w_Timesheet\n\n#XTIT: detail panel text\nDETAIL_TITLE=deltf4LSMw/aOjhfdVCALg_Timesheet\n\n#XTIT: weekly target\nTSA_WEEKLY_TARGET=7Z4/VVEh0YRTrEjLkR79cw_Target\n\n#XBUT: Button Approve\nTSA_APPROVE=SPQ2fdSHGAjqtpmaaTNKNw_Approve\n\n#XBUT: Button Reject\nTSA_REJECT=yBDeu5PQo1ic4QsB4tXQ4w_Reject\n\n#XBUT: button to confirm submit\nTSA_ACCEPT=jH+a22K+LuGrguEwBbYmBg_OK\n\n#XBUT: Button to Navigate back&nbsp;\\\\\\&nbsp;\nTSA_BACK=BtR9WWXWTkXgGuAyyD4VJg_Back\n\n#XFLD: No hours entered by the employee\nTSA_HOURS=pXMVAeiWK+C3kJex7UZoLA_Hours\n\n#XFLD: Hour in short form.\nTSA_HOUR_SHORT=7G2asK4JRjmQxJOCeYp/RA_h\n\n#XFLD: Minutes in short form.\nTSA_MIN_SHORT=h29729d7jl4JzRgvOhZhmA_m\n\n#YMSG: Message for list service error\nLIST_SERVICE_ERR_MESSAGE=/pZoFM/PeNursSyeNuEiVg_Could not obtain the list of timesheet entries\n\n#YMSG: Message for Successful updation\nCATS_SUCCESS_MESSAGE=81skpfZxinGKRRn85ONgMg_Timesheet entries updated\n\n#XFLD: Column header for activity\nTSA_ACTIVITY=7QwugaI2eLq50ZxHPVwGDA_Activity\n\n#XFLD: Column header for date\nTSA_DATE=6LRc7icL7AA/diUQ4W+aKA_Date\n\n#XTIT: Details  for time entry notes.\nTSA_DETAILS=bcDUfT6n/Wyf64GyVrpbLQ_Details for\n\n#XTIT: Title for list of rejection reasons\nTSA_TIT_REJECTION_REASON=s+eEFyTDXNnrTkZlPyCkZA_Rejection Reason\n\n#XTIT: Message for Approval confirmation\nTSA_APR_CONF=ckiXRbkIPwdOnTscrFLd0g_Do you want to approve the selected entry for\n\n#XTIT: Message for Approvals confirmation\nTSA_APRS_CONF=s0lgy8BiB+3O+tEFXApN8w_Do you want to approve the selected entries for\n\n#XTIT: Message for Rejection confirmation\nTSA_REJ_CONF=mckPkC5gx18Cl+Scn9vTQQ_Do you want to reject the selected entry for\n\n#XTIT: Message for Rejection confirmation\nTSA_REJS_CONF=H7Szy0XgUwKCtMnd+h8Tzw_Do you want to reject the selected entries for\n\n#XTIT: title for submit confirmation\nTSA_CONF_HEADER=VywRyhSF2WPKqGsTK/xtIQ_Confirmation\n\n#XFLD: Text for multiple weeks\nTSA_WEEKS=PEPswyXY4Cic6gBMoCNHbw_Weeks\n\n#XFLD: Text for week\nTSA_WEEK=xjk4LqBcfPUMAJBCTxgkKg_Week\n\n#XFLD: Recorded Time for employee.\nTSA_TIME_RECORDED=vor1E+lvJWoBFAeuFcHXHg_Recorded\n\n#XFLD: Notes for time entry.\nTSA_NOTES=Lqd/rXUH2W/UCX+q119/bQ_Notes\n\n#XFLD: Over weeks.\nTSA_OVER=qhKd8B8xJ2FwHZRsjrywvA_Over\n\n#XFLD: Wage Type for time entry.\nTSA_WAGE_TYPE=dOT0Gvpy4j5aYzH0JcjUxg_Wage Type\n\n#XTIT:Description\nTSA_DESCRIPTION=kUGh+NvPQIHqX5rwui4TWA_Description\n\n#XTIT: More information\nTSA_INFO=S9FyUNpItsrYfDkPmGMT7Q_More Info\n\n#XFLD: Hours for approval\nTSA_HRS_APPR=iciPtrCDP8kLdPTJZ+CkEA_Hours for approval\n\n#XFLD: For approval status\nTSA_STAT_FOR_APPR=Q4O94VZjS6jBg2AbN8cV7g_For Approval\n\n#XFLD: Approved status\nTSA_STAT_APPROVED=ubTUway2wW3amfAXQ1q43g_Approved\n\n#XFLD: Rejected status\nTSA_STAT_REJ=O50awKxIRCoB9wnN4wgPPQ_Rejected\n\n#XFLD: Changed after approval\nTSA_STAT_CHANGED=YfHiRZELQSCl2/RJcCWNNg_Changed after approval\n\n#XTIT: Approval status header\nTSA_APPR_STATUS=jwyRUbDKfHnKuZzYLnFDlA_Approval status\n\n#XTIT: Past Entry\nTSA_PAST_ENTRY=4scR0HQRAf2+W+uWWo22Hw_Past Entry\n\n#XFLD: Changed date\nTSA_CHANGED_DATETIME=3ifqysrWJdhgSLDf2eRbyA_Changed on\n\n#XFLD: Changed by\nTSA_CHANGED_BY=AFaefxnx3BuF38X9hsdQ7Q_Changed by\n\n# YMSG: No items are currently available\nNO_ITEMS_AVAILABLE=un5aEv4q1MJVmMWKNtoFdg_No items are currently available\n',
	"hcm/approve/timesheet/i18n/i18n_es.properties":'\n#XTIT:  Application name\nTSA_APP_TITLE=Aprobaci\\u00F3n de registros de tiempos\n\n#XTIT:  Application name\nMASTER_TITLE=Registros de tiempos ({0})\n\n#XTIT:  Application name\nTSA_APP=Registro de tiempos\n\n#XTIT: detail panel text\nDETAIL_TITLE=Registro de tiempos\n\n#XTIT: weekly target\nTSA_WEEKLY_TARGET=Objetivo\n\n#XBUT: Button Approve\nTSA_APPROVE=Autorizar\n\n#XBUT: Button Reject\nTSA_REJECT=Rechazar\n\n#XBUT: button to confirm submit\nTSA_ACCEPT=Aceptar\n\n#XBUT: Button to Navigate back&nbsp;\\\\\\&nbsp;\nTSA_BACK=Atr\\u00E1s\n\n#XFLD: No hours entered by the employee\nTSA_HOURS=Horas\n\n#XFLD: Hour in short form.\nTSA_HOUR_SHORT=h\n\n#XFLD: Minutes in short form.\nTSA_MIN_SHORT=m\n\n#YMSG: Message for list service error\nLIST_SERVICE_ERR_MESSAGE=No se ha podido obtener la lista de entradas del registro de tiempos\n\n#YMSG: Message for Successful updation\nCATS_SUCCESS_MESSAGE=Entradas del registro de tiempos actualizadas\n\n#XFLD: Column header for activity\nTSA_ACTIVITY=Actividad\n\n#XFLD: Column header for date\nTSA_DATE=Fecha\n\n#XTIT: Details  for time entry notes.\nTSA_DETAILS=Detalles\n\n#XTIT: Title for list of rejection reasons\nTSA_TIT_REJECTION_REASON=Motivo de rechazo\n\n#XTIT: Message for Approval confirmation\nTSA_APR_CONF=Desea autorizar la entrada seleccionada para\n\n#XTIT: Message for Approvals confirmation\nTSA_APRS_CONF=Desea autorizar las entradas seleccionadas para\n\n#XTIT: Message for Rejection confirmation\nTSA_REJ_CONF=Desea rechazar la entrada seleccionada para\n\n#XTIT: Message for Rejection confirmation\nTSA_REJS_CONF=Desea autorizar las entradas seleccionadas para\n\n#XTIT: title for submit confirmation\nTSA_CONF_HEADER=Confirmaci\\u00F3n\n\n#XFLD: Text for multiple weeks\nTSA_WEEKS=Semanas\n\n#XFLD: Text for week\nTSA_WEEK=Semana\n\n#XFLD: Recorded Time for employee.\nTSA_TIME_RECORDED=Grabado\n\n#XFLD: Notes for time entry.\nTSA_NOTES=Notas\n\n#XFLD: Over weeks.\nTSA_OVER=por encima\n\n#XFLD: Wage Type for time entry.\nTSA_WAGE_TYPE=Clase de salario\n\n#XTIT:Description\nTSA_DESCRIPTION=Descripci\\u00F3n\n\n#XTIT: More information\nTSA_INFO=M\\u00E1s informaci\\u00F3n\n\n#XFLD: Hours for approval\nTSA_HRS_APPR=Horas para la autorizaci\\u00F3n\n\n#XFLD: For approval status\nTSA_STAT_FOR_APPR=Para autorizaci\\u00F3n\n\n#XFLD: Approved status\nTSA_STAT_APPROVED=Autorizado\n\n#XFLD: Rejected status\nTSA_STAT_REJ=Rechazadas\n\n#XFLD: Changed after approval\nTSA_STAT_CHANGED=Modificado despu\\u00E9s de autorizaci\\u00F3n\n\n#XTIT: Approval status header\nTSA_APPR_STATUS=Estado de autorizaci\\u00F3n\n\n#XTIT: Past Entry\nTSA_PAST_ENTRY=Entrada anterior\n\n#XFLD: Changed date\nTSA_CHANGED_DATETIME=Fecha de modificaci\\u00F3n\n\n#XFLD: Changed by\nTSA_CHANGED_BY=Modificado por\n\n# YMSG: No items are currently available\nNO_ITEMS_AVAILABLE=No hay posiciones disponibles actualmente\n',
	"hcm/approve/timesheet/i18n/i18n_fr.properties":'\n#XTIT:  Application name\nTSA_APP_TITLE=Approbation de feuilles de saisie des temps\n\n#XTIT:  Application name\nMASTER_TITLE=Feuilles de saisie des temps ({0})\n\n#XTIT:  Application name\nTSA_APP=Feuille de saisie des temps\n\n#XTIT: detail panel text\nDETAIL_TITLE=Feuille de saisie des temps\n\n#XTIT: weekly target\nTSA_WEEKLY_TARGET=Cible\n\n#XBUT: Button Approve\nTSA_APPROVE=Approuver\n\n#XBUT: Button Reject\nTSA_REJECT=Rejeter\n\n#XBUT: button to confirm submit\nTSA_ACCEPT=OK\n\n#XBUT: Button to Navigate back&nbsp;\\\\\\&nbsp;\nTSA_BACK=Retour\n\n#XFLD: No hours entered by the employee\nTSA_HOURS=Heures\n\n#XFLD: Hour in short form.\nTSA_HOUR_SHORT=h\n\n#XFLD: Minutes in short form.\nTSA_MIN_SHORT=m\n\n#YMSG: Message for list service error\nLIST_SERVICE_ERR_MESSAGE=Impossible d\'acc\\u00E9der \\u00E0 la liste des entr\\u00E9es de la feuille de saisie des temps\n\n#YMSG: Message for Successful updation\nCATS_SUCCESS_MESSAGE=Entr\\u00E9es de la feuille de saisie des temps mises \\u00E0 jour\n\n#XFLD: Column header for activity\nTSA_ACTIVITY=Activit\\u00E9\n\n#XFLD: Column header for date\nTSA_DATE=Date\n\n#XTIT: Details  for time entry notes.\nTSA_DETAILS=D\\u00E9tails\n\n#XTIT: Title for list of rejection reasons\nTSA_TIT_REJECTION_REASON=Motif du rejet\n\n#XTIT: Message for Approval confirmation\nTSA_APR_CONF=Voulez-vous approuver l\'entr\\u00E9e s\\u00E9lectionn\\u00E9e pour\n\n#XTIT: Message for Approvals confirmation\nTSA_APRS_CONF=Voulez-vous approuver les entr\\u00E9es s\\u00E9lectionn\\u00E9es pour\n\n#XTIT: Message for Rejection confirmation\nTSA_REJ_CONF=Voulez-vous rejeter l\'entr\\u00E9e s\\u00E9lectionn\\u00E9e pour\n\n#XTIT: Message for Rejection confirmation\nTSA_REJS_CONF=Voulez-vous rejeter les entr\\u00E9es s\\u00E9lectionn\\u00E9es pour\n\n#XTIT: title for submit confirmation\nTSA_CONF_HEADER=Confirmation\n\n#XFLD: Text for multiple weeks\nTSA_WEEKS=Semaines\n\n#XFLD: Text for week\nTSA_WEEK=Semaine\n\n#XFLD: Recorded Time for employee.\nTSA_TIME_RECORDED=Enregistr\\u00E9\n\n#XFLD: Notes for time entry.\nTSA_NOTES=Notes\n\n#XFLD: Over weeks.\nTSA_OVER=Plus de\n\n#XFLD: Wage Type for time entry.\nTSA_WAGE_TYPE=Rubrique\n\n#XTIT:Description\nTSA_DESCRIPTION=Description\n\n#XTIT: More information\nTSA_INFO=Plus d\'infos\n\n#XFLD: Hours for approval\nTSA_HRS_APPR=Heures \\u00E0 approuver\n\n#XFLD: For approval status\nTSA_STAT_FOR_APPR=\\u00C0 approuver\n\n#XFLD: Approved status\nTSA_STAT_APPROVED=Approuv\\u00E9\n\n#XFLD: Rejected status\nTSA_STAT_REJ=Rejet\\u00E9\n\n#XFLD: Changed after approval\nTSA_STAT_CHANGED=Modifi\\u00E9 apr\\u00E8s approbation\n\n#XTIT: Approval status header\nTSA_APPR_STATUS=Statut d\'approbation\n\n#XTIT: Past Entry\nTSA_PAST_ENTRY=Entr\\u00E9e ancienne\n\n#XFLD: Changed date\nTSA_CHANGED_DATETIME=Modifi\\u00E9 le\n\n#XFLD: Changed by\nTSA_CHANGED_BY=Modifi\\u00E9 par\n\n# YMSG: No items are currently available\nNO_ITEMS_AVAILABLE=Aucun \\u00E9l\\u00E9ment disponible actuellement.\n',
	"hcm/approve/timesheet/i18n/i18n_hr.properties":'\n#XTIT:  Application name\nTSA_APP_TITLE=Odobri bilje\\u017Eenja vremena\n\n#XTIT:  Application name\nMASTER_TITLE=Liste za bilje\\u017Eenje radnog vremena ({0})\n\n#XTIT:  Application name\nTSA_APP=Lista za bilje\\u017Eenje radnog vrm\n\n#XTIT: detail panel text\nDETAIL_TITLE=Lista za bilje\\u017Eenje radnog vrm\n\n#XTIT: weekly target\nTSA_WEEKLY_TARGET=Cilj\n\n#XBUT: Button Approve\nTSA_APPROVE=Odobri\n\n#XBUT: Button Reject\nTSA_REJECT=Odbij\n\n#XBUT: button to confirm submit\nTSA_ACCEPT=OK\n\n#XBUT: Button to Navigate back&nbsp;\\\\\\&nbsp;\nTSA_BACK=Natrag\n\n#XFLD: No hours entered by the employee\nTSA_HOURS=Sati\n\n#XFLD: Hour in short form.\nTSA_HOUR_SHORT=h\n\n#XFLD: Minutes in short form.\nTSA_MIN_SHORT=m\n\n#YMSG: Message for list service error\nLIST_SERVICE_ERR_MESSAGE=Nije bilo mogu\\u0107e dobiti listu vremenskih unosa\n\n#YMSG: Message for Successful updation\nCATS_SUCCESS_MESSAGE=Unosi liste za bilje\\u017Eenje radnog vremena a\\u017Eurirani\n\n#XFLD: Column header for activity\nTSA_ACTIVITY=Aktivnost\n\n#XFLD: Column header for date\nTSA_DATE=Datum\n\n#XTIT: Details  for time entry notes.\nTSA_DETAILS=Detalji\n\n#XTIT: Title for list of rejection reasons\nTSA_TIT_REJECTION_REASON=Razlog odbijanja\n\n#XTIT: Message for Approval confirmation\nTSA_APR_CONF=\\u017Delite li odobriti odabrani unos za\n\n#XTIT: Message for Approvals confirmation\nTSA_APRS_CONF=\\u017Delite li odobriti odabrane unose za\n\n#XTIT: Message for Rejection confirmation\nTSA_REJ_CONF=\\u017Delite li odbiti odabrani unos za\n\n#XTIT: Message for Rejection confirmation\nTSA_REJS_CONF=\\u017Delite li odbiti odabrane unose za\n\n#XTIT: title for submit confirmation\nTSA_CONF_HEADER=Potvrda\n\n#XFLD: Text for multiple weeks\nTSA_WEEKS=Tjedni\n\n#XFLD: Text for week\nTSA_WEEK=Tjedan\n\n#XFLD: Recorded Time for employee.\nTSA_TIME_RECORDED=Zabilje\\u017Eeno\n\n#XFLD: Notes for time entry.\nTSA_NOTES=Bilje\\u0161ke\n\n#XFLD: Over weeks.\nTSA_OVER=Preko\n\n#XFLD: Wage Type for time entry.\nTSA_WAGE_TYPE=Tip elementa pla\\u0107e\n\n#XTIT:Description\nTSA_DESCRIPTION=Opis\n\n#XTIT: More information\nTSA_INFO=Vi\\u0161e informacija\n\n#XFLD: Hours for approval\nTSA_HRS_APPR=Sati za odobrenje\n\n#XFLD: For approval status\nTSA_STAT_FOR_APPR=Za odobrenje\n\n#XFLD: Approved status\nTSA_STAT_APPROVED=Odobreno\n\n#XFLD: Rejected status\nTSA_STAT_REJ=Odbijeno\n\n#XFLD: Changed after approval\nTSA_STAT_CHANGED=Promijenjeno nakon odobrenja\n\n#XTIT: Approval status header\nTSA_APPR_STATUS=Status odobrenja\n\n#XTIT: Past Entry\nTSA_PAST_ENTRY=Pro\\u0161li unos\n\n#XFLD: Changed date\nTSA_CHANGED_DATETIME=Datum promjene\n\n#XFLD: Changed by\nTSA_CHANGED_BY=Promijenio\n\n# YMSG: No items are currently available\nNO_ITEMS_AVAILABLE=Stavke trenutno nisu raspolo\\u017Eive\n',
	"hcm/approve/timesheet/i18n/i18n_hu.properties":'\n#XTIT:  Application name\nTSA_APP_TITLE=Id\\u0151adatlapok enged\\u00E9lyez\\u00E9se\n\n#XTIT:  Application name\nMASTER_TITLE=Id\\u0151adatlapok ({0})\n\n#XTIT:  Application name\nTSA_APP=Id\\u0151adatlap\n\n#XTIT: detail panel text\nDETAIL_TITLE=Id\\u0151adatlap\n\n#XTIT: weekly target\nTSA_WEEKLY_TARGET=C\\u00E9l\n\n#XBUT: Button Approve\nTSA_APPROVE=J\\u00F3v\\u00E1hagy\\u00E1s\n\n#XBUT: Button Reject\nTSA_REJECT=Elutas\\u00EDt\\u00E1s\n\n#XBUT: button to confirm submit\nTSA_ACCEPT=Rendben\n\n#XBUT: Button to Navigate back&nbsp;\\\\\\&nbsp;\nTSA_BACK=Vissza\n\n#XFLD: No hours entered by the employee\nTSA_HOURS=\\u00F3ra\n\n#XFLD: Hour in short form.\nTSA_HOUR_SHORT=\\u00F3\n\n#XFLD: Minutes in short form.\nTSA_MIN_SHORT=p\n\n#YMSG: Message for list service error\nLIST_SERVICE_ERR_MESSAGE=Nem siker\\u00FClt lek\\u00E9rni az id\\u0151adatlap-bejegyz\\u00E9sek list\\u00E1j\\u00E1t\n\n#YMSG: Message for Successful updation\nCATS_SUCCESS_MESSAGE=Id\\u0151adatlap-bejegyz\\u00E9sek aktualiz\\u00E1lva\n\n#XFLD: Column header for activity\nTSA_ACTIVITY=Tev\\u00E9kenys\\u00E9g\n\n#XFLD: Column header for date\nTSA_DATE=D\\u00E1tum\n\n#XTIT: Details  for time entry notes.\nTSA_DETAILS=R\\u00E9szletek\n\n#XTIT: Title for list of rejection reasons\nTSA_TIT_REJECTION_REASON=Elutas\\u00EDt\\u00E1s indoka\n\n#XTIT: Message for Approval confirmation\nTSA_APR_CONF=Szeretn\\u00E9 enged\\u00E9lyezni a kiv\\u00E1lasztott bejegyz\\u00E9st -\n\n#XTIT: Message for Approvals confirmation\nTSA_APRS_CONF=Szeretn\\u00E9 enged\\u00E9lyezni a kiv\\u00E1lasztott bejegyz\\u00E9seket -\n\n#XTIT: Message for Rejection confirmation\nTSA_REJ_CONF=Szeretn\\u00E9 visszautas\\u00EDtani a kiv\\u00E1lasztott bejegyz\\u00E9st -\n\n#XTIT: Message for Rejection confirmation\nTSA_REJS_CONF=Szeretn\\u00E9 visszautas\\u00EDtani a kiv\\u00E1lasztott bejegyz\\u00E9seket -\n\n#XTIT: title for submit confirmation\nTSA_CONF_HEADER=Visszaigazol\\u00E1s\n\n#XFLD: Text for multiple weeks\nTSA_WEEKS=H\\u00E9t\n\n#XFLD: Text for week\nTSA_WEEK=H\\u00E9t\n\n#XFLD: Recorded Time for employee.\nTSA_TIME_RECORDED=R\\u00F6gz\\u00EDtett\n\n#XFLD: Notes for time entry.\nTSA_NOTES=Jegyzetek\n\n#XFLD: Over weeks.\nTSA_OVER=T\\u00FAll\\u00E9p\\u00E9s\n\n#XFLD: Wage Type for time entry.\nTSA_WAGE_TYPE=B\\u00E9rfajta\n\n#XTIT:Description\nTSA_DESCRIPTION=Le\\u00EDr\\u00E1s\n\n#XTIT: More information\nTSA_INFO=Tov\\u00E1bbi inform\\u00E1ci\\u00F3k\n\n#XFLD: Hours for approval\nTSA_HRS_APPR=Engelyezend\\u0151 \\u00F3r\\u00E1k\n\n#XFLD: For approval status\nTSA_STAT_FOR_APPR=Enged\\u00E9lyezend\\u0151\n\n#XFLD: Approved status\nTSA_STAT_APPROVED=Enged\\u00E9lyezve\n\n#XFLD: Rejected status\nTSA_STAT_REJ=Elutas\\u00EDtva\n\n#XFLD: Changed after approval\nTSA_STAT_CHANGED=M\\u00F3dos\\u00EDtva enged\\u00E9lyez\\u00E9s ut\\u00E1n\n\n#XTIT: Approval status header\nTSA_APPR_STATUS=Enged\\u00E9lyez\\u00E9sst\\u00E1tus\n\n#XTIT: Past Entry\nTSA_PAST_ENTRY=Kor\\u00E1bbi bejegyz\\u00E9s\n\n#XFLD: Changed date\nTSA_CHANGED_DATETIME=M\\u00F3dos\\u00EDt\\u00E1s d\\u00E1tuma\\:\n\n#XFLD: Changed by\nTSA_CHANGED_BY=M\\u00F3dos\\u00EDtotta\\:\n\n# YMSG: No items are currently available\nNO_ITEMS_AVAILABLE=Jelenleg nincsenek el\\u00E9rhet\\u0151 t\\u00E9telek\n',
	"hcm/approve/timesheet/i18n/i18n_it.properties":'\n#XTIT:  Application name\nTSA_APP_TITLE=Approva timesheets\n\n#XTIT:  Application name\nMASTER_TITLE=Timesheets ({0})\n\n#XTIT:  Application name\nTSA_APP=Timesheet\n\n#XTIT: detail panel text\nDETAIL_TITLE=Timesheet\n\n#XTIT: weekly target\nTSA_WEEKLY_TARGET=Obiettivo\n\n#XBUT: Button Approve\nTSA_APPROVE=Approva\n\n#XBUT: Button Reject\nTSA_REJECT=Rifiuta\n\n#XBUT: button to confirm submit\nTSA_ACCEPT=OK\n\n#XBUT: Button to Navigate back&nbsp;\\\\\\&nbsp;\nTSA_BACK=Indietro\n\n#XFLD: No hours entered by the employee\nTSA_HOURS=Ore\n\n#XFLD: Hour in short form.\nTSA_HOUR_SHORT=h\n\n#XFLD: Minutes in short form.\nTSA_MIN_SHORT=m\n\n#YMSG: Message for list service error\nLIST_SERVICE_ERR_MESSAGE=Impossibile ottenere la lista di inserimenti timesheet\n\n#YMSG: Message for Successful updation\nCATS_SUCCESS_MESSAGE=Inserimenti timesheet aggiornati\n\n#XFLD: Column header for activity\nTSA_ACTIVITY=Attivit\\u00E0\n\n#XFLD: Column header for date\nTSA_DATE=Data\n\n#XTIT: Details  for time entry notes.\nTSA_DETAILS=Dettagli\n\n#XTIT: Title for list of rejection reasons\nTSA_TIT_REJECTION_REASON=Motivo rifiuto\n\n#XTIT: Message for Approval confirmation\nTSA_APR_CONF=Approvare l\'inserimento selezionato per\n\n#XTIT: Message for Approvals confirmation\nTSA_APRS_CONF=Approvare gli inserimenti selezionati per\n\n#XTIT: Message for Rejection confirmation\nTSA_REJ_CONF=Rifiutare l\'inserimento selezionato per\n\n#XTIT: Message for Rejection confirmation\nTSA_REJS_CONF=Rifiutare gli inserimenti selezionati per\n\n#XTIT: title for submit confirmation\nTSA_CONF_HEADER=Conferma\n\n#XFLD: Text for multiple weeks\nTSA_WEEKS=Settimane\n\n#XFLD: Text for week\nTSA_WEEK=Settimana\n\n#XFLD: Recorded Time for employee.\nTSA_TIME_RECORDED=Registrato\n\n#XFLD: Notes for time entry.\nTSA_NOTES=Note\n\n#XFLD: Over weeks.\nTSA_OVER=Sopra\n\n#XFLD: Wage Type for time entry.\nTSA_WAGE_TYPE=Voce retributiva\n\n#XTIT:Description\nTSA_DESCRIPTION=Descrizione\n\n#XTIT: More information\nTSA_INFO=Altre informazioni\n\n#XFLD: Hours for approval\nTSA_HRS_APPR=Ore per l\'approvazione\n\n#XFLD: For approval status\nTSA_STAT_FOR_APPR=Per approvazione\n\n#XFLD: Approved status\nTSA_STAT_APPROVED=Approvato\n\n#XFLD: Rejected status\nTSA_STAT_REJ=Rifiutato\n\n#XFLD: Changed after approval\nTSA_STAT_CHANGED=Modificato dopo approvazione\n\n#XTIT: Approval status header\nTSA_APPR_STATUS=Stato approvazione\n\n#XTIT: Past Entry\nTSA_PAST_ENTRY=Inserimento precedente\n\n#XFLD: Changed date\nTSA_CHANGED_DATETIME=Data di modifica\n\n#XFLD: Changed by\nTSA_CHANGED_BY=Autore modifica\n\n# YMSG: No items are currently available\nNO_ITEMS_AVAILABLE=Nessuna posizione attualmente disponibile\n',
	"hcm/approve/timesheet/i18n/i18n_iw.properties":'\n#XTIT:  Application name\nTSA_APP_TITLE=\\u05D0\\u05E9\\u05E8 \\u05D2\\u05D9\\u05DC\\u05D9\\u05D5\\u05E0\\u05D5\\u05EA \\u05E9\\u05E2\\u05D5\\u05EA\n\n#XTIT:  Application name\nMASTER_TITLE=\\u05D2\\u05D9\\u05DC\\u05D9\\u05D5\\u05E0\\u05D5\\u05EA \\u05E9\\u05E2\\u05D5\\u05EA ({0})\n\n#XTIT:  Application name\nTSA_APP=\\u05D2\\u05D9\\u05DC\\u05D9\\u05D5\\u05DF \\u05E9\\u05E2\\u05D5\\u05EA\n\n#XTIT: detail panel text\nDETAIL_TITLE=\\u05D2\\u05D9\\u05DC\\u05D9\\u05D5\\u05DF \\u05E9\\u05E2\\u05D5\\u05EA\n\n#XTIT: weekly target\nTSA_WEEKLY_TARGET=\\u05D9\\u05E2\\u05D3\n\n#XBUT: Button Approve\nTSA_APPROVE=\\u05D0\\u05E9\\u05E8\n\n#XBUT: Button Reject\nTSA_REJECT=\\u05D3\\u05D7\\u05D4\n\n#XBUT: button to confirm submit\nTSA_ACCEPT=OK\n\n#XBUT: Button to Navigate back&nbsp;\\\\\\&nbsp;\nTSA_BACK=\\u05D7\\u05D6\\u05D5\\u05E8\n\n#XFLD: No hours entered by the employee\nTSA_HOURS=\\u05E9\\u05E2\\u05D5\\u05EA\n\n#XFLD: Hour in short form.\nTSA_HOUR_SHORT=\\u05E9\n\n#XFLD: Minutes in short form.\nTSA_MIN_SHORT=\\u05D3\n\n#YMSG: Message for list service error\nLIST_SERVICE_ERR_MESSAGE=\\u05DC\\u05D0 \\u05E0\\u05D9\\u05EA\\u05DF \\u05D4\\u05D9\\u05D4 \\u05DC\\u05D4\\u05E9\\u05D9\\u05D2 \\u05D0\\u05EA \\u05E8\\u05E9\\u05D9\\u05DE\\u05EA \\u05D4\\u05D4\\u05D6\\u05E0\\u05D5\\u05EA \\u05E9\\u05DC \\u05D2\\u05D9\\u05DC\\u05D9\\u05D5\\u05DF \\u05D4\\u05E9\\u05E2\\u05D5\\u05EA\n\n#YMSG: Message for Successful updation\nCATS_SUCCESS_MESSAGE=\\u05D4\\u05D4\\u05D6\\u05E0\\u05D5\\u05EA \\u05E9\\u05DC \\u05D2\\u05D9\\u05DC\\u05D9\\u05D5\\u05DF \\u05D4\\u05E9\\u05E2\\u05D5\\u05EA \\u05E2\\u05D5\\u05D3\\u05DB\\u05E0\\u05D5\n\n#XFLD: Column header for activity\nTSA_ACTIVITY=\\u05E4\\u05E2\\u05D9\\u05DC\\u05D5\\u05EA\n\n#XFLD: Column header for date\nTSA_DATE=\\u05EA\\u05D0\\u05E8\\u05D9\\u05DA\n\n#XTIT: Details  for time entry notes.\nTSA_DETAILS=\\u05E4\\u05E8\\u05D8\\u05D9\\u05DD\n\n#XTIT: Title for list of rejection reasons\nTSA_TIT_REJECTION_REASON=\\u05E1\\u05D9\\u05D1\\u05D4 \\u05DC\\u05D3\\u05D7\\u05D9\\u05D9\\u05D4\n\n#XTIT: Message for Approval confirmation\nTSA_APR_CONF=\\u05D4\\u05D0\\u05DD \\u05D1\\u05E8\\u05E6\\u05D5\\u05E0\\u05DA \\u05DC\\u05D0\\u05E9\\u05E8 \\u05D0\\u05EA \\u05D4\\u05D4\\u05D6\\u05E0\\u05D4 \\u05E9\\u05E0\\u05D1\\u05D7\\u05E8\\u05D4 \\u05E2\\u05D1\\u05D5\\u05E8\n\n#XTIT: Message for Approvals confirmation\nTSA_APRS_CONF=\\u05D4\\u05D0\\u05DD \\u05D1\\u05E8\\u05E6\\u05D5\\u05E0\\u05DA \\u05DC\\u05D0\\u05E9\\u05E8 \\u05D0\\u05EA \\u05D4\\u05D4\\u05D6\\u05E0\\u05D5\\u05EA \\u05E9\\u05E0\\u05D1\\u05D7\\u05E8\\u05D5 \\u05E2\\u05D1\\u05D5\\u05E8\n\n#XTIT: Message for Rejection confirmation\nTSA_REJ_CONF=\\u05D4\\u05D0\\u05DD \\u05D1\\u05E8\\u05E6\\u05D5\\u05E0\\u05DA \\u05DC\\u05D3\\u05D7\\u05D5\\u05EA \\u05D0\\u05EA \\u05D4\\u05D4\\u05D6\\u05E0\\u05D4 \\u05E9\\u05E0\\u05D1\\u05D7\\u05E8\\u05D4 \\u05E2\\u05D1\\u05D5\\u05E8\n\n#XTIT: Message for Rejection confirmation\nTSA_REJS_CONF=\\u05D4\\u05D0\\u05DD \\u05D1\\u05E8\\u05E6\\u05D5\\u05E0\\u05DA \\u05DC\\u05D3\\u05D7\\u05D5\\u05EA \\u05D0\\u05EA \\u05D4\\u05D4\\u05D6\\u05E0\\u05D5\\u05EA \\u05E9\\u05E0\\u05D1\\u05D7\\u05E8\\u05D5 \\u05E2\\u05D1\\u05D5\\u05E8\n\n#XTIT: title for submit confirmation\nTSA_CONF_HEADER=\\u05D0\\u05D9\\u05E9\\u05D5\\u05E8\n\n#XFLD: Text for multiple weeks\nTSA_WEEKS=\\u05E9\\u05D1\\u05D5\\u05E2\\u05D5\\u05EA\n\n#XFLD: Text for week\nTSA_WEEK=\\u05E9\\u05D1\\u05D5\\u05E2\n\n#XFLD: Recorded Time for employee.\nTSA_TIME_RECORDED=\\u05E0\\u05E8\\u05E9\\u05DD\n\n#XFLD: Notes for time entry.\nTSA_NOTES=\\u05D4\\u05E2\\u05E8\\u05D5\\u05EA\n\n#XFLD: Over weeks.\nTSA_OVER=\\u05E0\\u05D5\\u05E1\\u05E4\\u05D9\\u05DD\n\n#XFLD: Wage Type for time entry.\nTSA_WAGE_TYPE=\\u05E8\\u05DB\\u05D9\\u05D1 \\u05E9\\u05DB\\u05E8\n\n#XTIT:Description\nTSA_DESCRIPTION=\\u05EA\\u05D9\\u05D0\\u05D5\\u05E8\n\n#XTIT: More information\nTSA_INFO=\\u05DE\\u05D9\\u05D3\\u05E2 \\u05E0\\u05D5\\u05E1\\u05E3\n\n#XFLD: Hours for approval\nTSA_HRS_APPR=\\u05E9\\u05E2\\u05D5\\u05EA \\u05DC\\u05D0\\u05D9\\u05E9\\u05D5\\u05E8\n\n#XFLD: For approval status\nTSA_STAT_FOR_APPR=\\u05DC\\u05D0\\u05D9\\u05E9\\u05D5\\u05E8\n\n#XFLD: Approved status\nTSA_STAT_APPROVED=\\u05D0\\u05D5\\u05E9\\u05E8\n\n#XFLD: Rejected status\nTSA_STAT_REJ=\\u05E0\\u05D3\\u05D7\\u05D4\n\n#XFLD: Changed after approval\nTSA_STAT_CHANGED=\\u05E9\\u05D5\\u05E0\\u05D4 \\u05DC\\u05D0\\u05D7\\u05E8 \\u05D0\\u05D9\\u05E9\\u05D5\\u05E8\n\n#XTIT: Approval status header\nTSA_APPR_STATUS=\\u05E1\\u05D8\\u05D0\\u05D8\\u05D5\\u05E1 \\u05D0\\u05D9\\u05E9\\u05D5\\u05E8\n\n#XTIT: Past Entry\nTSA_PAST_ENTRY=\\u05D4\\u05D6\\u05E0\\u05D4 \\u05E7\\u05D5\\u05D3\\u05DE\\u05EA\n\n#XFLD: Changed date\nTSA_CHANGED_DATETIME=\\u05E9\\u05D5\\u05E0\\u05D4 \\u05D1\\u05EA\\u05D0\\u05E8\\u05D9\\u05DA\n\n#XFLD: Changed by\nTSA_CHANGED_BY=\\u05E9\\u05D5\\u05E0\\u05D4 \\u05E2\\u05DC-\\u05D9\\u05D3\\u05D9\n\n# YMSG: No items are currently available\nNO_ITEMS_AVAILABLE=\\u05D0\\u05D9\\u05DF \\u05E4\\u05E8\\u05D9\\u05D8\\u05D9\\u05DD \\u05D6\\u05DE\\u05D9\\u05E0\\u05D9\\u05DD \\u05DB\\u05E8\\u05D2\\u05E2\n',
	"hcm/approve/timesheet/i18n/i18n_ja.properties":'\n#XTIT:  Application name\nTSA_APP_TITLE=\\u30BF\\u30A4\\u30E0\\u30B7\\u30FC\\u30C8\\u627F\\u8A8D\n\n#XTIT:  Application name\nMASTER_TITLE=\\u30BF\\u30A4\\u30E0\\u30B7\\u30FC\\u30C8 ({0})\n\n#XTIT:  Application name\nTSA_APP=\\u30BF\\u30A4\\u30E0\\u30B7\\u30FC\\u30C8\n\n#XTIT: detail panel text\nDETAIL_TITLE=\\u30BF\\u30A4\\u30E0\\u30B7\\u30FC\\u30C8\n\n#XTIT: weekly target\nTSA_WEEKLY_TARGET=\\u76EE\\u6A19\n\n#XBUT: Button Approve\nTSA_APPROVE=\\u627F\\u8A8D\n\n#XBUT: Button Reject\nTSA_REJECT=\\u5374\\u4E0B\n\n#XBUT: button to confirm submit\nTSA_ACCEPT=OK\n\n#XBUT: Button to Navigate back&nbsp;\\\\\\&nbsp;\nTSA_BACK=\\u524D\\u753B\\u9762\n\n#XFLD: No hours entered by the employee\nTSA_HOURS=\\u6642\\u9593\n\n#XFLD: Hour in short form.\nTSA_HOUR_SHORT=h\n\n#XFLD: Minutes in short form.\nTSA_MIN_SHORT=m\n\n#YMSG: Message for list service error\nLIST_SERVICE_ERR_MESSAGE=\\u30BF\\u30A4\\u30E0\\u30B7\\u30FC\\u30C8\\u5165\\u529B\\u306E\\u4E00\\u89A7\\u3092\\u53D6\\u5F97\\u3067\\u304D\\u307E\\u305B\\u3093\\u3067\\u3057\\u305F\n\n#YMSG: Message for Successful updation\nCATS_SUCCESS_MESSAGE=\\u30BF\\u30A4\\u30E0\\u30B7\\u30FC\\u30C8\\u5165\\u529B\\u304C\\u66F4\\u65B0\\u3055\\u308C\\u307E\\u3057\\u305F\n\n#XFLD: Column header for activity\nTSA_ACTIVITY=\\u6D3B\\u52D5\n\n#XFLD: Column header for date\nTSA_DATE=\\u65E5\\u4ED8\n\n#XTIT: Details  for time entry notes.\nTSA_DETAILS=\\u8A73\\u7D30\n\n#XTIT: Title for list of rejection reasons\nTSA_TIT_REJECTION_REASON=\\u5374\\u4E0B\\u7406\\u7531\n\n#XTIT: Message for Approval confirmation\nTSA_APR_CONF=\\u6B21\\u306E\\u9078\\u629E\\u3057\\u305F\\u5165\\u529B\\u3092\\u627F\\u8A8D\\u3057\\u307E\\u3059\\u304B\\uFF1F\\uFF1A\n\n#XTIT: Message for Approvals confirmation\nTSA_APRS_CONF=\\u9078\\u629E\\u3057\\u305F\\u5165\\u529B\\u3092\\u627F\\u8A8D\\u3057\\u307E\\u3059\\u304B\n\n#XTIT: Message for Rejection confirmation\nTSA_REJ_CONF=\\u6B21\\u306E\\u9078\\u629E\\u3057\\u305F\\u5165\\u529B\\u3092\\u5374\\u4E0B\\u3057\\u307E\\u3059\\u304B\\uFF1F\\uFF1A\n\n#XTIT: Message for Rejection confirmation\nTSA_REJS_CONF=\\u9078\\u629E\\u3057\\u305F\\u5165\\u529B\\u3092\\u5374\\u4E0B\\u3057\\u307E\\u3059\\u304B\n\n#XTIT: title for submit confirmation\nTSA_CONF_HEADER=\\u78BA\\u8A8D\n\n#XFLD: Text for multiple weeks\nTSA_WEEKS=\\u9031\n\n#XFLD: Text for week\nTSA_WEEK=\\u9031\n\n#XFLD: Recorded Time for employee.\nTSA_TIME_RECORDED=\\u8A18\\u9332\\u6E08\n\n#XFLD: Notes for time entry.\nTSA_NOTES=\\u30E1\\u30E2\n\n#XFLD: Over weeks.\nTSA_OVER=\\u8D85\\u904E\n\n#XFLD: Wage Type for time entry.\nTSA_WAGE_TYPE=\\u30A6\\u30A7\\u30A4\\u30B8\\u30BF\\u30A4\\u30D7\n\n#XTIT:Description\nTSA_DESCRIPTION=\\u30C6\\u30AD\\u30B9\\u30C8\n\n#XTIT: More information\nTSA_INFO=\\u8FFD\\u52A0\\u60C5\\u5831\n\n#XFLD: Hours for approval\nTSA_HRS_APPR=\\u627F\\u8A8D\\u5BFE\\u8C61\\u6642\\u9593\\u6570\n\n#XFLD: For approval status\nTSA_STAT_FOR_APPR=\\u627F\\u8A8D\\u5BFE\\u8C61\n\n#XFLD: Approved status\nTSA_STAT_APPROVED=\\u627F\\u8A8D\\u6E08\n\n#XFLD: Rejected status\nTSA_STAT_REJ=\\u5374\\u4E0B\\u6E08\n\n#XFLD: Changed after approval\nTSA_STAT_CHANGED=\\u627F\\u8A8D\\u5F8C\\u306B\\u5909\\u66F4\\u6E08\n\n#XTIT: Approval status header\nTSA_APPR_STATUS=\\u627F\\u8A8D\\u30B9\\u30C6\\u30FC\\u30BF\\u30B9\n\n#XTIT: Past Entry\nTSA_PAST_ENTRY=\\u904E\\u53BB\\u306E\\u5165\\u529B\n\n#XFLD: Changed date\nTSA_CHANGED_DATETIME=\\u5909\\u66F4\\u65E5\\u4ED8\n\n#XFLD: Changed by\nTSA_CHANGED_BY=\\u5909\\u66F4\\u8005\n\n# YMSG: No items are currently available\nNO_ITEMS_AVAILABLE=\\u73FE\\u5728\\u4F7F\\u7528\\u53EF\\u80FD\\u306A\\u30A2\\u30A4\\u30C6\\u30E0\\u304C\\u3042\\u308A\\u307E\\u305B\\u3093\n',
	"hcm/approve/timesheet/i18n/i18n_no.properties":'\n#XTIT:  Application name\nTSA_APP_TITLE=Godkjenn tidsregistreringer\n\n#XTIT:  Application name\nMASTER_TITLE=Tidsregistreringer ({0})\n\n#XTIT:  Application name\nTSA_APP=Tidsregistrering\n\n#XTIT: detail panel text\nDETAIL_TITLE=Tidsregistrering\n\n#XTIT: weekly target\nTSA_WEEKLY_TARGET=M\\u00E5l\n\n#XBUT: Button Approve\nTSA_APPROVE=Godkjenn\n\n#XBUT: Button Reject\nTSA_REJECT=Avvis\n\n#XBUT: button to confirm submit\nTSA_ACCEPT=OK\n\n#XBUT: Button to Navigate back&nbsp;\\\\\\&nbsp;\nTSA_BACK=Tilbake\n\n#XFLD: No hours entered by the employee\nTSA_HOURS=Timer\n\n#XFLD: Hour in short form.\nTSA_HOUR_SHORT=t\n\n#XFLD: Minutes in short form.\nTSA_MIN_SHORT=m\n\n#YMSG: Message for list service error\nLIST_SERVICE_ERR_MESSAGE=Kan ikke hente liste over tidsregistringer\n\n#YMSG: Message for Successful updation\nCATS_SUCCESS_MESSAGE=Tidsregistringer oppdatert\n\n#XFLD: Column header for activity\nTSA_ACTIVITY=Aktivitet\n\n#XFLD: Column header for date\nTSA_DATE=Dato\n\n#XTIT: Details  for time entry notes.\nTSA_DETAILS=Detaljer\n\n#XTIT: Title for list of rejection reasons\nTSA_TIT_REJECTION_REASON=Avvisningsgrunn\n\n#XTIT: Message for Approval confirmation\nTSA_APR_CONF=Vil du godkjenne den valgte registreringen for\n\n#XTIT: Message for Approvals confirmation\nTSA_APRS_CONF=Vil du godkjenne de valgte registreringene for\n\n#XTIT: Message for Rejection confirmation\nTSA_REJ_CONF=Vil du avvise den valgte registreringen for\n\n#XTIT: Message for Rejection confirmation\nTSA_REJS_CONF=Vil du avvise de valgte registreringene for\n\n#XTIT: title for submit confirmation\nTSA_CONF_HEADER=Bekreftelse\n\n#XFLD: Text for multiple weeks\nTSA_WEEKS=Uker\n\n#XFLD: Text for week\nTSA_WEEK=Uke\n\n#XFLD: Recorded Time for employee.\nTSA_TIME_RECORDED=Registrert\n\n#XFLD: Notes for time entry.\nTSA_NOTES=Merknader\n\n#XFLD: Over weeks.\nTSA_OVER=Over\n\n#XFLD: Wage Type for time entry.\nTSA_WAGE_TYPE=L\\u00F8nnart\n\n#XTIT:Description\nTSA_DESCRIPTION=Beskrivelse\n\n#XTIT: More information\nTSA_INFO=Mer info\n\n#XFLD: Hours for approval\nTSA_HRS_APPR=Timer til godkjenning\n\n#XFLD: For approval status\nTSA_STAT_FOR_APPR=Til godkjenning\n\n#XFLD: Approved status\nTSA_STAT_APPROVED=Godkjent\n\n#XFLD: Rejected status\nTSA_STAT_REJ=Avvist\n\n#XFLD: Changed after approval\nTSA_STAT_CHANGED=Endret etter godkjenning\n\n#XTIT: Approval status header\nTSA_APPR_STATUS=Godkjenningsstatus\n\n#XTIT: Past Entry\nTSA_PAST_ENTRY=Tidligere registrering\n\n#XFLD: Changed date\nTSA_CHANGED_DATETIME=Endret den\n\n#XFLD: Changed by\nTSA_CHANGED_BY=Endret av\n\n# YMSG: No items are currently available\nNO_ITEMS_AVAILABLE=Ingen posisjoner er tilgjengelige n\\u00E5\n',
	"hcm/approve/timesheet/i18n/i18n_pl.properties":'\n#XTIT:  Application name\nTSA_APP_TITLE=Zatwierdzanie czas\\u00F3w\n\n#XTIT:  Application name\nMASTER_TITLE=Arkusze czasu pracy ({0})\n\n#XTIT:  Application name\nTSA_APP=Arkusz czasu pracy\n\n#XTIT: detail panel text\nDETAIL_TITLE=Arkusz czasu pracy\n\n#XTIT: weekly target\nTSA_WEEKLY_TARGET=Cel\n\n#XBUT: Button Approve\nTSA_APPROVE=Zatwierd\\u017A\n\n#XBUT: Button Reject\nTSA_REJECT=Odrzu\\u0107\n\n#XBUT: button to confirm submit\nTSA_ACCEPT=OK\n\n#XBUT: Button to Navigate back&nbsp;\\\\\\&nbsp;\nTSA_BACK=Powr\\u00F3t\n\n#XFLD: No hours entered by the employee\nTSA_HOURS=Godziny\n\n#XFLD: Hour in short form.\nTSA_HOUR_SHORT=godz.\n\n#XFLD: Minutes in short form.\nTSA_MIN_SHORT=m\n\n#YMSG: Message for list service error\nLIST_SERVICE_ERR_MESSAGE=Nie mo\\u017Cna uzyska\\u0107 listy wpis\\u00F3w rejestracji czasu\n\n#YMSG: Message for Successful updation\nCATS_SUCCESS_MESSAGE=Zaktualizowano wpisy rejestracji czasu\n\n#XFLD: Column header for activity\nTSA_ACTIVITY=Czynno\\u015B\\u0107\n\n#XFLD: Column header for date\nTSA_DATE=Data\n\n#XTIT: Details  for time entry notes.\nTSA_DETAILS=Szczeg\\u00F3\\u0142y\n\n#XTIT: Title for list of rejection reasons\nTSA_TIT_REJECTION_REASON=Pow\\u00F3d odrzucenia\n\n#XTIT: Message for Approval confirmation\nTSA_APR_CONF=Czy chcesz zatwierdzi\\u0107 wybrany wpis dla\n\n#XTIT: Message for Approvals confirmation\nTSA_APRS_CONF=Czy chcesz zatwierdzi\\u0107 wybrane wpisy dla\n\n#XTIT: Message for Rejection confirmation\nTSA_REJ_CONF=Czy chcesz odrzuci\\u0107 wybrany wpis dla\n\n#XTIT: Message for Rejection confirmation\nTSA_REJS_CONF=Czy chcesz odrzuci\\u0107 wybrane wpisy dla\n\n#XTIT: title for submit confirmation\nTSA_CONF_HEADER=Potwierdzenie\n\n#XFLD: Text for multiple weeks\nTSA_WEEKS=Tygodnie\n\n#XFLD: Text for week\nTSA_WEEK=Tydzie\\u0144\n\n#XFLD: Recorded Time for employee.\nTSA_TIME_RECORDED=Zarejestrowano\n\n#XFLD: Notes for time entry.\nTSA_NOTES=Notatki\n\n#XFLD: Over weeks.\nTSA_OVER=Nadmiar\n\n#XFLD: Wage Type for time entry.\nTSA_WAGE_TYPE=Sk\\u0142adnik wynagrodzenia\n\n#XTIT:Description\nTSA_DESCRIPTION=Opis\n\n#XTIT: More information\nTSA_INFO=Dalsze informacje\n\n#XFLD: Hours for approval\nTSA_HRS_APPR=Godziny do zatwierdzenia\n\n#XFLD: For approval status\nTSA_STAT_FOR_APPR=Do zatwierdzenia\n\n#XFLD: Approved status\nTSA_STAT_APPROVED=Zatwierdzone\n\n#XFLD: Rejected status\nTSA_STAT_REJ=Odrzucone\n\n#XFLD: Changed after approval\nTSA_STAT_CHANGED=Zmieniono po zatwierdzeniu\n\n#XTIT: Approval status header\nTSA_APPR_STATUS=Status zatwierdzenia\n\n#XTIT: Past Entry\nTSA_PAST_ENTRY=Poprzedni wpis\n\n#XFLD: Changed date\nTSA_CHANGED_DATETIME=Zmieniono dnia\n\n#XFLD: Changed by\nTSA_CHANGED_BY=Zmienione przez\n\n# YMSG: No items are currently available\nNO_ITEMS_AVAILABLE=Obecnie brak dost\\u0119pnych pozycji\n',
	"hcm/approve/timesheet/i18n/i18n_pt.properties":'\n#XTIT:  Application name\nTSA_APP_TITLE=Aprovar folhas de horas\n\n#XTIT:  Application name\nMASTER_TITLE=Folhas de horas ({0})\n\n#XTIT:  Application name\nTSA_APP=Folha de horas de trabalho\n\n#XTIT: detail panel text\nDETAIL_TITLE=Folha de horas de trabalho\n\n#XTIT: weekly target\nTSA_WEEKLY_TARGET=Destino\n\n#XBUT: Button Approve\nTSA_APPROVE=Aprovar\n\n#XBUT: Button Reject\nTSA_REJECT=Rejeitar\n\n#XBUT: button to confirm submit\nTSA_ACCEPT=OK\n\n#XBUT: Button to Navigate back&nbsp;\\\\\\&nbsp;\nTSA_BACK=Voltar\n\n#XFLD: No hours entered by the employee\nTSA_HOURS=Horas\n\n#XFLD: Hour in short form.\nTSA_HOUR_SHORT=h\n\n#XFLD: Minutes in short form.\nTSA_MIN_SHORT=m\n\n#YMSG: Message for list service error\nLIST_SERVICE_ERR_MESSAGE=N\\u00E3o foi poss\\u00EDvel obter lista de entradas de folhas de horas\n\n#YMSG: Message for Successful updation\nCATS_SUCCESS_MESSAGE=Entradas de folhas de horas atualizadas\n\n#XFLD: Column header for activity\nTSA_ACTIVITY=Atividade\n\n#XFLD: Column header for date\nTSA_DATE=Data\n\n#XTIT: Details  for time entry notes.\nTSA_DETAILS=Detalhes\n\n#XTIT: Title for list of rejection reasons\nTSA_TIT_REJECTION_REASON=Motivo de rejei\\u00E7\\u00E3o\n\n#XTIT: Message for Approval confirmation\nTSA_APR_CONF=Aprovar a entrada selecionada para\n\n#XTIT: Message for Approvals confirmation\nTSA_APRS_CONF=Aprovar as entradas selecionadas para\n\n#XTIT: Message for Rejection confirmation\nTSA_REJ_CONF=Rejeitar a entrada selecionada para\n\n#XTIT: Message for Rejection confirmation\nTSA_REJS_CONF=Rejeitar as entradas selecionadas para\n\n#XTIT: title for submit confirmation\nTSA_CONF_HEADER=Confirma\\u00E7\\u00E3o\n\n#XFLD: Text for multiple weeks\nTSA_WEEKS=Semanas\n\n#XFLD: Text for week\nTSA_WEEK=Semana\n\n#XFLD: Recorded Time for employee.\nTSA_TIME_RECORDED=Registrado\n\n#XFLD: Notes for time entry.\nTSA_NOTES=Notas\n\n#XFLD: Over weeks.\nTSA_OVER=Mais de\n\n#XFLD: Wage Type for time entry.\nTSA_WAGE_TYPE=Tipo de sal\\u00E1rio\n\n#XTIT:Description\nTSA_DESCRIPTION=Descri\\u00E7\\u00E3o\n\n#XTIT: More information\nTSA_INFO=Maiores informa\\u00E7\\u00F5es\n\n#XFLD: Hours for approval\nTSA_HRS_APPR=Horas para aprova\\u00E7\\u00E3o\n\n#XFLD: For approval status\nTSA_STAT_FOR_APPR=Para aprova\\u00E7\\u00E3o\n\n#XFLD: Approved status\nTSA_STAT_APPROVED=Aprovado\n\n#XFLD: Rejected status\nTSA_STAT_REJ=Rejeitado\n\n#XFLD: Changed after approval\nTSA_STAT_CHANGED=Modificado ap\\u00F3s aprova\\u00E7\\u00E3o\n\n#XTIT: Approval status header\nTSA_APPR_STATUS=Status de aprova\\u00E7\\u00E3o\n\n#XTIT: Past Entry\nTSA_PAST_ENTRY=Entrada anterior\n\n#XFLD: Changed date\nTSA_CHANGED_DATETIME=Modificado em\n\n#XFLD: Changed by\nTSA_CHANGED_BY=Modificado por\n\n# YMSG: No items are currently available\nNO_ITEMS_AVAILABLE=Nenhum item dispon\\u00EDvel atualmente\n',
	"hcm/approve/timesheet/i18n/i18n_ro.properties":'\n#XTIT:  Application name\nTSA_APP_TITLE=Aprobare fi\\u015Fe de timp\n\n#XTIT:  Application name\nMASTER_TITLE=Fi\\u015Fe de timp ({0})\n\n#XTIT:  Application name\nTSA_APP=Fi\\u015F\\u0103 de timp\n\n#XTIT: detail panel text\nDETAIL_TITLE=Fi\\u015F\\u0103 de timp\n\n#XTIT: weekly target\nTSA_WEEKLY_TARGET=\\u0162int\\u0103\n\n#XBUT: Button Approve\nTSA_APPROVE=Aprobare\n\n#XBUT: Button Reject\nTSA_REJECT=Respingere\n\n#XBUT: button to confirm submit\nTSA_ACCEPT=OK\n\n#XBUT: Button to Navigate back&nbsp;\\\\\\&nbsp;\nTSA_BACK=\\u00CEnapoi\n\n#XFLD: No hours entered by the employee\nTSA_HOURS=Ore\n\n#XFLD: Hour in short form.\nTSA_HOUR_SHORT=h\n\n#XFLD: Minutes in short form.\nTSA_MIN_SHORT=m\n\n#YMSG: Message for list service error\nLIST_SERVICE_ERR_MESSAGE=Imposibil de ob\\u0163inut lista de intr\\u0103ri fi\\u015F\\u0103 de timp\n\n#YMSG: Message for Successful updation\nCATS_SUCCESS_MESSAGE=Intr\\u0103ri fi\\u015F\\u0103 de timp actualizate\n\n#XFLD: Column header for activity\nTSA_ACTIVITY=Activitate\n\n#XFLD: Column header for date\nTSA_DATE=Dat\\u0103\n\n#XTIT: Details  for time entry notes.\nTSA_DETAILS=Detalii\n\n#XTIT: Title for list of rejection reasons\nTSA_TIT_REJECTION_REASON=Motiv de respingere\n\n#XTIT: Message for Approval confirmation\nTSA_APR_CONF=Dori\\u0163i s\\u0103 aproba\\u0163i intrarea selectat\\u0103 pt.\n\n#XTIT: Message for Approvals confirmation\nTSA_APRS_CONF=Dori\\u0163i s\\u0103 aproba\\u0163i intr\\u0103rile selectate pt.\n\n#XTIT: Message for Rejection confirmation\nTSA_REJ_CONF=Dori\\u0163i s\\u0103 respinge\\u0163i intrarea selectat\\u0103 pt.\n\n#XTIT: Message for Rejection confirmation\nTSA_REJS_CONF=Dori\\u0163i s\\u0103 respinge\\u0163i intr\\u0103rile selectate pt.\n\n#XTIT: title for submit confirmation\nTSA_CONF_HEADER=Confirmare\n\n#XFLD: Text for multiple weeks\nTSA_WEEKS=S\\u0103pt\\u0103m\\u00E2ni\n\n#XFLD: Text for week\nTSA_WEEK=S\\u0103pt\\u0103m\\u00E2n\\u0103\n\n#XFLD: Recorded Time for employee.\nTSA_TIME_RECORDED=\\u00CEnregistrat\n\n#XFLD: Notes for time entry.\nTSA_NOTES=Note\n\n#XFLD: Over weeks.\nTSA_OVER=Peste\n\n#XFLD: Wage Type for time entry.\nTSA_WAGE_TYPE=Tip retribu\\u0163ie\n\n#XTIT:Description\nTSA_DESCRIPTION=Descriere\n\n#XTIT: More information\nTSA_INFO=Mai multe info\n\n#XFLD: Hours for approval\nTSA_HRS_APPR=Ore pt.aprobare\n\n#XFLD: For approval status\nTSA_STAT_FOR_APPR=Pt.aprobare\n\n#XFLD: Approved status\nTSA_STAT_APPROVED=Aprobat\n\n#XFLD: Rejected status\nTSA_STAT_REJ=Respins\n\n#XFLD: Changed after approval\nTSA_STAT_CHANGED=Modificat dup\\u0103 aprobare\n\n#XTIT: Approval status header\nTSA_APPR_STATUS=Stare de aprobare\n\n#XTIT: Past Entry\nTSA_PAST_ENTRY=Intrare anterioar\\u0103\n\n#XFLD: Changed date\nTSA_CHANGED_DATETIME=Modificat pe\n\n#XFLD: Changed by\nTSA_CHANGED_BY=Modificat de\n\n# YMSG: No items are currently available\nNO_ITEMS_AVAILABLE=F\\u0103r\\u0103 pozi\\u0163ii disponibile \\u00EEn prezent\n',
	"hcm/approve/timesheet/i18n/i18n_ru.properties":'\n#XTIT:  Application name\nTSA_APP_TITLE=\\u0423\\u0442\\u0432\\u0435\\u0440\\u0436\\u0434\\u0435\\u043D\\u0438\\u0435 \\u0442\\u0430\\u0431\\u0435\\u043B\\u0435\\u0439\n\n#XTIT:  Application name\nMASTER_TITLE=\\u0422\\u0430\\u0431\\u0435\\u043B\\u0438 ({0})\n\n#XTIT:  Application name\nTSA_APP=\\u0422\\u0430\\u0431\\u0435\\u043B\\u044C\n\n#XTIT: detail panel text\nDETAIL_TITLE=\\u0422\\u0430\\u0431\\u0435\\u043B\\u044C\n\n#XTIT: weekly target\nTSA_WEEKLY_TARGET=\\u0426\\u0435\\u043B\\u044C\n\n#XBUT: Button Approve\nTSA_APPROVE=\\u0423\\u0442\\u0432\\u0435\\u0440\\u0434\\u0438\\u0442\\u044C\n\n#XBUT: Button Reject\nTSA_REJECT=\\u041E\\u0442\\u043A\\u043B\\u043E\\u043D\\u0438\\u0442\\u044C\n\n#XBUT: button to confirm submit\nTSA_ACCEPT=\\u041E\\u041A\n\n#XBUT: Button to Navigate back&nbsp;\\\\\\&nbsp;\nTSA_BACK=\\u041D\\u0430\\u0437\\u0430\\u0434\n\n#XFLD: No hours entered by the employee\nTSA_HOURS=\\u0427\\u0430\\u0441\\u044B\n\n#XFLD: Hour in short form.\nTSA_HOUR_SHORT=\\u0447\n\n#XFLD: Minutes in short form.\nTSA_MIN_SHORT=\\u043C\\u0438\\u043D\n\n#YMSG: Message for list service error\nLIST_SERVICE_ERR_MESSAGE=\\u041D\\u0435 \\u0443\\u0434\\u0430\\u043B\\u043E\\u0441\\u044C \\u043F\\u043E\\u043B\\u0443\\u0447\\u0438\\u0442\\u044C \\u0441\\u043F\\u0438\\u0441\\u043E\\u043A \\u0437\\u0430\\u043F\\u0438\\u0441\\u0435\\u0439 \\u0442\\u0430\\u0431\\u0435\\u043B\\u044F\n\n#YMSG: Message for Successful updation\nCATS_SUCCESS_MESSAGE=\\u0417\\u0430\\u043F\\u0438\\u0441\\u0438 \\u0442\\u0430\\u0431\\u0435\\u043B\\u044F \\u043E\\u0431\\u043D\\u043E\\u0432\\u043B\\u0435\\u043D\\u044B\n\n#XFLD: Column header for activity\nTSA_ACTIVITY=\\u041E\\u043F\\u0435\\u0440\\u0430\\u0446\\u0438\\u044F\n\n#XFLD: Column header for date\nTSA_DATE=\\u0414\\u0430\\u0442\\u0430\n\n#XTIT: Details  for time entry notes.\nTSA_DETAILS=\\u041F\\u043E\\u0434\\u0440\\u043E\\u0431\\u043D\\u043E\n\n#XTIT: Title for list of rejection reasons\nTSA_TIT_REJECTION_REASON=\\u041F\\u0440\\u0438\\u0447\\u0438\\u043D\\u0430 \\u043E\\u0442\\u043A\\u043B\\u043E\\u043D\\u0435\\u043D\\u0438\\u044F\n\n#XTIT: Message for Approval confirmation\nTSA_APR_CONF=\\u0423\\u0442\\u0432\\u0435\\u0440\\u0434\\u0438\\u0442\\u044C \\u0432\\u044B\\u0431\\u0440\\u0430\\u043D\\u043D\\u0443\\u044E \\u0437\\u0430\\u043F\\u0438\\u0441\\u044C \\u0434\\u043B\\u044F\n\n#XTIT: Message for Approvals confirmation\nTSA_APRS_CONF=\\u0423\\u0442\\u0432\\u0435\\u0440\\u0434\\u0438\\u0442\\u044C \\u0432\\u044B\\u0431\\u0440\\u0430\\u043D\\u043D\\u044B\\u0435 \\u0437\\u0430\\u043F\\u0438\\u0441\\u0438 \\u0434\\u043B\\u044F\n\n#XTIT: Message for Rejection confirmation\nTSA_REJ_CONF=\\u041E\\u0442\\u043A\\u043B\\u043E\\u043D\\u0438\\u0442\\u044C \\u0432\\u044B\\u0431\\u0440\\u0430\\u043D\\u043D\\u0443\\u044E \\u0437\\u0430\\u043F\\u0438\\u0441\\u044C \\u0434\\u043B\\u044F\n\n#XTIT: Message for Rejection confirmation\nTSA_REJS_CONF=\\u041E\\u0442\\u043A\\u043B\\u043E\\u043D\\u0438\\u0442\\u044C \\u0432\\u044B\\u0431\\u0440\\u0430\\u043D\\u043D\\u044B\\u0435 \\u0437\\u0430\\u043F\\u0438\\u0441\\u0438 \\u0434\\u043B\\u044F\n\n#XTIT: title for submit confirmation\nTSA_CONF_HEADER=\\u041F\\u043E\\u0434\\u0442\\u0432\\u0435\\u0440\\u0436\\u0434\\u0435\\u043D\\u0438\\u0435\n\n#XFLD: Text for multiple weeks\nTSA_WEEKS=\\u041D\\u0435\\u0434\\u0435\\u043B\\u0438\n\n#XFLD: Text for week\nTSA_WEEK=\\u041D\\u0435\\u0434\\u0435\\u043B\\u044F\n\n#XFLD: Recorded Time for employee.\nTSA_TIME_RECORDED=\\u0417\\u0430\\u043F\\u0438\\u0441\\u0430\\u043D\\u043E\n\n#XFLD: Notes for time entry.\nTSA_NOTES=\\u041F\\u0440\\u0438\\u043C\\u0435\\u0447\\u0430\\u043D\\u0438\\u044F\n\n#XFLD: Over weeks.\nTSA_OVER=\\u043F\\u0440\\u0435\\u0432.\n\n#XFLD: Wage Type for time entry.\nTSA_WAGE_TYPE=\\u0412\\u0438\\u0434 \\u043E\\u043F\\u043B\\u0430\\u0442\\u044B\n\n#XTIT:Description\nTSA_DESCRIPTION=\\u041E\\u043F\\u0438\\u0441\\u0430\\u043D\\u0438\\u0435\n\n#XTIT: More information\nTSA_INFO=\\u0414\\u043E\\u043F\\u043E\\u043B\\u043D\\u0438\\u0442\\u0435\\u043B\\u044C\\u043D\\u0430\\u044F \\u0438\\u043D\\u0444\\u043E\\u0440\\u043C\\u0430\\u0446\\u0438\\u044F\n\n#XFLD: Hours for approval\nTSA_HRS_APPR=\\u0427\\u0430\\u0441\\u043E\\u0432 \\u043A \\u0443\\u0442\\u0432\\u0435\\u0440\\u0436\\u0434\\u0435\\u043D\\u0438\\u044E\n\n#XFLD: For approval status\nTSA_STAT_FOR_APPR=\\u041A \\u0443\\u0442\\u0432\\u0435\\u0440\\u0436\\u0434\\u0435\\u043D\\u0438\\u044E\n\n#XFLD: Approved status\nTSA_STAT_APPROVED=\\u0423\\u0442\\u0432\\u0435\\u0440\\u0436\\u0434\\u0435\\u043D\\u043E\n\n#XFLD: Rejected status\nTSA_STAT_REJ=\\u041E\\u0442\\u043A\\u043B\\u043E\\u043D\\u0435\\u043D\\u043E\n\n#XFLD: Changed after approval\nTSA_STAT_CHANGED=\\u0418\\u0437\\u043C\\u0435\\u043D\\u0435\\u043D\\u043E \\u043F\\u043E\\u0441\\u043B\\u0435 \\u0443\\u0442\\u0432\\u0435\\u0440\\u0436\\u0434\\u0435\\u043D\\u0438\\u044F\n\n#XTIT: Approval status header\nTSA_APPR_STATUS=\\u0421\\u0442\\u0430\\u0442\\u0443\\u0441 \\u0443\\u0442\\u0432\\u0435\\u0440\\u0436\\u0434\\u0435\\u043D\\u0438\\u044F\n\n#XTIT: Past Entry\nTSA_PAST_ENTRY=\\u041F\\u0440\\u043E\\u0448\\u043B\\u0430\\u044F \\u0437\\u0430\\u043F\\u0438\\u0441\\u044C\n\n#XFLD: Changed date\nTSA_CHANGED_DATETIME=\\u0414\\u0430\\u0442\\u0430 \\u0438\\u0437\\u043C\\u0435\\u043D\\u0435\\u043D\\u0438\\u044F\n\n#XFLD: Changed by\nTSA_CHANGED_BY=\\u0418\\u0437\\u043C\\u0435\\u043D\\u0438\\u043B\n\n# YMSG: No items are currently available\nNO_ITEMS_AVAILABLE=\\u0412 \\u0434\\u0430\\u043D\\u043D\\u044B\\u0439 \\u043C\\u043E\\u043C\\u0435\\u043D\\u0442 \\u043D\\u0435\\u0442 \\u0434\\u043E\\u0441\\u0442\\u0443\\u043F\\u043D\\u044B\\u0445 \\u044D\\u043B\\u0435\\u043C\\u0435\\u043D\\u0442\\u043E\\u0432\n',
	"hcm/approve/timesheet/i18n/i18n_sh.properties":'\n#XTIT:  Application name\nTSA_APP_TITLE=Odobri liste radnog vremena\n\n#XTIT:  Application name\nMASTER_TITLE=Liste radnog vremena ({0})\n\n#XTIT:  Application name\nTSA_APP=Lista radnog vremena\n\n#XTIT: detail panel text\nDETAIL_TITLE=Lista radnog vremena\n\n#XTIT: weekly target\nTSA_WEEKLY_TARGET=Cilj\n\n#XBUT: Button Approve\nTSA_APPROVE=Odobri\n\n#XBUT: Button Reject\nTSA_REJECT=Odbij\n\n#XBUT: button to confirm submit\nTSA_ACCEPT=OK\n\n#XBUT: Button to Navigate back&nbsp;\\\\\\&nbsp;\nTSA_BACK=Nazad\n\n#XFLD: No hours entered by the employee\nTSA_HOURS=Sati\n\n#XFLD: Hour in short form.\nTSA_HOUR_SHORT=h\n\n#XFLD: Minutes in short form.\nTSA_MIN_SHORT=m\n\n#YMSG: Message for list service error\nLIST_SERVICE_ERR_MESSAGE=Nije mogu\\u0107e pozvati listu unosa liste radnog vremena\n\n#YMSG: Message for Successful updation\nCATS_SUCCESS_MESSAGE=Unosi liste radnog vremena a\\u017Eurirani\n\n#XFLD: Column header for activity\nTSA_ACTIVITY=Aktivnost\n\n#XFLD: Column header for date\nTSA_DATE=Datum\n\n#XTIT: Details  for time entry notes.\nTSA_DETAILS=Detalji\n\n#XTIT: Title for list of rejection reasons\nTSA_TIT_REJECTION_REASON=Razlog za odbijanje\n\n#XTIT: Message for Approval confirmation\nTSA_APR_CONF=Da li \\u017Eelite da odobrite odabrani unos za\n\n#XTIT: Message for Approvals confirmation\nTSA_APRS_CONF=Da li \\u017Eelite da odobrite odabrane unose za\n\n#XTIT: Message for Rejection confirmation\nTSA_REJ_CONF=Da li \\u017Eelite da odbijete odabrani unos za\n\n#XTIT: Message for Rejection confirmation\nTSA_REJS_CONF=Da li \\u017Eelite da odbijete odabrane unose za\n\n#XTIT: title for submit confirmation\nTSA_CONF_HEADER=Potvrda\n\n#XFLD: Text for multiple weeks\nTSA_WEEKS=Nedelje\n\n#XFLD: Text for week\nTSA_WEEK=Nedelja\n\n#XFLD: Recorded Time for employee.\nTSA_TIME_RECORDED=Zabele\\u017Eeno\n\n#XFLD: Notes for time entry.\nTSA_NOTES=Bele\\u0161ke\n\n#XFLD: Over weeks.\nTSA_OVER=Preko\n\n#XFLD: Wage Type for time entry.\nTSA_WAGE_TYPE=Kategorija plate\n\n#XTIT:Description\nTSA_DESCRIPTION=Opis\n\n#XTIT: More information\nTSA_INFO=Vi\\u0161e informacija\n\n#XFLD: Hours for approval\nTSA_HRS_APPR=Sati za odobrenje\n\n#XFLD: For approval status\nTSA_STAT_FOR_APPR=Za odobrenje\n\n#XFLD: Approved status\nTSA_STAT_APPROVED=Odobreno\n\n#XFLD: Rejected status\nTSA_STAT_REJ=Odbijeno\n\n#XFLD: Changed after approval\nTSA_STAT_CHANGED=Promenjeno nakon odobrenja\n\n#XTIT: Approval status header\nTSA_APPR_STATUS=Status odobrenja\n\n#XTIT: Past Entry\nTSA_PAST_ENTRY=Prethodni unos\n\n#XFLD: Changed date\nTSA_CHANGED_DATETIME=Promenjeno\n\n#XFLD: Changed by\nTSA_CHANGED_BY=Promenio\n\n# YMSG: No items are currently available\nNO_ITEMS_AVAILABLE=Stavke trenutno nisu dostupne\n',
	"hcm/approve/timesheet/i18n/i18n_sk.properties":'\n#XTIT:  Application name\nTSA_APP_TITLE=Schva\\u013Eovanie evidencie \\u010Dasu\n\n#XTIT:  Application name\nMASTER_TITLE=Evidencie \\u010Dasu ({0})\n\n#XTIT:  Application name\nTSA_APP=Evidencia \\u010Dasu\n\n#XTIT: detail panel text\nDETAIL_TITLE=Evidencia \\u010Dasu\n\n#XTIT: weekly target\nTSA_WEEKLY_TARGET=Cie\\u013E\n\n#XBUT: Button Approve\nTSA_APPROVE=Schv\\u00E1li\\u0165\n\n#XBUT: Button Reject\nTSA_REJECT=Zamietnu\\u0165\n\n#XBUT: button to confirm submit\nTSA_ACCEPT=OK\n\n#XBUT: Button to Navigate back&nbsp;\\\\\\&nbsp;\nTSA_BACK=Sp\\u00E4\\u0165\n\n#XFLD: No hours entered by the employee\nTSA_HOURS=Hodiny\n\n#XFLD: Hour in short form.\nTSA_HOUR_SHORT=hod\n\n#XFLD: Minutes in short form.\nTSA_MIN_SHORT=min\n\n#YMSG: Message for list service error\nLIST_SERVICE_ERR_MESSAGE=Nie je mo\\u017En\\u00E9 z\\u00EDska\\u0165 zoznam z\\u00E1znamov evidencie \\u010Dasu\n\n#YMSG: Message for Successful updation\nCATS_SUCCESS_MESSAGE=Z\\u00E1znamy evidencie \\u010Dasu aktualizovan\\u00E9\n\n#XFLD: Column header for activity\nTSA_ACTIVITY=Aktivita\n\n#XFLD: Column header for date\nTSA_DATE=D\\u00E1tum\n\n#XTIT: Details  for time entry notes.\nTSA_DETAILS=Detaily\n\n#XTIT: Title for list of rejection reasons\nTSA_TIT_REJECTION_REASON=D\\u00F4vod zamietnutia\n\n#XTIT: Message for Approval confirmation\nTSA_APR_CONF=Chcete schv\\u00E1li\\u0165 vybran\\u00FD z\\u00E1znam pre\n\n#XTIT: Message for Approvals confirmation\nTSA_APRS_CONF=Chcete schv\\u00E1li\\u0165 vybran\\u00E9 z\\u00E1znamy pre\n\n#XTIT: Message for Rejection confirmation\nTSA_REJ_CONF=Chcete zamietnu\\u0165 vybran\\u00FD z\\u00E1znam pre\n\n#XTIT: Message for Rejection confirmation\nTSA_REJS_CONF=Chcete zamietnu\\u0165 vybran\\u00E9 z\\u00E1znamy pre\n\n#XTIT: title for submit confirmation\nTSA_CONF_HEADER=Potvrdenie\n\n#XFLD: Text for multiple weeks\nTSA_WEEKS=T\\u00FD\\u017Edne\n\n#XFLD: Text for week\nTSA_WEEK=T\\u00FD\\u017Ede\\u0148\n\n#XFLD: Recorded Time for employee.\nTSA_TIME_RECORDED=Zaznamenan\\u00E9\n\n#XFLD: Notes for time entry.\nTSA_NOTES=Pozn\\u00E1mky\n\n#XFLD: Over weeks.\nTSA_OVER=Nad\n\n#XFLD: Wage Type for time entry.\nTSA_WAGE_TYPE=Mzdov\\u00FD druh\n\n#XTIT:Description\nTSA_DESCRIPTION=Popis\n\n#XTIT: More information\nTSA_INFO=\\u010Eal\\u0161ie inform\\u00E1cie\n\n#XFLD: Hours for approval\nTSA_HRS_APPR=Hodiny na schv\\u00E1lenie\n\n#XFLD: For approval status\nTSA_STAT_FOR_APPR=Na schv\\u00E1lenie\n\n#XFLD: Approved status\nTSA_STAT_APPROVED=Schv\\u00E1len\\u00E9\n\n#XFLD: Rejected status\nTSA_STAT_REJ=Zamietnut\\u00E9\n\n#XFLD: Changed after approval\nTSA_STAT_CHANGED=Zmenen\\u00E9 po schv\\u00E1len\\u00ED\n\n#XTIT: Approval status header\nTSA_APPR_STATUS=Stav schva\\u013Eovania\n\n#XTIT: Past Entry\nTSA_PAST_ENTRY=Minul\\u00FD z\\u00E1znam\n\n#XFLD: Changed date\nTSA_CHANGED_DATETIME=Zmenen\\u00E9 d\\u0148a\n\n#XFLD: Changed by\nTSA_CHANGED_BY=Zmenil\n\n# YMSG: No items are currently available\nNO_ITEMS_AVAILABLE=Aktu\\u00E1lne nie s\\u00FA k dispoz\\u00EDcii \\u017Eiadne polo\\u017Eky\n',
	"hcm/approve/timesheet/i18n/i18n_sl.properties":'\n#XTIT:  Application name\nTSA_APP_TITLE=Odobritev evidenc delov. \\u010Dasa\n\n#XTIT:  Application name\nMASTER_TITLE=Seznami delovnih ur ({0})\n\n#XTIT:  Application name\nTSA_APP=Evidenca delovnega \\u010Dasa\n\n#XTIT: detail panel text\nDETAIL_TITLE=Evidenca delovnega \\u010Dasa\n\n#XTIT: weekly target\nTSA_WEEKLY_TARGET=Cilj\n\n#XBUT: Button Approve\nTSA_APPROVE=Odobritev\n\n#XBUT: Button Reject\nTSA_REJECT=Zavrnitev\n\n#XBUT: button to confirm submit\nTSA_ACCEPT=OK\n\n#XBUT: Button to Navigate back&nbsp;\\\\\\&nbsp;\nTSA_BACK=Nazaj\n\n#XFLD: No hours entered by the employee\nTSA_HOURS=Ure\n\n#XFLD: Hour in short form.\nTSA_HOUR_SHORT=h\n\n#XFLD: Minutes in short form.\nTSA_MIN_SHORT=m\n\n#YMSG: Message for list service error\nLIST_SERVICE_ERR_MESSAGE=Ni bilo mogo\\u010De pridobiti seznama vnosov evidence delovnega \\u010Dasa\n\n#YMSG: Message for Successful updation\nCATS_SUCCESS_MESSAGE=Vnosi evidence delovnega \\u010Dasa so posodobljeni\n\n#XFLD: Column header for activity\nTSA_ACTIVITY=Aktivnost\n\n#XFLD: Column header for date\nTSA_DATE=Datum\n\n#XTIT: Details  for time entry notes.\nTSA_DETAILS=Detajli\n\n#XTIT: Title for list of rejection reasons\nTSA_TIT_REJECTION_REASON=Razlog zavrnitve\n\n#XTIT: Message for Approval confirmation\nTSA_APR_CONF=\\u017Delite odobriti izbrani vnos za\n\n#XTIT: Message for Approvals confirmation\nTSA_APRS_CONF=\\u017Delite odobriti izbrane vnose za\n\n#XTIT: Message for Rejection confirmation\nTSA_REJ_CONF=\\u017Delite zavrniti izbrani vnos za\n\n#XTIT: Message for Rejection confirmation\nTSA_REJS_CONF=\\u017Delite zavrniti izbrane vnose za\n\n#XTIT: title for submit confirmation\nTSA_CONF_HEADER=Potrditev\n\n#XFLD: Text for multiple weeks\nTSA_WEEKS=Tedni\n\n#XFLD: Text for week\nTSA_WEEK=Teden\n\n#XFLD: Recorded Time for employee.\nTSA_TIME_RECORDED=Posneto\n\n#XFLD: Notes for time entry.\nTSA_NOTES=Zabele\\u017Eke\n\n#XFLD: Over weeks.\nTSA_OVER=\\u010Cez\n\n#XFLD: Wage Type for time entry.\nTSA_WAGE_TYPE=Tip pla\\u010De\n\n#XTIT:Description\nTSA_DESCRIPTION=Opis\n\n#XTIT: More information\nTSA_INFO=Druge informacije\n\n#XFLD: Hours for approval\nTSA_HRS_APPR=Ure za odobritev\n\n#XFLD: For approval status\nTSA_STAT_FOR_APPR=Za odobritev\n\n#XFLD: Approved status\nTSA_STAT_APPROVED=Odobreno\n\n#XFLD: Rejected status\nTSA_STAT_REJ=Zavrnjeno\n\n#XFLD: Changed after approval\nTSA_STAT_CHANGED=Spremenjeno po odobritvi\n\n#XTIT: Approval status header\nTSA_APPR_STATUS=Status odobritve\n\n#XTIT: Past Entry\nTSA_PAST_ENTRY=Predhodni vnos\n\n#XFLD: Changed date\nTSA_CHANGED_DATETIME=Spremenjeno dne\n\n#XFLD: Changed by\nTSA_CHANGED_BY=Spremenil\n\n# YMSG: No items are currently available\nNO_ITEMS_AVAILABLE=Tenutno postavke niso na voljo\n',
	"hcm/approve/timesheet/i18n/i18n_tr.properties":'\n#XTIT:  Application name\nTSA_APP_TITLE=Zaman \\u00E7izelgelerini onayla\n\n#XTIT:  Application name\nMASTER_TITLE=Zaman \\u00E7izelgeleri ({0})\n\n#XTIT:  Application name\nTSA_APP=Zaman \\u00E7izelgesi\n\n#XTIT: detail panel text\nDETAIL_TITLE=Zaman \\u00E7izelgesi\n\n#XTIT: weekly target\nTSA_WEEKLY_TARGET=Hedef\n\n#XBUT: Button Approve\nTSA_APPROVE=Onayla\n\n#XBUT: Button Reject\nTSA_REJECT=Reddet\n\n#XBUT: button to confirm submit\nTSA_ACCEPT=Tamam\n\n#XBUT: Button to Navigate back&nbsp;\\\\\\&nbsp;\nTSA_BACK=Geriye\n\n#XFLD: No hours entered by the employee\nTSA_HOURS=Saat\n\n#XFLD: Hour in short form.\nTSA_HOUR_SHORT=s\n\n#XFLD: Minutes in short form.\nTSA_MIN_SHORT=d\n\n#YMSG: Message for list service error\nLIST_SERVICE_ERR_MESSAGE=Zaman \\u00E7izelgesi giri\\u015Flerinin listesi al\\u0131namad\\u0131\n\n#YMSG: Message for Successful updation\nCATS_SUCCESS_MESSAGE=Zaman \\u00E7izelgesi giri\\u015Fleri g\\u00FCncellendi\n\n#XFLD: Column header for activity\nTSA_ACTIVITY=Aktivite\n\n#XFLD: Column header for date\nTSA_DATE=Tarih\n\n#XTIT: Details  for time entry notes.\nTSA_DETAILS=Ayr\\u0131nt\\u0131lar\n\n#XTIT: Title for list of rejection reasons\nTSA_TIT_REJECTION_REASON=Ret nedeni\n\n#XTIT: Message for Approval confirmation\nTSA_APR_CONF=\\u015Eunun i\\u00E7in se\\u00E7ilen giri\\u015Fi onaylamak istiyor musunuz?\n\n#XTIT: Message for Approvals confirmation\nTSA_APRS_CONF=\\u015Eunun i\\u00E7in se\\u00E7ilen giri\\u015Fleri onaylamak istiyor musunuz?\n\n#XTIT: Message for Rejection confirmation\nTSA_REJ_CONF=\\u015Eunun i\\u00E7in se\\u00E7ilen giri\\u015Fi reddetmek istiyor musunuz?\n\n#XTIT: Message for Rejection confirmation\nTSA_REJS_CONF=\\u015Eunun i\\u00E7in se\\u00E7ilen giri\\u015Fleri reddetmek istiyor musunuz?\n\n#XTIT: title for submit confirmation\nTSA_CONF_HEADER=Teyit\n\n#XFLD: Text for multiple weeks\nTSA_WEEKS=Hafta\n\n#XFLD: Text for week\nTSA_WEEK=Hafta\n\n#XFLD: Recorded Time for employee.\nTSA_TIME_RECORDED=Kaydedildi\n\n#XFLD: Notes for time entry.\nTSA_NOTES=Notlar\n\n#XFLD: Over weeks.\nTSA_OVER=Fazla\n\n#XFLD: Wage Type for time entry.\nTSA_WAGE_TYPE=\\u00DCcret t\\u00FCr\\u00FC\n\n#XTIT:Description\nTSA_DESCRIPTION=Tan\\u0131m\n\n#XTIT: More information\nTSA_INFO=Daha fazla bilgi\n\n#XFLD: Hours for approval\nTSA_HRS_APPR=Onay i\\u00E7in saatler\n\n#XFLD: For approval status\nTSA_STAT_FOR_APPR=Onay i\\u00E7in\n\n#XFLD: Approved status\nTSA_STAT_APPROVED=Onayland\\u0131\n\n#XFLD: Rejected status\nTSA_STAT_REJ=Reddedildi\n\n#XFLD: Changed after approval\nTSA_STAT_CHANGED=Onaydan sonra de\\u011Fi\\u015Ftirildi\n\n#XTIT: Approval status header\nTSA_APPR_STATUS=Onay durumu\n\n#XTIT: Past Entry\nTSA_PAST_ENTRY=Ge\\u00E7mi\\u015F giri\\u015F\n\n#XFLD: Changed date\nTSA_CHANGED_DATETIME=De\\u011Fi\\u015Fiklik tarihi\n\n#XFLD: Changed by\nTSA_CHANGED_BY=De\\u011Fi\\u015Ftiren\n\n# YMSG: No items are currently available\nNO_ITEMS_AVAILABLE=\\u015Eu anda kalem mevcut de\\u011Fil\n',
	"hcm/approve/timesheet/i18n/i18n_zh_CN.properties":'\n#XTIT:  Application name\nTSA_APP_TITLE=\\u5BA1\\u6279\\u5DE5\\u65F6\\u8868\n\n#XTIT:  Application name\nMASTER_TITLE=\\u5DE5\\u65F6\\u8868 ({0})\n\n#XTIT:  Application name\nTSA_APP=\\u5DE5\\u65F6\\u8868\n\n#XTIT: detail panel text\nDETAIL_TITLE=\\u5DE5\\u65F6\\u8868\n\n#XTIT: weekly target\nTSA_WEEKLY_TARGET=\\u76EE\\u6807\n\n#XBUT: Button Approve\nTSA_APPROVE=\\u6279\\u51C6\n\n#XBUT: Button Reject\nTSA_REJECT=\\u62D2\\u7EDD\n\n#XBUT: button to confirm submit\nTSA_ACCEPT=\\u786E\\u5B9A\n\n#XBUT: Button to Navigate back&nbsp;\\\\\\&nbsp;\nTSA_BACK=\\u4E0A\\u4E00\\u6B65\n\n#XFLD: No hours entered by the employee\nTSA_HOURS=\\u5C0F\\u65F6\n\n#XFLD: Hour in short form.\nTSA_HOUR_SHORT=\\u5C0F\\u65F6\n\n#XFLD: Minutes in short form.\nTSA_MIN_SHORT=\\u5206\n\n#YMSG: Message for list service error\nLIST_SERVICE_ERR_MESSAGE=\\u65E0\\u6CD5\\u83B7\\u53D6\\u5DE5\\u65F6\\u8868\\u6761\\u76EE\\u5217\\u8868\n\n#YMSG: Message for Successful updation\nCATS_SUCCESS_MESSAGE=\\u5DE5\\u65F6\\u8868\\u6761\\u76EE\\u5DF2\\u66F4\\u65B0\n\n#XFLD: Column header for activity\nTSA_ACTIVITY=\\u6D3B\\u52A8\n\n#XFLD: Column header for date\nTSA_DATE=\\u65E5\\u671F\n\n#XTIT: Details  for time entry notes.\nTSA_DETAILS=\\u8BE6\\u7EC6\\u4FE1\\u606F\n\n#XTIT: Title for list of rejection reasons\nTSA_TIT_REJECTION_REASON=\\u62D2\\u7EDD\\u539F\\u56E0\n\n#XTIT: Message for Approval confirmation\nTSA_APR_CONF=\\u662F\\u5426\\u8981\\u6279\\u51C6\\u9009\\u5B9A\\u6761\\u76EE\\uFF1A\n\n#XTIT: Message for Approvals confirmation\nTSA_APRS_CONF=\\u662F\\u5426\\u8981\\u6279\\u51C6\\u9009\\u5B9A\\u6761\\u76EE\\uFF1A\n\n#XTIT: Message for Rejection confirmation\nTSA_REJ_CONF=\\u662F\\u5426\\u8981\\u62D2\\u7EDD\\u9009\\u5B9A\\u6761\\u76EE\\uFF1A\n\n#XTIT: Message for Rejection confirmation\nTSA_REJS_CONF=\\u662F\\u5426\\u8981\\u62D2\\u7EDD\\u9009\\u5B9A\\u6761\\u76EE\\uFF1A\n\n#XTIT: title for submit confirmation\nTSA_CONF_HEADER=\\u786E\\u8BA4\n\n#XFLD: Text for multiple weeks\nTSA_WEEKS=\\u5468\n\n#XFLD: Text for week\nTSA_WEEK=\\u661F\\u671F\n\n#XFLD: Recorded Time for employee.\nTSA_TIME_RECORDED=\\u5DF2\\u8BB0\\u5F55\n\n#XFLD: Notes for time entry.\nTSA_NOTES=\\u6CE8\\u91CA\n\n#XFLD: Over weeks.\nTSA_OVER=\\u8D85\\u8FC7\n\n#XFLD: Wage Type for time entry.\nTSA_WAGE_TYPE=\\u5DE5\\u8D44\\u9879\n\n#XTIT:Description\nTSA_DESCRIPTION=\\u63CF\\u8FF0\n\n#XTIT: More information\nTSA_INFO=\\u66F4\\u591A\\u4FE1\\u606F\n\n#XFLD: Hours for approval\nTSA_HRS_APPR=\\u5F85\\u5BA1\\u6279\\u7684\\u5C0F\\u65F6\\u6570\n\n#XFLD: For approval status\nTSA_STAT_FOR_APPR=\\u5F85\\u6279\\u51C6\n\n#XFLD: Approved status\nTSA_STAT_APPROVED=\\u5DF2\\u6279\\u51C6\n\n#XFLD: Rejected status\nTSA_STAT_REJ=\\u5DF2\\u62D2\\u7EDD\n\n#XFLD: Changed after approval\nTSA_STAT_CHANGED=\\u5BA1\\u6279\\u540E\\u53D1\\u751F\\u66F4\\u6539\n\n#XTIT: Approval status header\nTSA_APPR_STATUS=\\u5BA1\\u6279\\u72B6\\u6001\n\n#XTIT: Past Entry\nTSA_PAST_ENTRY=\\u8FC7\\u53BB\\u7684\\u6761\\u76EE\n\n#XFLD: Changed date\nTSA_CHANGED_DATETIME=\\u66F4\\u6539\\u65E5\\u671F\n\n#XFLD: Changed by\nTSA_CHANGED_BY=\\u66F4\\u6539\\u4EBA\n\n# YMSG: No items are currently available\nNO_ITEMS_AVAILABLE=\\u5F53\\u524D\\u65E0\\u53EF\\u7528\\u9879\\u76EE\n',
	"hcm/approve/timesheet/util/DataManager.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("hcm.approve.timesheet.util.DataManager");

hcm.approve.timesheet.util.DataManager = (function() {

	var _modelBase = null;
	var _resourceBundle = null;
	var _cachedModelObj = {};
	_cachedModelObj.exist = true;

	return {

		init: function(oDataModel, oresourceBundle) {
			_modelBase = oDataModel;
			_modelBase.setCountSupported(false);

			//_modelBase.setUseBatch(true);
			_resourceBundle = oresourceBundle;
		},

		getBaseODataModel: function() {
			return _modelBase;
		},

		setCachedModelObjProp: function(propName, propObj) {
			_cachedModelObj[propName] = propObj;
		},

		getCachedModelObjProp: function(propName) {
			return _cachedModelObj[propName];
		},

		getMaster: function(successCallback, errorCallback) {
			var sPath = "TIME_PENDING";
			var mParameters = {
				// urlParameters : "TIME_PENDING",
				async: false,
				success: jQuery.proxy(function(objResponse) {
					successCallback(objResponse.results);
				}, this),
				error: function(objResponse) {
					errorCallback(objResponse);
				}
			};
			_modelBase.read(sPath, mParameters);
		},

		getDetail: function(filter, successCallback, errorCallback) {
			var oFilter = {
				"$filter": filter
			};
			var sPath = "TIME_DETAILS_EMP";
			var mParameters = {
				urlParameters: oFilter,
				async: true,
				success: jQuery.proxy(function(objResponse) {
					successCallback(objResponse.results);
				}, this),
				error: function(objResponse) {
					errorCallback(objResponse);
				}
			};
			_modelBase.read(sPath, mParameters);
		},

		getRejectionReasons: function(successCallback, errorCallback) {
			var sPath = "REJ_REASON";
			var mParameters = {
				async: false,
				success: jQuery.proxy(function(objResponse) {
					this.setCachedModelObjProp("RejectionReason", objResponse.results);
					successCallback(objResponse.results);
				}, this),
				error: function(objResponse) {
					errorCallback(objResponse);
				}
			};
			_modelBase.read(sPath, mParameters);
		},

		submitPendingEntries: function(collection, successCallback) {
			var onRequestFailed = function(oError) {
				this.processError(oError);
			};
			_modelBase.create(collection, null, null, jQuery.proxy(function(oData, oResponse) {
				successCallback(oData, oResponse);

				/*this.self.oRouter.navTo("master");*/
			}, this), jQuery.proxy(onRequestFailed, this));
		},

		processError: function(oError) {
			var errorObj = JSON.parse(oError.response.body).error;
			var errorSet = errorObj.innererror.errordetails;
			var finalMessage, messageSeverity, finalMessageSeverity;
			finalMessage = messageSeverity = "";
			finalMessageSeverity = errorSet[0].severity;
			var messageHeader = errorSet[0].message;

			for (var i = 0; i < errorSet.length; i++) {
				if (errorSet[i].code.match("/IWBEP")) {
					continue;
				}
				finalMessage += errorSet[i].message + "\n";
				messageSeverity = errorSet[i].severity;
				if (finalMessageSeverity !== "error" && finalMessageSeverity !== messageSeverity) {
					finalMessageSeverity = messageSeverity;
				}
			}

			sap.ca.ui.message.showMessageBox({
				type: (finalMessageSeverity === "error") ? sap.ca.ui.message.Type.ERROR : sap.ca.ui.message.Type.WARNING,
				message: messageHeader,
				details: finalMessage
			});

		}

	};

}());
},
	"hcm/approve/timesheet/util/Formatter.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
//declare namespace
jQuery.sap.declare("hcm.approve.timesheet.util.Formatter");
jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
jQuery.sap.require("sap.ca.ui.model.format.AmountFormat");

hcm.approve.timesheet.util.Formatter = {
	init: function(resourseBundle) {
		this.resourceBundle = resourseBundle;
	},
	DateRangeFormatter: function(ODate1, ODate2) {
		var oDateInstance = sap.ui.core.format.DateFormat.getDateInstance({
			style: "medium",
			pattern: "MMM dd"
		});

		var formattedDate1 = ODate1.substr(0, 4) + "-" + ODate1.substr(4, 2) + "-" + ODate1.substr(6, 2); //change date format to yyyy-mm-dd
		var formattedDate2 = ODate2.substr(0, 4) + "-" + ODate2.substr(4, 2) + "-" + ODate2.substr(6, 2);
		var displayDate = oDateInstance.format(new Date(formattedDate1), true) + " - " + oDateInstance.format(new Date(formattedDate2), true); //UTC param changed to true 2148838
		return displayDate;
	},

	DateFormatter: function(ODate) {
		var oDateInstance = sap.ui.core.format.DateFormat.getDateInstance({
			style: "medium",
			pattern: "MMM dd"
		});
		var formattedDate = ODate.substr(0, 4) + "-" + ODate.substr(4, 2) + "-" + ODate.substr(6, 2); //change date format to yyyy-mm-dd
		return oDateInstance.format(new Date(formattedDate), true); //UTC param changed to true 2148838
	},

	LastDateTimeFormatter: function(ODate, OTime) {
		var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
			pattern: "yyyyMMdd"
		});
		var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
			pattern: "HHmmss"
		});
		return dateFormat.format(ODate, true) + "," + timeFormat.format(new Date(OTime), true);
	},

	weekAppender: function(num_week) {
		if (num_week > 1) {
			return hcm.approve.timesheet.util.Formatter.resourceBundle.getText("TSA_OVER") + " " + num_week + " " + hcm.approve.timesheet.util.Formatter
				.resourceBundle.getText("TSA_WEEKS");
		} else {
			return hcm.approve.timesheet.util.Formatter.resourceBundle.getText("TSA_OVER") + " " + num_week + " " + hcm.approve.timesheet.util.Formatter
				.resourceBundle.getText("TSA_WEEK");
		}
	},

	textAppender: function(text1, text2) {
		return text1 + " " + text2;
	},

	textAppender1: function(text1, text2, text3) {
		var text = text1 + " " + text2 + ", " + text3;
		return text;
	},
	newLineAdder: function(text1, text2) {
		return text1 + "\n" + text2;
	},

	timeConverter: function(value) {
		var hours = parseInt(Number(value), 10).toString();
		var minutes = parseInt(((Number(value) - hours) * 60), 10).toString();

		if (hours.length === 1) {
			hours = "0" + hours;
		}
		if (minutes.length === 1) {
			minutes = "0" + minutes;
		}
		return hours + ":" + minutes;
	},
	unitAppender: function(text1, text2) {
		if (text2 === "H") { //convert to hours and minutes
			var time = hcm.approve.timesheet.util.Formatter.timeConverter(text1);
			return time;
		} else {
			return text1 + " " + text2;
		}
	},

	removeText: function(text1) {
		return text1.slice(text1.indexOf(".") + 1, text1.length); //Removes title from names(Mr Ms Mrs) 
	},
	IdFormatter: function(text1, text2) {
		return text1 + text2;
	},
	textFormatter: function(value, text1, text2) {
		if (value > 0) {
			return text1 + "/" + text2;
		} else {
			return text1;
		}
	},
	recTimeDisplay: function(value1, value2) {
		if (value2 > 0) {
			return hcm.approve.timesheet.util.Formatter.timeConverter(value1) + "/" + hcm.approve.timesheet.util.Formatter.timeConverter(value2);

		} else {
			return hcm.approve.timesheet.util.Formatter.timeConverter(value1);

		}
	},
	DateTimeFormatter: function(date, time) {
		var oDateInstance = sap.ui.core.format.DateFormat.getDateInstance({
			pattern: "d.MM.yyyy",
			locale: "EN"
		});
		var oDate = oDateInstance.format(date, false);
		var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
			pattern: "KK:mm:ss a"
		});
		// timezoneOffset is in hours convert to milliseconds  
		var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
		var oTime = timeFormat.format(new Date(time.ms + TZOffsetMs));
		return oDate + "[ " + oTime + " ]";
	}
};
},
	"hcm/approve/timesheet/view/S2.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.ScfldMasterController");

sap.ca.scfld.md.controller.ScfldMasterController.extend("hcm.approve.timesheet.view.S2", {

	extHookfillList: null,
	extHookChangeFooterButtons: null,

	onInit: function() {
		sap.ca.scfld.md.controller.ScfldMasterController.prototype.onInit.call(this);
		this.oDataModel = this.oApplicationFacade.getODataModel();
		this.resourceBundle = this.oApplicationFacade.getResourceBundle();
		hcm.approve.timesheet.util.DataManager.init(this.oDataModel, this.resourceBundle);
		hcm.approve.timesheet.util.Formatter.init(this.resourceBundle);
		this.oApplication = this.oApplicationFacade.oApplicationImplementation;
		this.oRouter.attachRouteMatched(this._handleRouteMatched, this);
		this._isLocalRouting = false;
		this._fnRefreshCompleted = null;
		this._isMasterRefresh = false;
		this.firstItemRemoved = false;

		var eventBus = sap.ui.getCore().getEventBus();
		eventBus.subscribe("hcm.approve.timesheet", "timesheetApproveReject", this._handleUpdate, this);
	},
	selectFirstItem: function() { //selectes either the first item or the item selected before refresh
		var oList = this.getList();
		var aItems = oList.getItems();
		var oListItem;
		var oIndex = null,
			searchKey = null;
		if (aItems.length < 1) {
			this.showEmptyView();
			this.pernr = null;
			this.updateModelCall = false;
			return;
		}
		var oInstance = new sap.ui.core.routing.HashChanger();
		var completeURL = oInstance.getHash().split('detail');
		if (completeURL[1] !== undefined) {
			completeURL = completeURL[1].split("/");
		}
		if (completeURL[1] !== undefined) {
			searchKey = decodeURIComponent(completeURL[1]);
			//	searchKey = decodeURIComponent(searchKey);

		}
		if (this.itemNotFound) {
			oIndex = searchKey.split("/")[1];
			if (oIndex === "0") {
				this.firstItemRemoved = true; //previously first item was removed
			}
			oListItem = this._oApplicationImplementation.getFirstListItem(this);
			this.setListItem(oListItem);
			return;
		}
		//get the index
		if ((searchKey !== null && searchKey !== "") && (aItems)) {
			oIndex = searchKey.split("/")[1];
			if (oIndex === null) {
				if (aItems.length > 0) {
					oListItem = this._oApplicationImplementation.getFirstListItem(this);
				} else {
					this.showEmptyView();
				}
			} else {

				if (aItems.length > oIndex) {
					oListItem = aItems[oIndex];
					this.setListItem(oListItem);
				}

			}
		} else {
			oListItem = this._oApplicationImplementation.getFirstListItem(this);
			this.setListItem(oListItem);
		}

	},
	/*	getDetailNavigationParameters : function(oListItem) {
		return {
			contextPath : encodeURIComponent(oListItem.getBindingContextPath().substr(1))
		};
	},*/
	_handleRouteMatched: function(oEvent) {

		// to use cached data for local routing
		if (oEvent.getParameter("name") === "master" && (this._isLocalRouting === false)) {
			this._initData();
		}
	},

	_handleUpdate: function(channelId, eventId, data) {
		this._initData(data);
	},

	setListItem: function(oItem) {
		var oList = this.getList();
		if (oList) {
			oList.removeSelections(true);
		}
		oItem.setSelected(true);
		if ( /*this.itemPathBeforeRefresh !== oList.getSelectedContextPaths()[0] ||*/ !this.updateModelCall || (this.itemNotFound && !this.firstItemRemoved)) {
			this.oRouter.navTo("detail", {
				contextPath: encodeURIComponent(oItem.getBindingContextPath().substr(1))
			}, !jQuery.device.is.phone);
		} else {
			this.updateModelCall = false;
			var eventBus = sap.ui.getCore().getEventBus();
			eventBus.publish("hcm.approve.timesheet", "refreshDetail", {
				pos: this.updatedMasterItemPos
			});
		}
		this._isLocalRouting = true;
		this.firstItemRemoved = false;
	},

	applySearchPatternToListItem: function(oItem, sFilterPattern) {
		if ((oItem.getTitle() && oItem.getTitle().toLowerCase().indexOf(sFilterPattern) !== -1) || (oItem.getNumber() && oItem.getNumber().toLowerCase()
			.indexOf(sFilterPattern) !== -1) || (oItem.getFirstStatus() && oItem.getFirstStatus().getText().toLowerCase().indexOf(sFilterPattern) !==
			-1) || (oItem.getSecondStatus() && oItem.getSecondStatus().getText().toLowerCase().indexOf(sFilterPattern) !== -1)) {
			return true;
		}
		var aAttributes = oItem.getAttributes();
		for (var j = 0; j < aAttributes.length; j++) {
			if (aAttributes[j].getText().toLowerCase().indexOf(sFilterPattern) !== -1) {
				return true;
			}
		}
		return false;
	},

	fillList: function(oMasterModel) {
		this.byId("list").bindItems({
			path: "/MasterModelDataCollection",
			template: new sap.m.ObjectListItem({
				type: "{device>/listItemType}",
				title: "{parts:[{path:'EMPNAME'}], formatter:'hcm.approve.timesheet.util.Formatter.removeText'}",
				number: "{parts:[{path:'CATSHOURS'}], formatter:'hcm.approve.timesheet.util.Formatter.timeConverter'}", //Note 2206414 make duration display consistent with My Timesheet app
				numberUnit: "{i18n>TSA_HOURS}",
				attributes: [
							              new sap.m.ObjectAttribute({
						text: "{POSNAME}"
					})],
				firstStatus: new sap.m.ObjectStatus({
					text: "{i18n>TSA_STAT_FOR_APPR}",
					state: "None"
				}),
				secondStatus: new sap.m.ObjectStatus({
					text: "{parts:[{path:'NUM_WEEKS'}], formatter:'hcm.approve.timesheet.util.Formatter.weekAppender'}",
					state: "None"
				}),
				customData: new sap.ui.core.CustomData({
					key: "AtsPernr",
					value: "{PERNR}"
				})
			})
		});
	},

	_initData: function(data) {
		if (data) {
			this.pernr = data; //will be set onupdate() via event bus
		}

		hcm.approve.timesheet.util.DataManager.getMaster(jQuery.proxy(function(objResponse) {
			//var MasterModelData = this._createDetailModelData(objResponse);
			var oMasterModel = new sap.ui.model.json.JSONModel({
				"MasterModelDataCollection": objResponse
			});
			var oView = this.getView();
			oView.setModel(oMasterModel);
			this.oApplication.setModel(oMasterModel, "masterModel");
			this._isLocalRouting = true;
			this.itemNotFound = false;
			/**
			 * @ControllerHook Modify the footer buttons
			 * This hook method can be used to add and change the properties of the list
			 * It is called when the employees data for the manager is called successfully
			 * @callback hcm.approve.timesheet.view.S2~extHookfillList
			 * @param {object} Master model for the list
			 */
			if (this.extHookfillList) {
				this.extHookfillList(oMasterModel);
			} else {
				this.fillList(oMasterModel);
			}
			this.refreshHeaderFooterForEditToggle();

			if (this._fnRefreshCompleted) {
				this._fnRefreshCompleted();
			}
			var i, masterListItems = this.byId("list").getItems();
			//to do : handle no data on update model call
			if (this.pernr) {
				this.updateModelCall = true;
				for (i = 0; i < masterListItems.length; i++) {
					if (this.pernr === masterListItems[i].getCustomData()[0].getValue("AtsPernr")) {
						this.updatedMasterItemPos = i;
						this.setListItem(masterListItems[i]);
						break;
					}
				}
				if (i === masterListItems.length) {
					if (masterListItems.length > 0) {
						this.pernr = masterListItems[0].getCustomData()[0].getValue("AtsPernr");
					}

					this.updatedMasterItemPos = 0;
					this.itemNotFound = true;
					this.selectFirstItem();
				}
			} else if (!jQuery.device.is.phone) {
				/*if((!jQuery.device.is.phone && i === masterListItems.length) || this._isMasterRefresh === true) ){*/
				this.selectFirstItem();
			}

		}, this), function(objResponse) {
			hcm.approve.timesheet.util.DataManager.processError(objResponse);
		});

	},
	getHeaderFooterOptions: function() {
		var data;
		var oList = this.byId("list");
		var count = oList.getItems().length;
		var objHdrFtr = {

			sI18NMasterTitle: this.resourceBundle.getText("MASTER_TITLE", [count]),
			onRefresh: jQuery.proxy(function(searchField, fnRefreshCompleted) {
				/*this.itemPathBeforeRefresh = this.byId("list").getSelectedContextPaths()[0];*/
				var length = this.byId("list").getItems().length;
				this._fnRefreshCompleted = fnRefreshCompleted;
				this._searchField = searchField;
				this._isMasterRefresh = true;
				if (length > 0 && !jQuery.device.is.phone) {
					data = this.byId("list").getSelectedItem().getCustomData()[0].getValue("AtsPernr");
				}
				this._initData(data);
				//var eventBus = sap.ui.getCore().getEventBus();
				//eventBus.publish("hcm.approve.timesheet", "refreshDetail",this.pernr);
			}, this)
		};
		var m = new sap.ui.core.routing.HashChanger();
		var oUrl = m.getHash();
		if (oUrl.indexOf("Shell-runStandaloneApp") >= 0) {
			objHdrFtr.onBack = null;
		}
		/**
		 * @ControllerHook Modify the footer buttons
		 * This hook method can be used to add and change buttons for the detail view footer
		 * It is called when the decision options for the detail item are fetched successfully
		 * @callback hcm.approve.timesheet.view.S2~extHookChangeFooterButtons
		 * @param {object} Header Footer Object
		 * @return {object} Header Footer Object
		 */

		if (this.extHookChangeFooterButtons) {
			objHdrFtr = this.extHookChangeFooterButtons(objHdrFtr);
		}

		return objHdrFtr;
	}
});
},
	"hcm/approve/timesheet/view/S2.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View controllerName="hcm.approve.timesheet.view.S2" xmlns:core="sap.ui.core" xmlns="sap.m">\n\t<Page id="page">\n\t\t<content>\n\t\t\t<List id="list" mode="SingleSelectMaster" select="_handleSelect"/>\n\t\t</content>\n\t</Page>\n</core:View>',
	"hcm/approve/timesheet/view/S3.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
jQuery.sap.require("hcm.approve.timesheet.util.DataManager");
jQuery.sap.require("hcm.approve.timesheet.util.Formatter");
jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");

sap.ca.scfld.md.controller.BaseDetailController.extend("hcm.approve.timesheet.view.S3", {
	extHookcreateDetailModelData: null,
	extHookviewSummary: null,
	extHookChangeFooterButtons: null,

	getWeeklyPendingEntriesCount: function() {
		var numVisibleCheckBox = 0;
		var iconTabBarID = this.byId("S3IconTabBar");
		var SelectedKey = iconTabBarID.getSelectedKey();
		//fetch the items for the selected icon tab filter
		for (var k = 0; k < iconTabBarID.getItems().length; k++) {
			if (iconTabBarID.getItems()[k].getKey() === SelectedKey) {
				var oItems = this.byId("S3IconTabBar").getItems()[k].getContent()[0].getItems();
				break;
			}
		}
		/*		var selectedIconTabFilter = this.byId("S3IconTabBar").oSelectedItem;
		var oItems =  selectedIconTabFilter.getContent()[0].getItems();*/
		for (var i = 0; i < oItems.length; i++) {
			var oCheckBox = oItems[i].getCells()[1];
			if (oCheckBox.getEnabled() === true) {
				numVisibleCheckBox++;
			}
		}
		return numVisibleCheckBox;
	},
	updateModel: function() {
		this.updateFlag = true;
		//	this._initData(this.filter,this.IndividualMasterData);
		this.setBtnEnabled("ApproveBtn", false);
		this.setBtnEnabled("RejectBtn", false);
		var eventBus = sap.ui.getCore().getEventBus();
		eventBus.publish("hcm.approve.timesheet", "timesheetApproveReject", this.pernr);
		/*this.IndividualMasterData = this.oApplication.getModel("masterModel").getData().MasterModelDataCollection[this.masterItem];
		this.setDetailObjectHdr(this.IndividualMasterData);*/
	},
	refreshDetail: function(channelId, eventId, data) {
		this.IndividualMasterData = this.oApplication.getModel("masterModel").getData().MasterModelDataCollection[data.pos];
		this.pernr = this.IndividualMasterData.PERNR;
		var startDate = this.IndividualMasterData.STARTDATE;
		var endDate = this.IndividualMasterData.ENDDATE;
		this.filter = "PERNR eq '" + this.pernr + "' and STARTDATE eq '" + startDate + "'and ENDDATE eq '" + endDate + "'";
		this._initData(this.filter, this.IndividualMasterData);
		this.setDetailObjectHdr(this.IndividualMasterData);
	},
	setButtonState: function(event) {
		var iconTabBarID = this.byId("S3IconTabBar");
		var SelectedKey = iconTabBarID.getSelectedKey();
		var counterDateTime = this.fetchSelectedCounters(); //Note 2206414 async rec check
		this.lSelectedCounters = counterDateTime[0];
		this.lLaeda = counterDateTime[1];
		this.lLaetm = counterDateTime[2];

		if (this.lSelectedCounters.length !== 0) {
			this.setBtnEnabled("ApproveBtn", true);
			this.setBtnEnabled("RejectBtn", true);
		} else {
			this.setBtnEnabled("ApproveBtn", false);
			this.setBtnEnabled("RejectBtn", false);
		}

		var selectableEntriesCount = this.getWeeklyPendingEntriesCount();
		//handle the selection of header checkbox
		if (selectableEntriesCount === this.lSelectedCounters.length) {

			// var headerCheckBoxState = event.getParameters().checked;
			for (var k = 0; k < iconTabBarID.getItems().length; k++) {
				if (iconTabBarID.getItems()[k].getKey() === SelectedKey) {
					this.byId("S3IconTabBar").getItems()[k].getContent()[0].getColumns()[1].getHeader().setSelected(true);
					this.prevAllSelected = true;
					break;
				}
			}

		} else if (this.prevAllSelected === true) {
			for (var k = 0; k < iconTabBarID.getItems().length; k++) {
				if (iconTabBarID.getItems()[k].getKey() === SelectedKey) {
					this.byId("S3IconTabBar").getItems()[k].getContent()[0].getColumns()[1].getHeader().setSelected(false);
					this.prevAllSelected = false;
					break;
				}
			}
		}
	},
	reset: function() { //Note 2124135
		var iconTabBarID = this.byId("S3IconTabBar");
		for (var k = 0; k < iconTabBarID.getItems().length; k++) {
			if (iconTabBarID.getItems()[k].getKey() === this.prevIconTabFilter) {
				this.byId("S3IconTabBar").getItems()[k].getContent()[0].getColumns()[1].getHeader().setSelected(false); //reset the header checkbox
				this.selectAllCheckBoxes(); //reset all the selected checkboxes and the button state
				break;
			}
		}
		this.prevIconTabFilter = this.byId("S3IconTabBar").getSelectedKey(); //End Note 2124135
	},
	selectAllCheckBoxes: function(event) {
		var iconTabBarID = this.byId("S3IconTabBar");

		var headerCheckBoxState, SelectedKey; //Note 2124135
		//If event is generated then call is from the checkbox , else it is from reset function
		if (event) {
			headerCheckBoxState = event.getParameters().selected;
			SelectedKey = iconTabBarID.getSelectedKey();
		} else { //set the parameters for resetting the rest of checkboxes in the previous contabfilter
			headerCheckBoxState = false;
			SelectedKey = this.prevIconTabFilter; //End Note 2124135
		}
		// var headerCheckBoxState = event.getParameters().checked;
		//fetch the items for the selected icon tab filter
		for (var k = 0; k < iconTabBarID.getItems().length; k++) {
			if (iconTabBarID.getItems()[k].getKey() === SelectedKey) {
				var oItems = this.byId("S3IconTabBar").getItems()[k].getContent()[0].getItems();
				break;
			}
		}
		/*		var selectedIconTabFilter = this.byId("S3IconTabBar").oSelectedItem;
		var oItems =  selectedIconTabFilter.getContent()[0].getItems();*/
		for (var i = 0; i < oItems.length; i++) {
			var oCheckBox = oItems[i].getCells()[1];
			if (oCheckBox.getEnabled() === true) {
				oCheckBox.setSelected(headerCheckBoxState); //set each checkbox to the headerCheckBox State
			}
		}
		//Set the button status according to the headerCheckBox state.
		if (headerCheckBoxState === true) {
			this.setBtnEnabled("ApproveBtn", true);
			this.setBtnEnabled("RejectBtn", true);
			this.prevAllSelected = true;
		} else {
			this.setBtnEnabled("ApproveBtn", false);
			this.setBtnEnabled("RejectBtn", false);
			this.prevAllSelected = true;
		}

		var counterDateTime = this.fetchSelectedCounters(); //Note 2206414 async rec check
		this.lSelectedCounters = counterDateTime[0];
		this.lLaeda = counterDateTime[1];
		this.lLaetm = counterDateTime[2];
	},
	fetchSelectedCounters: function(event) {
		var iconTabBarID = this.byId("S3IconTabBar");
		var SelectedKey = iconTabBarID.getSelectedKey();
		//fetch the items for the selected icon tab filter
		for (var k = 0; k < iconTabBarID.getItems().length; k++) {
			if (iconTabBarID.getItems()[k].getKey() === SelectedKey) {
				var oItems = this.byId("S3IconTabBar").getItems()[k].getContent()[0].getItems();
				break;
			}
		}
		/*	var selectedIconTabFilter = this.byId("S3IconTabBar").oSelectedItem;
		var oItems =  selectedIconTabFilter.getContent()[0].getItems();*/
		var oCounter = [],
			oLaeda = [],
			oLaetm = []; //Note 2206414 async rec check
		for (var i = 0; i < oItems.length; i++) {
			var oCheckBox = oItems[i].getCells()[1];
			if (oCheckBox.getSelected() === true)
			//	if(oCheckBox.getChecked() === true)
			{
				oCounter.push(oItems[i].getCells()[1].getCustomData()[0].getValue()); //Note 2206414 async rec check
				oLaeda.push(oItems[i].getCells()[1].getCustomData()[1].getValue());
				oLaetm.push(oItems[i].getCells()[1].getCustomData()[2].getValue());
			}
		}
		return [oCounter, oLaeda, oLaetm]; //Note 2206414 async rec check
	},

	setSelectedRejectionReason: function(rejReason) {
		this.Reason = rejReason.REASON;
		var RejectionReasonText = null;
		if (this.lSelectedCounters.length > 1) {
//BEGIN OF NOTE 2310185		    
		    if(this.resourceBundle.sLocale === 'ja'){
		     RejectionReasonText = this.resourceBundle.getText("TSA_REJS_CONF");                           //NOTE 2312493  
		    }else{       
			 RejectionReasonText = this.resourceBundle.getText("TSA_REJS_CONF") + " " + this.EMPNAME + "?";
		    }
		} else {
		   if(this.resourceBundle.sLocale === 'ja'){
		    RejectionReasonText = this.resourceBundle.getText("TSA_REJ_CONF");                            //NOTE 2312493     
		   }else{     
			RejectionReasonText = this.resourceBundle.getText("TSA_REJ_CONF") + " " + this.EMPNAME + "?";
		   }	
		}
//END OF NOTE 2310185
		var lSettings = this.confirmationTextBoxView(RejectionReasonText);
		sap.ca.ui.dialog.factory.confirm(lSettings, jQuery.proxy(function(response) {
			if (response.isConfirmed === true) {
				var submitStr = this.createSubmitStr("R", this.Reason);
				submitStr += "'";
				var collection = "CATS_ACTION?" + submitStr;
				hcm.approve.timesheet.util.DataManager.submitPendingEntries(collection, jQuery.proxy(function(oData, oResponse) {
					sap.ca.ui.message.showMessageToast(this.resourceBundle.getText("CATS_SUCCESS_MESSAGE"));
					this.updateModel();
				}, this));
			}
		}, this));
	},

	createSubmitStr: function(statusChar, rejReason) {
		var str = "cats='";
		for (var i = 0; i < this.lSelectedCounters.length; i++) {
			str += this.pernr + "," + this.lSelectedCounters[i] + "," + statusChar + "," + rejReason + "," + hcm.approve.timesheet.util.Formatter.LastDateTimeFormatter(
				this.lLaeda[i], this.lLaetm[i].ms) + "/"; //Note 2206414 async rec check
		}
		return str;
	},
	confirmationTextBoxView: function(ConfBoxText) {
		var oSettings = {
			question: ConfBoxText,
			showNote: false,
			title: this.resourceBundle.getText("TSA_CONF_HEADER"),
			confirmButtonLabel: "OK"
		};
		return oSettings;
	},

	/*fetchSelectedTableEntries : function(){
		var selectedIconTabFilter = this.byId("S3IconTabBar").oSelectedItem;					
		var selectedTableEntries = selectedIconTabFilter.getContent()[0].getSelectedItems();    
		return selectedTableEntries;
	},*/

	viewSummary: function(event) {
		/**
		 * @ControllerHook Modify the contents in the Summary pop-up
		 * This hook method can be used to add or remove the contents for the Summary pop-up
		 * It is called when you click on the button in the detail view
		 * @callback hcm.approve.timesheet.view.S3~extHookviewSummary
		 * @param {object} event captured on click of the button
		 */
		if (this.extHookviewSummary) {
			this.extHookviewSummary(event);
		} else {
			var counter = event.getSource().getCustomData()[0].getValue("counter");
			var iconTabBarID = this.byId("S3IconTabBar");
			var selectedKey = iconTabBarID.getSelectedKey();
			var selectedIcontab = null;
			for (var l = 0; l < iconTabBarID.getItems().length; l++) {
				if (iconTabBarID.getItems()[l].getKey() === selectedKey) {
					selectedIcontab = this.byId("S3IconTabBar").getItems()[l];
					break;
				}
			}

			var notesArray = [];
			/*	var path = selectedIcontab.mBindingInfos.key.binding.oContext.sPath;
		path = path.split("/");
		var weekIndex = path[2];*/
			var weekIndex = selectedIcontab.getCustomData()[0].getValue();
			var weeksCollection = this.oView.getModel("a").getData().DetailModelDataCollection;
			//traverse to fetch the past entry using counter as the reference
			var weekData = weeksCollection[weekIndex].PENDING_ENTRIES;

			for (var i = 0; i < weekData.length; i++) {
				if (weekData[i].COUNTER === counter) {
					notesArray.push({
						"title": this.resourceBundle.getText("TSA_DATE"),
						"description": hcm.approve.timesheet.util.Formatter.DateFormatter(weekData[i].WORKDATE)
					});
					notesArray.push({
						"title": this.resourceBundle.getText("TSA_DESCRIPTION"),
						"description": hcm.approve.timesheet.util.Formatter.newLineAdder(weekData[i].MAIN_FIELD_TEXT, weekData[i].SUB_FIELDS_TEXT)
					});
					notesArray.push({
						"title": this.resourceBundle.getText("TSA_TIME_RECORDED"),
						"description": hcm.approve.timesheet.util.Formatter.unitAppender(weekData[i].CATSHOURS, weekData[i].CATSUNIT)
					});
					var notes = weekData[i].NOTES;
					var rejectionReason = weekData[i].REJ_REASON;
					if (notes || rejectionReason) {
						if (notes) {
							notesArray.push({
								"title": this.resourceBundle.getText("TSA_NOTES"),
								"description": notes
							});
						}
						if (rejectionReason) {
							var rejectionReasonText = null;
							var CachedRejectionReason = hcm.approve.timesheet.util.DataManager.getCachedModelObjProp("RejectionReason");
							if (!CachedRejectionReason) {
								hcm.approve.timesheet.util.DataManager.getRejectionReasons(jQuery.proxy(function(objResponse) {
									//do-nothing
								}, this), function(objResponse) {
									//hcm.emp.mybenefits.util.DataManager.parseErrorMessages(objResponse);
									hcm.approve.timesheet.util.DataManager.processError(objResponse);
								});
								CachedRejectionReason = hcm.approve.timesheet.util.DataManager.getCachedModelObjProp("RejectionReason");
							}
							for (var j = 0; j < CachedRejectionReason.length; j++) {
								if (CachedRejectionReason[j].REASON === rejectionReason) {
									rejectionReasonText = CachedRejectionReason[j].TEXT;
								}
							}
							notesArray.push({
								"title": this.resourceBundle.getText("TSA_TIT_REJECTION_REASON"),
								"description": rejectionReasonText
							});
						}
					}

					if (weekData[i].oPastEntries) {

						for (var k = 0; k < weekData[i].oPastEntries.length; k++) { //Create the notes data

							var pastCatsHours = weekData[i].oPastEntries[k].CATSHOURS;
							var pastCatsUnit = weekData[i].oPastEntries[k].CATSUNIT;
							var changedDate = weekData[i].oPastEntries[k].CHANGED_DATE;
							var changedTime = weekData[i].oPastEntries[k].CHANGED_TIME;
							var changedBy = weekData[i].oPastEntries[k].CHANGED_BY;

							notesArray.push({
								"title": this.resourceBundle.getText("TSA_PAST_ENTRY"),
								"description": hcm.approve.timesheet.util.Formatter.unitAppender(pastCatsHours, pastCatsUnit)
							});
							notesArray.push({
								"title": this.resourceBundle.getText("TSA_CHANGED_DATETIME"),
								"description": hcm.approve.timesheet.util.Formatter.DateTimeFormatter(changedDate, changedTime)
							});

							notesArray.push({
								"title": this.resourceBundle.getText("TSA_CHANGED_BY"),
								"description": changedBy
							});
						}
					}
					break;
				}
			}
			var template = new sap.m.ColumnListItem({
				cells: [
		                new sap.m.Label({
						text: "{title}"
					}),
		                 new sap.m.Text({
						text: "{description}"
					})
		                                                ]
			});
			var oTable = new sap.m.Table({
				columns: [new sap.m.Column(), new sap.m.Column()]
			});
			var closePopOver = function(event) {
				oPopOver.close();
			};
			var details = this.resourceBundle.getText("TSA_DETAILS");
			var empname = event.getSource().getCustomData()[1].getValue("empname");
			var oPopOver = new sap.m.ResponsivePopover({
				contentWidth: "40%",
				placement: sap.m.PlacementType.Left,
				title: hcm.approve.timesheet.util.Formatter.textAppender(details, empname),
				content: oTable,
				beginButton: new sap.m.Button({
					text: this.resourceBundle.getText("TSA_ACCEPT"),
					press: closePopOver
				})
			});
			var noteJsonModel = new sap.ui.model.json.JSONModel({
				"Notes": notesArray
			});
			oTable.bindAggregation("items", "/Notes", template);
			oTable.setModel(noteJsonModel);
			oPopOver.openBy(sap.ui.getCore().byId(event.getParameters().id));

		}
	},

	handleSearch: function(oEvent) {
		var sValue = oEvent.getParameter("value");
		var oFilter = new sap.ui.model.Filter("TEXT", sap.ui.model.FilterOperator.Contains, sValue);
		var oBinding = oEvent.getSource().getBinding("items");
		oBinding.filter([oFilter]);
	},

	handleClose: function(evt) {
		var listSPath = evt.getParameters().selectedItem.getBindingContext().sPath;
		var listSPathSplit = listSPath.split("/");
		var listIndex = listSPathSplit[2];
		var CachedRejectionReason = hcm.approve.timesheet.util.DataManager.getCachedModelObjProp("RejectionReason");
		this.setSelectedRejectionReason(CachedRejectionReason[listIndex]);

	},

	setRejectionReasons: function(CachedRejectionReason) {
		var oData = {
			"RejectionReasonCollection": CachedRejectionReason
		};
		var oModel = new sap.ui.model.json.JSONModel(oData);
		var rejReasonTemplate = new sap.m.StandardListItem({
			title: "{TEXT}",
			type: "Active"
		});

		var oDialog = new sap.m.SelectDialog({
			title: this.resourceBundle.getText("TSA_TIT_REJECTION_REASON"),
			items: {
				path: "/RejectionReasonCollection",
				template: rejReasonTemplate
			},
			search: this.handleSearch,
			close: this.handleClose,
			confirm: jQuery.proxy(this.handleClose, this)
		});
		oDialog.setModel(oModel);
		oDialog.open();
	},

	setDetailObjectHdr: function(ObjHdrData) {
		this.EMPNAME = ObjHdrData.EMPNAME;
		var objHdr = this.byId("DetailObjHdr");
		objHdr.setTitle(ObjHdrData.EMPNAME);
		objHdr.setNumber(hcm.approve.timesheet.util.Formatter.timeConverter(ObjHdrData.CATSHOURS)); //Note 2206414 make duration display consistent with My Timesheet app
		objHdr.setNumberUnit(this.resourceBundle.getText("TSA_HRS_APPR"));
		this.byId("DetailObjHdrAttr1").setText(hcm.approve.timesheet.util.Formatter.weekAppender(ObjHdrData.NUM_WEEKS));
		this.byId("DetailObjHdrAttr2").setText(ObjHdrData.POSNAME);
		this.byId("DetailObjHdrStatus1").setText(hcm.approve.timesheet.util.Formatter.textAppender1( //Note 2206414 make duration display consistent with My Timesheet app
			hcm.approve.timesheet.util.Formatter.timeConverter(ObjHdrData.APPROVEDHOURS), this.resourceBundle
			.getText("TSA_HOURS"), this.resourceBundle.getText("TSA_STAT_APPROVED")));
		this.byId("DetailObjHdrStatus2").setText(hcm.approve.timesheet.util.Formatter.textAppender1(
			hcm.approve.timesheet.util.Formatter.timeConverter(ObjHdrData.REJECTEDHOURS), this.resourceBundle
			.getText("TSA_HOURS"), this.resourceBundle.getText("TSA_STAT_REJ")));
	},
	_getStatusText: function(number) {
		switch (number) {
			case "20":
				return [this.resourceBundle.getText("TSA_STAT_FOR_APPR"), "None", true];
			case "30":
				return [this.resourceBundle.getText("TSA_STAT_APPROVED"), "Success", false];
			case "40":
				return [this.resourceBundle.getText("TSA_STAT_REJ"), "Error", false];
			case "50":
				return [this.resourceBundle.getText("TSA_STAT_CHANGED"), "Warning", true];
		}
	},

	_createDetailModelData: function(oResults) {
		var weeksData = []; // holds complete set of weeks data
		var weekData = {}; //holds data for a week
		var oWeek = [];
		var oPendingEntry = {};
		var oAllPastEntries = [];
		var displayWeekNumber = 0;
		var pastEntries = []; //past entries associated with the new entry
		var currWeeknumber, nextWeekNumber, oStatus = null;
		var totalCatHours = 0.0,
			headerCheckboxState = false;

		for (var i = 0; i < oResults.length; i++) {
			currWeeknumber = oResults[i].WEEKNR;
			if (i !== oResults.length - 1) {
				nextWeekNumber = oResults[i + 1].WEEKNR;
			} else {
				nextWeekNumber = undefined;
			}

			oPendingEntry = {};
			oPendingEntry.EMPNAME = oResults[i].EMPNAME;
			oPendingEntry.WORKDATE = oResults[i].WORKDATE;
			oPendingEntry.MAIN_FIELD_TEXT = oResults[i].MAIN_FIELD_TEXT;
			oPendingEntry.SUB_FIELDS_TEXT = oResults[i].SUB_FIELDS_TEXT;
			oPendingEntry.CATSHOURS = oResults[i].CATSHOURS;
			oPendingEntry.CATSUNIT = oResults[i].CATSUNIT;
			var status = oResults[i].STATUS;
			if (status === "20" || status === "30") {
				totalCatHours += Number(oPendingEntry.CATSHOURS);
			}
			if (status === "20" && headerCheckboxState !== true) {
				headerCheckboxState = true;
			}
			oStatus = this._getStatusText(oResults[i].STATUS);
			oPendingEntry.STATUS_TEXT = oStatus[0];
			oPendingEntry.STATUS = oStatus[1];
			oPendingEntry.CHECKBOX_STATE = oStatus[2];
			oPendingEntry.CHECKBOX_SELECTED_STATE = false;
			oPendingEntry.COUNTER = oResults[i].COUNTER;
			oPendingEntry.REF_COUNTER = oResults[i].REF_COUNTER;

			oPendingEntry.CHANGED_DATE = oResults[i].CHANGED_DATE;
			oPendingEntry.CHANGED_TIME = oResults[i].CHANGED_TIME;
			oPendingEntry.CHANGED_BY = oResults[i].CHANGED_BY;
			if (oResults[i].CATSTEXT) { //Note: 2165196  check to display either catstext or ltxa1(short text)
				oPendingEntry.NOTES = oResults[i].CATSTEXT;
			} else {
				oPendingEntry.NOTES = oResults[i].NOTES;
			} //End Note: 2165196
			oPendingEntry.REJ_REASON = oResults[i].REJ_REASON;
			if (oPendingEntry.NOTES || oPendingEntry.REJ_REASON) {
				oPendingEntry.moreInfoBtnStatus = true;
			} else {
				oPendingEntry.moreInfoBtnStatus = false;
			}

			if (status === "50") {
				oAllPastEntries.push(oPendingEntry);
			} else {
				oWeek.push(oPendingEntry);
			}
			if (currWeeknumber !== nextWeekNumber) {
				for (var j = 0; j < oAllPastEntries.length; j++) {
					var counter = oAllPastEntries[j].COUNTER; //Counter of past entries will be matched with the ref_counter of the new entry
					for (var k = 0; k < oWeek.length; k++) {
						if (oWeek[k].REF_COUNTER === counter) {
							pastEntries.push(oAllPastEntries[j]);
							oWeek[k].moreInfoBtnStatus = true;
							oWeek[k].STATUS1 = oAllPastEntries[j].STATUS_TEXT;
							oWeek[k].oPastEntries = pastEntries;
							pastEntries = [];
							break;
						}
					}
				}
				weekData.PENDING_ENTRIES = oWeek;
				weekData.WEEK_START = oResults[i].WEEK_START;
				weekData.WEEK_END = oResults[i].WEEK_END;
				weekData.totalCatHours = totalCatHours;
				weekData.weekTarget = oResults[i].WEEK_TARGET;
				weekData.tableID = "PendingEntriesTable" + oResults[i].WEEKNR; //used to generate dynamic ids for table as well as tab filter
				weekData.tabFilterID = "IconTabFilter" + oResults[i].WEEKNR;
				weekData.displayWeekNumber = displayWeekNumber;
				weekData.MainCheckBoxState = headerCheckboxState;
				weekData.MainCheckBoxSelectedState = false;
				if (weekData.PENDING_ENTRIES.length > 0) {
					weeksData.push(weekData);
				}

				//clean up
				oWeek = [];
				weekData = {};
				totalCatHours = 0.0;
				headerCheckboxState = false;
				displayWeekNumber++;
			}
		}
		return weeksData;

	},
	_initData: function(filter, ObjHdrData) {
		this.setDetailObjectHdr(ObjHdrData);
		hcm.approve.timesheet.util.DataManager.getDetail(filter, jQuery.proxy(function(objResponse) {
			var DetailModelData;
			/**
			 * @ControllerHook Modify the loaded view
			 * It is called when the detail page odata call is successful
			 * @callback hcm.approve.timesheet.view.S3~extHookcreateDetailModelData
			 * @param {object} Response from the Detail Odata Call
			 * @return {object} Data parsed according to weeks
			 */
			if (this.extHookcreateDetailModelData) {
				DetailModelData = this.extHookcreateDetailModelData(objResponse);
			} else {
				DetailModelData = this._createDetailModelData(objResponse);
			}

			this.byId("RecordedTime").setText(hcm.approve.timesheet.util.Formatter.textFormatter(this.totalCatHours, ObjHdrData.TARGETHOURS));
			var oDetailModel = new sap.ui.model.json.JSONModel({
				"DetailModelDataCollection": DetailModelData
			});
			var oView = this.getView();
			oView.setModel(oDetailModel, "a");
			this.byId("S3IconTabBar").setExpanded(true);
			if (!this.updateFlag) {
				this.byId("S3IconTabBar").setSelectedKey(DetailModelData[0].tabFilterID);
				this.prevIconTabFilter = this.byId("S3IconTabBar").getSelectedKey();
			}
			this.updateFlag = false;
		}, this), function(objResponse) {
			hcm.approve.timesheet.util.DataManager.processError(objResponse);
			//hcm.emp.mybenefits.util.DataManager.parseErrorMessages(objResponse);
		});

	},

	onInit: function() {
		// execute the onInit for the base class
		// BaseDetailController
		sap.ca.scfld.md.controller.BaseDetailController.prototype.onInit.call(this);
		this.oDataModel = this.oApplicationFacade.getODataModel();
		this.resourceBundle = this.oApplicationFacade.getResourceBundle();
		hcm.approve.timesheet.util.DataManager.init(this.oDataModel, this.resourceBundle);

		var eventBus = sap.ui.getCore().getEventBus();
		eventBus.subscribe("hcm.approve.timesheet", "refreshDetail", this.refreshDetail, this);
		if (!this.oApplication) {
			this.oApplication = this.oApplicationFacade.oApplicationImplementation;
		}
		this.oRouter.attachRouteMatched(function(oEvent) {
			if (oEvent.getParameter("name") === "detail") {
				hcm.approve.timesheet.util.DataManager.init(this.oDataModel, this.resourceBundle);
				var contextPath = decodeURIComponent(oEvent.getParameter("arguments").contextPath);
				this.masterItem = Number(contextPath.slice(contextPath.indexOf("/") + 1, contextPath.length));
				this.IndividualMasterData = this.oApplication.getModel("masterModel").getData().MasterModelDataCollection[this.masterItem];
				this.pernr = this.IndividualMasterData.PERNR;
				var startDate = this.IndividualMasterData.STARTDATE;
				var endDate = this.IndividualMasterData.ENDDATE;
				this.filter = "PERNR eq '" + this.pernr + "' and STARTDATE eq '" + startDate + "'and ENDDATE eq '" + endDate + "'";
				this._initData(this.filter, this.IndividualMasterData);
			}

		}, this);
	},

	getHeaderFooterOptions: function() {
		var objHdrFtr = {
			oPositiveAction: {
				sId: "ApproveBtn",
				sI18nBtnTxt: this.resourceBundle.getText("TSA_APPROVE"),
				bDisabled: true,
				onBtnPressed: jQuery.proxy(function() {
					var ConfBoxText, lSettings;
					//Fetch the selected time entry counters
					if (this.lSelectedCounters.length > 1) {
//BEGIN OF NOTE 2310185					    
					    if(this.resourceBundle.sLocale === 'ja'){
					     ConfBoxText = this.resourceBundle.getText("TSA_APRS_CONF");                           //NOTE 2312493       
					    }else{
						 ConfBoxText = this.resourceBundle.getText("TSA_APRS_CONF") + " " + this.EMPNAME + "?";
					    }
					} else {
					   if(this.resourceBundle.sLocale === 'ja'){ 
					    ConfBoxText = this.resourceBundle.getText("TSA_APR_CONF");                            //NOTE 2312493  
					   }else{ 
						ConfBoxText = this.resourceBundle.getText("TSA_APR_CONF") + " " + this.EMPNAME + "?";
					   }
					}
//END OF NOTE 2310185					
					lSettings = this.confirmationTextBoxView(ConfBoxText); //function end create str, osettings
					sap.ca.ui.dialog.factory.confirm(lSettings, jQuery.proxy(function(response) {
						if (response.isConfirmed === true) {
							var submitStr = this.createSubmitStr("A", "");
							submitStr += "'";
							var collection = "CATS_ACTION?" + submitStr;
							hcm.approve.timesheet.util.DataManager.submitPendingEntries(collection, jQuery.proxy(function(oData, oResponse) {
								sap.ca.ui.message.showMessageToast(this.resourceBundle.getText("CATS_SUCCESS_MESSAGE"));
								this.updateModel();
							}, this));
						}
					}, this));
				}, this)
			},

			oNegativeAction: {
				sId: "RejectBtn",
				sI18nBtnTxt: this.resourceBundle.getText("TSA_REJECT"),
				bDisabled: true,
				onBtnPressed: jQuery.proxy(function() {
					var CachedRejectionReason = hcm.approve.timesheet.util.DataManager.getCachedModelObjProp("RejectionReason");
					if (!CachedRejectionReason) {
						hcm.approve.timesheet.util.DataManager.getRejectionReasons(jQuery.proxy(function(objResponse) {
							this.setRejectionReasons(objResponse);
						}, this), function(objResponse) {
							//hcm.emp.mybenefits.util.DataManager.parseErrorMessages(objResponse);
							hcm.approve.timesheet.util.DataManager.processError(objResponse);
						});
					} else {
						this.setRejectionReasons(CachedRejectionReason);
					}
				}, this)

			}
		};
		var m = new sap.ui.core.routing.HashChanger();
		var oUrl = m.getHash();
		if (oUrl.indexOf("Shell-runStandaloneApp") >= 0) {
			objHdrFtr.bSuppressBookmarkButton = true;
		}
		/**
		 * @ControllerHook Modify the footer buttons
		 * This hook method can be used to add and change buttons for the detail view footer
		 * It is called when the decision options for the detail item are fetched successfully
		 * @callback hcm.approve.timesheet.view.S3~extHookChangeFooterButtons
		 * @param {object} Header Footer Object
		 * @return {object} Header Footer Object
		 */

		if (this.extHookChangeFooterButtons) {
			objHdrFtr = this.extHookChangeFooterButtons(objHdrFtr);
		}
		return objHdrFtr;
	}
});
},
	"hcm/approve/timesheet/view/S3.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View controllerName="hcm.approve.timesheet.view.S3" xmlns:core="sap.ui.core" xmlns:l="sap.ui.layout" xmlns:mvc="sap.ui.core.mvc"\n\txmlns="sap.m">\n\t<Page>\n\t\t<content>\n\t\t\t<ObjectHeader id="DetailObjHdr" visible="true">\n\t\t\t\t<attributes>\n\t\t\t\t\t<ObjectAttribute id="DetailObjHdrAttr1"/>\n\t\t\t\t\t<ObjectAttribute id="DetailObjHdrAttr2"/>\n\t\t\t\t</attributes>\n\t\t\t\t<firstStatus>\n\t\t\t\t\t<ObjectStatus id="DetailObjHdrStatus1" state="Success"></ObjectStatus>\n\t\t\t\t</firstStatus>\n\t\t\t\t<secondStatus>\n\t\t\t\t\t<ObjectStatus id="DetailObjHdrStatus2" state="Error"></ObjectStatus>\n\t\t\t\t</secondStatus>\n\t\t\t\t<!-- extension point for additional fields -->\n\t\t\t\t<core:ExtensionPoint name="extS3Header"></core:ExtensionPoint>\n\t\t\t</ObjectHeader>\n\t\t\t<IconTabBar class="iconTabBarPaddingTop" expanded="{device>/isNoPhone}" id="S3IconTabBar" items="{a>/DetailModelDataCollection}"\n\t\t\t\tselect="reset">\n\t\t\t\t<items>\n\t\t\t\t\t<IconTabFilter key="{a>tabFilterID}"\n\t\t\t\t\t\ttext="{parts:[{path:\'a>WEEK_START\'},{path:\'a>WEEK_END\'}], formatter:\'hcm.approve.timesheet.util.Formatter.DateRangeFormatter\'}">\n\t\t\t\t\t\t<content>\n\t\t\t\t\t\t\t<Table fixedLayout="false" id="PendingEntriesTable" inset="false" items="{a>PENDING_ENTRIES}">\n\t\t\t\t\t\t\t\t<columns>\n\t\t\t\t\t\t\t\t\t<Column demandPopin="true" id="S3DateColumn" mergeDuplicates="true" minScreenWidth="Tablet">\n\t\t\t\t\t\t\t\t\t\t<header>\n\t\t\t\t\t\t\t\t\t\t\t<Label design="Bold" text="{i18n>TSA_DATE}"/>\n\t\t\t\t\t\t\t\t\t\t</header>\n\t\t\t\t\t\t\t\t\t</Column>\n\t\t\t\t\t\t\t\t\t<Column id="S3CheckBoxColumn">\n\t\t\t\t\t\t\t\t\t\t<CheckBox enabled="{a>MainCheckBoxState}" id="HeaderCheckbox" select="selectAllCheckBoxes" selected="{a>MainCheckBoxSelectedState}"/>\n\t\t\t\t\t\t\t\t\t</Column>\n\t\t\t\t\t\t\t\t\t<Column id="S3DescrColumn" demandPopin="true" minScreenWidth="Tablet">                   <!-- NOTE 2312493 -->\n\t\t\t\t\t\t\t\t\t\t<header>\n\t\t\t\t\t\t\t\t\t\t\t<Label design="Bold" text="{i18n>TSA_DESCRIPTION}"/>\n\t\t\t\t\t\t\t\t\t\t</header>\n\t\t\t\t\t\t\t\t\t</Column>\n\t\t\t\t\t\t\t\t\t<Column id="S3TimeColumn">\n\t\t\t\t\t\t\t\t\t\t<header>\n\t\t\t\t\t\t\t\t\t\t\t<ObjectIdentifier id="RecordedTime"\n\t\t\t\t\t\t\t\t\t\t\t\ttext="{parts:[{path:\'a>totalCatHours\'},{path:\'a>weekTarget\'}], formatter:\'hcm.approve.timesheet.util.Formatter.recTimeDisplay\'}"\n\t\t\t\t\t\t\t\t\t\t\t\ttitle="{parts:[{path:\'a>weekTarget\'},{path:\'i18n>TSA_TIME_RECORDED\'},{path:\'i18n>TSA_WEEKLY_TARGET\'},{path:\'a>weekTarget\'}], formatter:\'hcm.approve.timesheet.util.Formatter.textFormatter\'}"/>\n\t\t\t\t\t\t\t\t\t\t</header>\n\t\t\t\t\t\t\t\t\t</Column>\n\t\t\t\t\t\t\t\t\t<Column demandPopin="true" id="S3StatusColumn" minScreenWidth="Tablet">\n\t\t\t\t\t\t\t\t\t\t<header>\n\t\t\t\t\t\t\t\t\t\t\t<Label design="Bold" text="{i18n>TSA_APPR_STATUS}"/>\n\t\t\t\t\t\t\t\t\t\t</header>\n\t\t\t\t\t\t\t\t\t</Column>\n\t\t\t\t\t\t\t\t\t<!-- extension point for additional fields -->\n\t\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extS3Column"></core:ExtensionPoint>\n\t\t\t\t\t\t\t\t\t<Column demandPopin="true" id="S3ButtonColumn" minScreenWidth="Tablet"></Column>\n\t\t\t\t\t\t\t\t</columns>\n\t\t\t\t\t\t\t\t<ColumnListItem type="Inactive">\n\t\t\t\t\t\t\t\t\t<cells>\n\t\t\t\t\t\t\t\t\t\t<Text text="{parts:[{path:\'a>WORKDATE\'}], formatter:\'hcm.approve.timesheet.util.Formatter.DateFormatter\'}"/>\n\t\t\t\t\t\t\t\t\t\t<CheckBox enabled="{a>CHECKBOX_STATE}" select="setButtonState" selected="{a>CHECKBOX_SELECTED_STATE}">\n\t\t\t\t\t\t\t\t\t\t\t<customData>\n\t\t\t\t\t\t\t\t\t\t\t\t<core:CustomData key="counter" value="{a>COUNTER}"/>\n\t\t\t\t\t\t\t\t\t\t\t\t<core:CustomData key="lastChangedDate" value="{a>CHANGED_DATE}"/>\n\t\t\t\t\t\t\t\t\t\t\t\t<core:CustomData key="lastChangedTime" value="{a>CHANGED_TIME}"/>\n\t\t\t\t\t\t\t\t\t\t\t</customData>\n\t\t\t\t\t\t\t\t\t\t</CheckBox>\n\t\t\t\t\t\t\t\t\t\t<ObjectIdentifier text="{a>SUB_FIELDS_TEXT}" title="{a>MAIN_FIELD_TEXT}"/>\n\t\t\t\t\t\t\t\t\t\t<Text text="{parts:[{path:\'a>CATSHOURS\'},{path:\'a>CATSUNIT\'}], formatter:\'hcm.approve.timesheet.util.Formatter.unitAppender\'}"/>\n\t\t\t\t\t\t\t\t\t\t<ObjectStatus state="{a>STATUS}" text="{a>STATUS_TEXT}"/>\n\t\t\t\t\t\t\t\t\t\t<!-- extension point for additional fields -->\n\t\t\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extS3Cells"></core:ExtensionPoint>\n\t\t\t\t\t\t\t\t\t\t<Button icon="sap-icon://detail-view" press="viewSummary" visible="{a>moreInfoBtnStatus}">\n\t\t\t\t\t\t\t\t\t\t\t<customData>\n\t\t\t\t\t\t\t\t\t\t\t\t<core:CustomData key="counter" value="{a>COUNTER}"/>\n\t\t\t\t\t\t\t\t\t\t\t\t<core:CustomData key="empname" value="{a>EMPNAME}"/>\n\t\t\t\t\t\t\t\t\t\t\t</customData>\n\t\t\t\t\t\t\t\t\t\t</Button>\n\t\t\t\t\t\t\t\t\t</cells>\n\t\t\t\t\t\t\t\t</ColumnListItem>\n\t\t\t\t\t\t\t</Table>\n\t\t\t\t\t\t</content>\n\t\t\t\t\t\t<customData>\n\t\t\t\t\t\t\t<core:CustomData key="{a>COUNTER}" value="{a>displayWeekNumber}"/>\n\t\t\t\t\t\t</customData>\n\t\t\t\t\t</IconTabFilter>\n\t\t\t\t</items>\n\t\t\t</IconTabBar>\n\t\t</content>\n\t</Page>\n</core:View>'
}});
